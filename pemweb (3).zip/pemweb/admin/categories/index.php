<?php
session_start();
require_once '../../db.php';

if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../../login.php');
    exit;
}

// Handle category deletion
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    
    // Cek apakah kategori digunakan di item_types sebelum menghapus
    $check = $conn->query("SELECT COUNT(*) as count FROM item_types WHERE service_category_id = $id")->fetch_assoc();
    
    if ($check['count'] > 0) {
        $_SESSION['error'] = "Cannot delete category. It's being used by some items.";
    } else {
        $conn->query("DELETE FROM service_categories WHERE id = $id");
        $_SESSION['success'] = "Category deleted successfully";
    }
    
    header('Location: index.php');
    exit;
}

// Handle form submission for adding new category
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_category'])) {
    $name = $conn->real_escape_string(trim($_POST['name']));
    $description = $conn->real_escape_string(trim($_POST['description']));
    
    // Validasi
    if (empty($name)) {
        $_SESSION['error'] = "Category name cannot be empty";
    } else {
        // Cek duplikasi
        $check = $conn->query("SELECT COUNT(*) as count FROM service_categories WHERE name = '$name'")->fetch_assoc();
        
        if ($check['count'] > 0) {
            $_SESSION['error'] = "Category name already exists";
        } else {
            $sql = "INSERT INTO service_categories (name, description) VALUES ('$name', '$description')";
            if ($conn->query($sql)) {
                $_SESSION['success'] = "Category added successfully";
            } else {
                $_SESSION['error'] = "Error adding category: " . $conn->error;
            }
        }
    }
    
    header('Location: index.php');
    exit;
}

// Get all service categories
$categories = $conn->query("SELECT * FROM service_categories ORDER BY name");
$category_count = $categories->num_rows;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Service Categories</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        .action-column {
            width: 120px;
        }
        .card {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <?php include '../navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <div class="row">
            <div class="col-md-3">
                <?php include '../sidebar.php'; ?>
            </div>
            <div class="col-md-9">
                <h2>Service Categories</h2>
                
                <!-- Alert Messages -->
                <?php if (isset($_SESSION['success'])): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?= $_SESSION['success'] ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <?php unset($_SESSION['success']); ?>
                <?php endif; ?>
                
                <?php if (isset($_SESSION['error'])): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?= $_SESSION['error'] ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <?php unset($_SESSION['error']); ?>
                <?php endif; ?>
                
                <div class="card mb-4">
                    <div class="card-header">
                        <h5>Add New Category</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="name" class="form-label">Category Name *</label>
                                    <input type="text" class="form-control" id="name" name="name" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="description" class="form-label">Description</label>
                                    <textarea class="form-control" id="description" name="description" rows="1"></textarea>
                                </div>
                            </div>
                            <button type="submit" name="add_category" class="btn btn-primary">
                                <i class="bi bi-plus-circle"></i> Add Category
                            </button>
                        </form>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5>Category List</h5>
                        <span class="badge bg-primary">
                            Total: <?= $category_count ?> categories
                        </span>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover table-striped">
                                <thead class="table-light">
                                    <tr>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Description</th>
                                        <th class="action-column">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if ($category_count > 0): ?>
                                        <?php while($category = $categories->fetch_assoc()): ?>
                                        <tr>
                                            <td><?= $category['id'] ?></td>
                                            <td><?= htmlspecialchars($category['name']) ?></td>
                                            <td><?= htmlspecialchars($category['description']) ?></td>
                                            <td>
                                                <div class="btn-group btn-group-sm" role="group">
                                                    <a href="edit.php?id=<?= $category['id'] ?>" class="btn btn-primary" title="Edit">
                                                        <i class="bi bi-pencil"></i>
                                                    </a>
                                                    <a href="?delete=<?= $category['id'] ?>" class="btn btn-danger" title="Delete" onclick="return confirm('Are you sure to delete this category?')">
                                                        <i class="bi bi-trash"></i>
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endwhile; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="4" class="text-center text-muted">No categories found</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>