<?php
session_start();
require_once '../../db.php';

if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../../login.php');
    exit;
}

$id = intval($_GET['id'] ?? 0);

$technician = $conn->query("
    SELECT t.*, u.name, u.email, u.phone, u.profile_picture, u.country, u.gender, u.created_at as user_created
    FROM technicians t
    JOIN users u ON t.user_id = u.id
    WHERE t.id = $id
")->fetch_assoc();

if (!$technician) {
    $_SESSION['error'] = "Technician not found";
    header('Location: index.php');
    exit;
}

$skills = $conn->query("
    SELECT sc.id, sc.name 
    FROM technician_skills ts
    JOIN service_categories sc ON ts.service_category_id = sc.id
    WHERE ts.user_id = {$technician['user_id']}
");

$completedOrders = $conn->query("
    SELECT COUNT(*) as count 
    FROM orders 
    WHERE technician_id = $id AND status = 'completed'
")->fetch_assoc()['count'];

$avgRating = $conn->query("
    SELECT AVG(rating) as avg_rating 
    FROM feedback 
    WHERE technician_id = $id
")->fetch_assoc()['avg_rating'];
$avgRating = $avgRating ? round($avgRating, 1) : 'No ratings yet';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Technician Details</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <div class="row">
            <div class="col-md-3">
                <?php include '../sidebar.php'; ?>
            </div>
            <div class="col-md-9">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2>Technician Details</h2>
                    <div>
                        <a href="index.php" class="btn btn-secondary">
                            <i class="bi bi-arrow-left"></i> Back
                        </a>
                        <a href="edit.php?id=<?= $id ?>" class="btn btn-primary">
                            <i class="bi bi-pencil"></i> Edit
                        </a>
                    </div>
                </div>
                
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-3 text-center">
                                <img src="<?= $technician['profile_picture'] ? '../../uploads/profiles/'.$technician['profile_picture'] : 'https://via.placeholder.com/150' ?>" 
                                     class="rounded-circle img-thumbnail mb-3" width="150" height="150">
                                <h4><?= htmlspecialchars($technician['name']) ?></h4>
                                <span class="badge bg-<?= $technician['is_verified'] ? 'success' : 'warning' ?>">
                                    <?= $technician['is_verified'] ? 'Verified' : 'Unverified' ?>
                                </span>
                            </div>
                            <div class="col-md-9">
                                <div class="row mb-3">
                                    <div class="col-md-4">
                                        <h6>Email</h6>
                                        <p><?= htmlspecialchars($technician['email']) ?></p>
                                    </div>
                                    <div class="col-md-4">
                                        <h6>Phone</h6>
                                        <p><?= htmlspecialchars($technician['phone']) ?></p>
                                    </div>
                                    <div class="col-md-4">
                                        <h6>Country</h6>
                                        <p><?= htmlspecialchars($technician['country']) ?></p>
                                    </div>
                                </div>
                                
                                <div class="row mb-3">
                                    <div class="col-md-4">
                                        <h6>Specialization</h6>
                                        <p><?= htmlspecialchars($technician['specialization']) ?></p>
                                    </div>
                                    <div class="col-md-4">
                                        <h6>Experience</h6>
                                        <p><?= $technician['experience_years'] ?> years</p>
                                    </div>
                                    <div class="col-md-4">
                                        <h6>Hourly Rate</h6>
                                        <p>Rp <?= number_format($technician['rate'], 0, ',', '.') ?></p>
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-4">
                                        <h6>Completed Jobs</h6>
                                        <p><?= $completedOrders ?></p>
                                    </div>
                                    <div class="col-md-4">
                                        <h6>Average Rating</h6>
                                        <p>
                                            <?php if (is_numeric($avgRating)): ?>
                                                <?= str_repeat('★', floor($avgRating)) . (fmod($avgRating, 1) >= 0.5 ? '½' : '') ?>
                                                (<?= $avgRating ?>/5)
                                            <?php else: ?>
                                                <?= $avgRating ?>
                                            <?php endif; ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="card mb-4">
                            <div class="card-header">
                                <h5 class="mb-0">Skills</h5>
                            </div>
                            <div class="card-body">
                                <?php if ($skills->num_rows > 0): ?>
                                    <div class="d-flex flex-wrap gap-2">
                                        <?php while($skill = $skills->fetch_assoc()): ?>
                                            <span class="badge bg-primary"><?= htmlspecialchars($skill['name']) ?></span>
                                        <?php endwhile; ?>
                                    </div>
                                <?php else: ?>
                                    <p class="text-muted">No skills added</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>