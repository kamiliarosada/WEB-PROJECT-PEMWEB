<?php
session_start();
require_once '../../db.php';

if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../../login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $conn->real_escape_string($_POST['name']);
    $username = $conn->real_escape_string($_POST['username']);
    $email = $conn->real_escape_string($_POST['email']);
    $role = $conn->real_escape_string($_POST['role']);
    $password = $conn->real_escape_string($_POST['password']); // Password disimpan plain text
    $confirm_password = $conn->real_escape_string($_POST['confirm_password']);
    
    // Validasi password
    if ($password !== $confirm_password) {
        $_SESSION['error'] = 'Password dan konfirmasi password tidak cocok!';
        header('Location: index.php');
        exit;
    }
    
    // Cek apakah username atau email sudah ada
    $check = $conn->query("SELECT id FROM users WHERE username = '$username' OR email = '$email'");
    if ($check->num_rows > 0) {
        $_SESSION['error'] = 'Username atau email sudah digunakan!';
        header('Location: index.php');
        exit;
    }
    
    // Simpan password dalam bentuk plain text (TIDAK AMAN!)
    $conn->query("INSERT INTO users (name, username, email, password, role, is_verified) 
                 VALUES ('$name', '$username', '$email', '$password', '$role', 1)");
    
    $user_id = $conn->insert_id;
    
    // Jika role adalah teknisi, tambahkan ke tabel technicians
    if ($role === 'technician') {
        $specialization = $conn->real_escape_string($_POST['specialization']);
        $experience_years = (int)$_POST['experience_years'];
        $certification = $conn->real_escape_string($_POST['certification']);
        $rate = (float)$_POST['rate'];
        
        $conn->query("INSERT INTO technicians (user_id, specialization, experience_years, certification, rate, is_verified) 
                     VALUES ($user_id, '$specialization', $experience_years, '$certification', $rate, 1)");
    }
    
    $_SESSION['message'] = 'User baru berhasil ditambahkan!';
    header('Location: index.php');
    exit;
}

header('Location: index.php');
exit;
?>