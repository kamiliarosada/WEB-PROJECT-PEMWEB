<?php
session_start();
require_once '../db.php';

// Check if user is logged in and has user role
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'user') {
    header('Location: ../login.php');
    exit;
}

// Get user ID from session (pastikan ini diset saat login)
if (!isset($_SESSION['user_id'])) {
    // Jika tidak ada, ambil dari database berdasarkan username
    $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->bind_param("s", $_SESSION['username']);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $_SESSION['user_id'] = $user['id'];
}

// Get selected category from URL
$category_id = isset($_GET['category']) ? intval($_GET['category']) : null;

// Check if technician ID is provided for booking
$tech_id = isset($_GET['tech_id']) ? intval($_GET['tech_id']) : null;

// Get all service categories
$categories = $conn->query("SELECT * FROM service_categories ORDER BY name");

// Get technicians based on selected category
if ($category_id) {
    $technicians = $conn->query("
        SELECT DISTINCT u.id, u.name, u.profile_picture, 
               (SELECT GROUP_CONCAT(sc.name SEPARATOR ', ') 
                FROM service_categories sc 
                JOIN technician_skills ts ON sc.id = ts.service_category_id
                WHERE ts.user_id = u.id) as skills,
               (SELECT AVG(rating) FROM feedback WHERE technician_id = u.id) as avg_rating,
               (SELECT COUNT(*) FROM feedback WHERE technician_id = u.id) as review_count,
               t.rate
        FROM users u
        LEFT JOIN technicians t ON t.user_id = u.id
        JOIN technician_skills ts ON ts.user_id = u.id
        WHERE u.is_verified = 1 
          AND u.role = 'technician' 
          AND ts.service_category_id = $category_id
        ORDER BY u.name
    ");
} else {
    // Get all verified technicians if no category selected
    $technicians = $conn->query("
        SELECT DISTINCT u.id, u.name, u.profile_picture, 
               (SELECT GROUP_CONCAT(sc.name SEPARATOR ', ') 
                FROM service_categories sc 
                JOIN technician_skills ts ON sc.id = ts.service_category_id
                WHERE ts.user_id = u.id) as skills,
               (SELECT AVG(rating) FROM feedback WHERE technician_id = u.id) as avg_rating,
               (SELECT COUNT(*) FROM feedback WHERE technician_id = u.id) as review_count,
               t.rate
        FROM users u
        LEFT JOIN technicians t ON t.user_id = u.id
        WHERE u.is_verified = 1 AND u.role = 'technician'
        ORDER BY u.name
    ");
}

// If tech_id is provided, get technician details
if ($tech_id) {
    $tech_stmt = $conn->prepare("
        SELECT u.id, u.name, u.profile_picture, u.email, u.phone, u.country,
               t.specialization, t.experience_years, t.certification, t.rate
        FROM technicians t
        JOIN users u ON t.user_id = u.id
        WHERE u.id = ?
    ");
    $tech_stmt->bind_param("i", $tech_id);
    $tech_stmt->execute();
    $selected_tech = $tech_stmt->get_result()->fetch_assoc();
    
    // Get average rating
    $avg_rating = $conn->query("
        SELECT AVG(rating) as avg_rating FROM feedback WHERE technician_id = $tech_id
    ")->fetch_assoc()['avg_rating'] ?? 4.5;
}

// Get count of all technicians
$total_techs = $conn->query("
    SELECT COUNT(*) as count 
    FROM users u
    WHERE u.is_verified = 1 AND u.role = 'technician'
")->fetch_assoc()['count'];

// Get average satisfaction (placeholder)
$satisfaction = 97;

// Get count of item types
$item_types = $conn->query("SELECT COUNT(*) as count FROM item_types")->fetch_assoc()['count'];
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Service Elektronik | ReparoTech</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: linear-gradient(135deg, #f5f7fa 0%, #e4e8f0 100%);
      color: #333;
      line-height: 1.6;
      min-height: 100vh;
    }
    
    /* Header Navigation */
    .nav-container {
      display: flex;
      justify-content: space-between;
      align-items: center;
      max-width: 1200px;
      margin: 0 auto;
      padding: 15px 20px;
      background: white;
      box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }
    
    .logo {
      display: flex;
      align-items: center;
      gap: 10px;
      font-size: 1.5rem;
      font-weight: 700;
      color: #2563eb;
      text-decoration: none;
    }
    
    .logo i {
      font-size: 1.8rem;
    }
    
    .nav-links {
      display: flex;
      gap: 25px;
    }
    
    .nav-links a {
      text-decoration: none;
      color: #1e293b;
      font-weight: 500;
      transition: color 0.3s ease;
      display: flex;
      align-items: center;
      gap: 5px;
    }
    
    .nav-links a:hover {
      color: #2563eb;
    }
    
    .nav-links a.active {
      color: #2563eb;
      font-weight: 600;
    }
    
    .user-actions {
      display: flex;
      align-items: center;
      gap: 15px;
    }
    
    .user-actions a {
      text-decoration: none;
      color: #1e293b;
      transition: color 0.3s ease;
    }
    
    .user-actions a:hover {
      color: #2563eb;
    }
    
    .user-profile {
      display: flex;
      align-items: center;
      gap: 8px;
      cursor: pointer;
      position: relative;
    }
    
    .user-img {
      width: 35px;
      height: 35px;
      border-radius: 50%;
      background: #2563eb;
      color: white;
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 600;
    }
    
    .dropdown-menu {
      position: absolute;
      top: 45px;
      right: 0;
      background: white;
      border-radius: 8px;
      box-shadow: 0 5px 15px rgba(0,0,0,0.1);
      padding: 10px 0;
      min-width: 180px;
      display: none;
      z-index: 100;
    }
    
    .dropdown-menu a {
      display: block;
      padding: 8px 15px;
      color: #334155;
      text-decoration: none;
      transition: background 0.3s;
    }
    
    .dropdown-menu a:hover {
      background: #f1f5f9;
    }
    
    .user-profile:hover .dropdown-menu {
      display: block;
    }
    
    /* Rest of your existing service.php styles */
    .container {
      max-width: 1200px;
      margin: 30px auto;
      background: white;
      border-radius: 15px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
      overflow: hidden;
      padding: 20px;
    }
    
    .breadcrumb {
      padding: 15px 0;
      font-size: 0.9rem;
      color: #666;
    }
    
    .breadcrumb a {
      color: #2563eb;
      text-decoration: none;
    }
    
    .breadcrumb span {
      margin: 0 5px;
      color: #999;
    }
    
    .hero {
      text-align: center;
      padding: 30px 0;
      margin-bottom: 30px;
    }
    
    .hero h1 {
      font-size: 2.2rem;
      color: #1e40af;
      margin-bottom: 15px;
    }
    
    .hero p {
      font-size: 1.1rem;
      color: #4b5563;
      max-width: 700px;
      margin: 0 auto 25px;
    }
    
    .stats {
      display: flex;
      justify-content: center;
      gap: 30px;
      margin-top: 30px;
    }
    
    .stat-item {
      text-align: center;
    }
    
    .stat-item .number {
      font-size: 2rem;
      font-weight: 700;
      color: #2563eb;
      margin-bottom: 5px;
    }
    
    .stat-item .label {
      font-size: 0.9rem;
      color: #64748b;
    }
    
    .filters {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 30px;
      flex-wrap: wrap;
      gap: 15px;
    }
    
    .filter-group {
      display: flex;
      gap: 10px;
      flex-wrap: wrap;
    }
    
    .filter-btn {
      padding: 10px 15px;
      background: #f1f5f9;
      border-radius: 8px;
      cursor: pointer;
      transition: all 0.3s ease;
      font-size: 0.9rem;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    
    .filter-btn:hover {
      background: #e2e8f0;
    }
    
    .filter-btn.active {
      background: #2563eb;
      color: white;
    }
    
    .location-select {
      padding: 10px 15px;
      border-radius: 8px;
      border: 1px solid #e2e8f0;
      background: white;
      font-size: 0.9rem;
    }
    
    .section-title {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 20px;
    }
    
    .section-title h2 {
      font-size: 1.5rem;
      color: #1e40af;
      display: flex;
      align-items: center;
      gap: 10px;
    }
    
    .view-all {
      color: #2563eb;
      text-decoration: none;
      font-size: 0.9rem;
      display: flex;
      align-items: center;
      gap: 5px;
    }
    
    .technician-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
      gap: 25px;
      margin-bottom: 40px;
    }
    
    .tech-box {
      background: white;
      border-radius: 12px;
      overflow: hidden;
      box-shadow: 0 5px 15px rgba(0,0,0,0.05);
      transition: all 0.3s ease;
      text-decoration: none;
      color: inherit;
      opacity: 0;
      transform: translateY(20px);
      transition: opacity 0.3s ease, transform 0.3s ease;
    }
    
    .tech-box img {
      width: 100%;
      height: 200px;
      object-fit: cover;
    }
    
    .tech-info {
      padding: 20px;
    }
    
    .tech-info h3 {
      font-size: 1.2rem;
      margin-bottom: 5px;
      color: #1e293b;
    }
    
    .specialty {
      color: #64748b;
      font-size: 0.9rem;
      margin-bottom: 10px;
    }
    
    .stars {
      color: #f59e0b;
      margin-bottom: 10px;
      display: flex;
      align-items: center;
      gap: 5px;
    }
    
    .stars span {
      color: #64748b;
      font-size: 0.8rem;
    }
    
    .location {
      color: #64748b;
      font-size: 0.9rem;
      display: flex;
      align-items: center;
      gap: 5px;
      margin-bottom: 10px;
    }
    
    .price {
      color: #2563eb;
      font-weight: 600;
      margin-bottom: 15px;
    }
    
    .action-btn {
      width: 100%;
      padding: 10px;
      background: #2563eb;
      color: white;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      transition: background 0.3s ease;
      font-weight: 500;
    }
    
    .action-btn:hover {
      background: #1d4ed8;
    }
    
    .no-techs {
      grid-column: 1 / -1;
      text-align: center;
      padding: 50px 0;
    }
    
    .no-techs i {
      font-size: 3rem;
      color: #64748b;
      margin-bottom: 20px;
    }
    
    .no-techs h3 {
      color: #1e293b;
      margin-bottom: 10px;
    }
    
    .no-techs p {
      color: #64748b;
    }
    
    footer {
      text-align: center;
      padding: 20px;
      color: #64748b;
      font-size: 0.9rem;
    }
    
    @media (max-width: 768px) {
      .nav-links {
        display: none;
      }
      
      .stats {
        flex-direction: column;
        gap: 20px;
      }
      
      .hero h1 {
        font-size: 1.8rem;
      }
      
      .hero p {
        font-size: 1rem;
      }
    }
    .skill-badge {
      display: inline-block;
      background-color: #f0f0f0;
      color: #333;
      padding: 3px 8px;
      border-radius: 12px;
      font-size: 12px;
      margin: 2px;
      white-space: nowrap;
    }

    .specialty {
      margin: 8px 0;
      display: flex;
      flex-wrap: wrap;
    }

    .tech-box {
      opacity: 0;
      transform: translateY(20px);
      transition: all 0.3s ease;
    }

    .booking-modal {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0,0,0,0.5);
      z-index: 1000;
      overflow-y: auto;
    }
    
    .booking-content {
      background-color: white;
      margin: 5% auto;
      padding: 20px;
      width: 80%;
      max-width: 600px;
      border-radius: 10px;
      box-shadow: 0 5px 15px rgba(0,0,0,0.3);
    }
    
    .close-btn {
      float: right;
      font-size: 28px;
      cursor: pointer;
    }
    
    .form-group {
      margin-bottom: 15px;
    }
    
    .form-group label {
      display: block;
      margin-bottom: 5px;
      font-weight: bold;
    }
    
    .form-control {
      width: 100%;
      padding: 10px;
      border: 1px solid #ddd;
      border-radius: 5px;
    }
    
    .submit-btn {
      background-color: #4CAF50;
      color: white;
      padding: 10px 15px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      font-size: 16px;
    }
    
    .submit-btn:hover {
      background-color: #45a049;
    }
    
    .tech-info-box {
      background-color: #f9f9f9;
      padding: 15px;
      border-radius: 5px;
      margin-bottom: 20px;
    }
    
    .tech-info-box img {
      width: 80px;
      height: 80px;
      border-radius: 50%;
      object-fit: cover;
      margin-right: 15px;
      float: left;
    }
    
    .tech-info-content {
      overflow: hidden;
    }
    
    .tech-info-content h3 {
      margin-top: 0;
    }
  </style>
</head>
<body>

  <!-- Navigation Bar -->
  <div class="nav-container">
    <a href="../index.php" class="logo">
      <i class="fas fa-tools"></i>
      <span>ReparoTech</span>
    </a>
    
    <div class="nav-links">
      <a href="../index.php"><i class="fas fa-home"></i> Beranda</a>
      <a href="service.php" class="active"><i class="fas fa-headset"></i> Layanan</a>
      <a href="pesanan.php"><i class="fas fa-clipboard-list"></i> Pesanan</a>
      <a href="artikel.php"><i class="fas fa-clipboard-list"></i> Artikel</a>
    </div>
    
    <div class="user-actions">
      <div class="user-profile">
        <div class="user-img"><?php echo strtoupper(substr($_SESSION['username'], 0, 1)); ?></div>
        <span><?php echo htmlspecialchars($_SESSION['username']); ?></span>
        <div class="dropdown-menu">
          <a href="profile.php"><i class="fas fa-user"></i> Profil</a>
          <a href="riwayat-pesanan.php"><i class="fas fa-history"></i> Riwayat</a>
          <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
      </div>
    </div>
  </div>
  
  <div class="container">
    <div class="hero">
      <h1>Temukan Teknisi Profesional</h1>
      <p>Lebih dari 500 teknisi ahli siap membantu perbaikan perangkat elektronik Anda</p>
      
      <div class="stats">
        <div class="stat-item">
          <div class="number"><?= $total_techs ?>+</div>
          <div class="label">Teknisi Profesional</div>
        </div>
        <div class="stat-item">
          <div class="number"><?= $satisfaction ?>%</div>
          <div class="label">Kepuasan Pelanggan</div>
        </div>
        <div class="stat-item">
          <div class="number">24/7</div>
          <div class="label">Layanan Dukungan</div>
        </div>
      </div>
    </div>
    
    <div class="filters">
      <div class="filter-group">
        <div class="filter-btn <?= !$category_id ? 'active' : '' ?>" onclick="window.location.href='service.php'">
          <i class="fas fa-layer-group"></i> Semua Kategori
        </div>
        <?php 
        $categories->data_seek(0); // Reset pointer result
        while($category = $categories->fetch_assoc()): 
          // Determine icon based on category name
          $icon = 'fa-question'; // default icon
          switch($category['name']) {
            case 'Kulkas':
              $icon = 'fa-snowflake';
              break;
            case 'AC':
              $icon = 'fa-fan';
              break;
            case 'Mesin Cuci':
              $icon = 'fa-tshirt';
              break;
            case 'TV':
              $icon = 'fa-tv';
              break;
            case 'Laptop':
              $icon = 'fa-laptop';
              break;
          }
        ?>
        <div class="filter-btn <?= $category_id == $category['id'] ? 'active' : '' ?>" 
             onclick="window.location.href='service.php?category=<?= $category['id'] ?>'">
          <i class="fas <?= $icon ?>"></i> <?= htmlspecialchars($category['name']) ?>
        </div>
        <?php endwhile; ?>
      </div>
    </div>
    
    <div class="section-title">
      <h2><i class="fas fa-user-cog"></i> 
        <?php 
        if ($category_id) {
            $cat_name = $conn->query("SELECT name FROM service_categories WHERE id = $category_id")->fetch_assoc()['name'];
            echo htmlspecialchars($cat_name);
        } else {
            echo 'Semua Teknisi';
        } 
        ?>
      </h2>
      <a href="#" class="view-all">Lihat Semua <i class="fas fa-arrow-right"></i></a>
    </div>
    
    <div class="technician-grid" id="techList">
      <?php if($technicians->num_rows > 0): ?>
        <?php while($tech = $technicians->fetch_assoc()): ?>
        <div class="tech-box">
          <img src="<?= $tech['profile_picture'] ? htmlspecialchars($tech['profile_picture']) : 'https://randomuser.me/api/portraits/men/'.rand(1,99).'.jpg' ?>">
          <div class="tech-info">
            <h3><?= htmlspecialchars($tech['name']) ?></h3>
            <div class="specialty">
              <?php 
              $skills = explode(', ', $tech['skills']);
              foreach($skills as $skill): ?>
                <span class="skill-badge"><?= htmlspecialchars($skill) ?></span>
              <?php endforeach; ?>
            </div>
            <div class="stars">
              <?php 
              $rating = round($tech['avg_rating'] ?? 0);
              for($i = 1; $i <= 5; $i++): ?>
                <i class="fas fa-star<?= $i <= $rating ? '' : '-half-alt' ?>"></i>
              <?php endfor; ?>
              <span>(<?= $tech['review_count'] ?: 0 ?>)</span>
            </div>
            <div class="price">Rp <?= number_format($tech['rate'] ?? 50000, 0, ',', '.') ?>/jam</div>
            <button class="action-btn" onclick="showBookingForm(<?= $tech['id'] ?>, '<?= htmlspecialchars($tech['name']) ?>', '<?= $tech['profile_picture'] ? htmlspecialchars($tech['profile_picture']) : 'https://randomuser.me/api/portraits/men/'.rand(1,99).'.jpg' ?>', <?= $tech['rate'] ?? 50000 ?>)">
              Pilih Teknisi
            </button>
          </div>
        </div>
        <?php endwhile; ?>
      <?php else: ?>
        <div class="no-techs">
          <i class="fas fa-user-slash"></i>
          <h3>Tidak ada teknisi yang tersedia</h3>
          <p>Silakan coba kategori lain atau coba lagi nanti</p>
        </div>
      <?php endif; ?>
    </div>
    
     <!-- Booking Modal -->
    <div id="bookingModal" class="booking-modal">
      <div class="booking-content">
        <span class="close-btn" onclick="closeBookingForm()">&times;</span>
        
        <div class="tech-info-box">
          <img id="modalTechImage" src="">
          <div class="tech-info-content">
            <h3 id="modalTechName"></h3>
            <div class="price" id="modalTechRate"></div>
          </div>
        </div>
        <?php if (isset($_GET['success']) && $_GET['success'] == 1): ?>
          <div class="alert alert-success">
            Pesanan berhasil dibuat! Teknisi akan segera menghubungi Anda.
          </div>
        <?php endif; ?>

        <h2><i class="fas fa-calendar-alt"></i> Form Pemesanan</h2>
        
        <form action="process_booking.php" method="POST" id="bookingForm">
          <input type="hidden" name="tech_id" id="formTechId" value="">
          
          <div class="form-group">
              <label for="book-name">Nama Lengkap</label>
              <input type="text" id="book-name" name="name" class="form-control" 
                    value="<?= isset($_SESSION['name']) ? htmlspecialchars($_SESSION['name']) : '' ?>" 
                    placeholder="Masukkan nama Anda" required>
          </div>
          
          <div class="form-group">
              <label for="book-phone">Nomor Handphone</label>
              <input type="tel" id="book-phone" name="phone" class="form-control" 
                    value="<?= isset($_SESSION['phone']) ? htmlspecialchars($_SESSION['phone']) : '' ?>"
                    placeholder="Contoh: 081234567890" required>
          </div>
          
          <div class="form-group">
              <label for="book-address">Alamat Lengkap</label>
              <textarea id="book-address" name="address" class="form-control" 
                        placeholder="Masukkan alamat lengkap untuk perbaikan" required></textarea>
          </div>
          
          <div class="form-group">
              <label for="book-device">Perangkat yang Akan Diperbaiki</label>
              <input type="text" id="book-device" name="device" class="form-control" 
                    placeholder="Contoh: TV Samsung 32 inch" required>
          </div>
          
          <div class="form-group">
              <label for="book-date">Tanggal Perbaikan</label>
              <input type="date" id="book-date" name="date" class="form-control" required>
          </div>
          
          <div class="form-group">
              <label for="book-time">Waktu Perbaikan</label>
              <select id="book-time" name="time" class="form-control" required>
                  <option value="">Pilih Waktu</option>
                  <option value="08:00-10:00">08:00 - 10:00</option>
                  <option value="10:00-12:00">10:00 - 12:00</option>
                  <option value="13:00-15:00">13:00 - 15:00</option>
                  <option value="15:00-17:00">15:00 - 17:00</option>
              </select>
          </div>
          
          <div class="form-group">
              <label for="book-notes">Catatan Tambahan (Opsional)</label>
              <textarea id="book-notes" name="notes" class="form-control" 
                        placeholder="Masukkan catatan tambahan jika ada"></textarea>
          </div>
          
          <button type="submit" class="submit-btn">
              <i class="fas fa-check-circle"></i>
              Pesan Teknisi
          </button>
      </form>
      </div>
    </div>
    
    <footer>
      <p>&copy; <?= date('Y') ?> ReparoTech. Semua Hak Dilindungi.</p>
      <p>Layanan Service Elektronik Terpercaya di Indonesia</p>
    </footer>
  </div>
  
  <script>
    // Initialize technicians with animation
    document.addEventListener('DOMContentLoaded', function() {
      const techBoxes = document.querySelectorAll('.tech-box');
      techBoxes.forEach((box, index) => {
        setTimeout(() => {
          box.style.opacity = '1';
          box.style.transform = 'translateY(0)';
        }, index * 100);
      });
      
      // Set minimum date to tomorrow
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      document.getElementById('book-date').min = tomorrow.toISOString().split('T')[0];
    });
    
    // Show booking form
    function showBookingForm(techId, techName, techImage, techRate) {
      document.getElementById('modalTechImage').src = techImage;
      document.getElementById('modalTechName').textContent = techName;
      document.getElementById('modalTechRate').textContent = 'Rp ' + techRate.toLocaleString('id-ID') + '/jam';
      document.getElementById('formTechId').value = techId;
      
      // Pre-fill user data if available
      document.getElementById('book-name').value = '<?= isset($_SESSION['name']) ? addslashes($_SESSION['name']) : '' ?>';
      document.getElementById('book-phone').value = '<?= isset($_SESSION['phone']) ? addslashes($_SESSION['phone']) : '' ?>';
      
      document.getElementById('bookingModal').style.display = 'block';
    }
    
    // Close booking form
    function closeBookingForm() {
      document.getElementById('bookingModal').style.display = 'none';
    }
    
    // Close modal when clicking outside
    window.onclick = function(event) {
      if (event.target == document.getElementById('bookingModal')) {
        closeBookingForm();
      }
    }
  </script>
</body>
</html>