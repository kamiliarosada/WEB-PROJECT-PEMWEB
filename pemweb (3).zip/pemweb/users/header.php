<header>
  <div class="topbar">
    <div>📍 jl.soromandi no.2, Gomong, Mataram, </div>
    <div>🕘 Mon - Sat: 09.00 to 22.00</div>
    <div>📧 Supportyou@RepairTech.com</div>
    <div>📞 Customer Care: +62-8133-9400-577</div>
  </div>
  <nav>
    <h2>Reparo<span style="color: #00AEEF;">Tech</span></h2>
    <ul>
      <li><a href="#">HOME</a></li>
      <li><a href="#">SERVICES</a></li>
      <li><a href="#">PAGES</a></li>
      <li><a href="#">SHOP</a></li>
      <li><a href="#">NEWS</a></li>
      <li><a href="#">CONTACT</a></li>
    </ul>
  </nav>
</header>