<?php
session_start();
require_once '../db.php';

// Check if user is logged in and has user role
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'user') {
    header('Location: ../login.php');
    exit;
}

// Get user ID from session
$user_id = $_SESSION['user_id'];

// Get order history
$order_history = $conn->query("
    SELECT o.*, u.name as technician_name, u.profile_picture as tech_image, t.rate,
           (SELECT COUNT(*) FROM feedback WHERE order_id = o.id) as has_feedback
    FROM orders o
    LEFT JOIN technicians t ON o.technician_id = t.id
    LEFT JOIN users u ON t.user_id = u.id
    WHERE o.user_id = $user_id 
    AND o.status IN ('completed', 'cancelled')
    ORDER BY o.service_date DESC, o.service_time DESC
");

// Process feedback submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_feedback'])) {
    $order_id = intval($_POST['order_id']);
    $technician_id = intval($_POST['technician_id']);
    $rating = intval($_POST['rating']);
    $comment = $conn->real_escape_string(trim($_POST['comment']));
    
    // Validate rating
    if ($rating < 1 || $rating > 5) {
        $feedback_error = "Rating harus antara 1-5";
    } else {
        // Check if feedback already exists for this order
        $check_feedback = $conn->query("SELECT id FROM feedback WHERE order_id = $order_id");
        
        if ($check_feedback->num_rows > 0) {
            $feedback_error = "Anda sudah memberikan feedback untuk pesanan ini";
        } else {
            // Insert feedback
            $insert = $conn->query("
                INSERT INTO feedback (user_id, technician_id, order_id, rating, comment)
                VALUES ($user_id, $technician_id, $order_id, $rating, '$comment')
            ");
            
            if ($insert) {
                $feedback_success = "Feedback berhasil dikirim! Terima kasih.";
                // Refresh the page to show updated feedback status
                header("Location: riwayat-pesanan.php");
                exit;
            } else {
                $feedback_error = "Gagal mengirim feedback: " . $conn->error;
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Riwayat Pesanan - ReparoTech</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* Same CSS as before, including feedback modal styles */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f5f7fa;
            color: #333;
        }
        
    /* Header Navigation */
        .nav-container {
        display: flex;
        justify-content: space-between;
        align-items: center;
        max-width: 1200px;
        margin: 0 auto;
        padding: 15px 20px;
        background: white;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .logo {
        display: flex;
        align-items: center;
        gap: 10px;
        font-size: 1.5rem;
        font-weight: 700;
        color:rgb(37, 99, 235);
        text-decoration: none;
        }
        
        .logo i {
        font-size: 1.8rem;
        }
        
        .nav-links {
        display: flex;
        gap: 25px;
        }
        
        .nav-links a {
        text-decoration: none;
        color: #1e293b;
        font-weight: 500;
        transition: color 0.3s ease;
        display: flex;
        align-items: center;
        gap: 5px;
        }
        
        .nav-links a:hover {
        color: #2563eb;
        }
        
        .nav-links a.active {
        color: #2563eb;
        font-weight: 600;
        }
        
        .user-actions {
        display: flex;
        align-items: center;
        gap: 15px;
        }
        
        .user-actions a {
        text-decoration: none;
        color: #1e293b;
        transition: color 0.3s ease;
        }
        
        .user-actions a:hover {
        color: #2563eb;
        }
        
        .user-profile {
        display: flex;
        align-items: center;
        gap: 8px;
        cursor: pointer;
        position: relative;
        }
        
        .user-img {
        width: 35px;
        height: 35px;
        border-radius: 50%;
        background: #2563eb;
        color: white;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 600;
        }
        
        .dropdown-menu {
        position: absolute;
        top: 45px;
        right: 0;
        background: white;
        border-radius: 8px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        padding: 10px 0;
        min-width: 180px;
        display: none;
        z-index: 100;
        }
        
        .dropdown-menu a {
        display: block;
        padding: 8px 15px;
        color: #334155;
        text-decoration: none;
        transition: background 0.3s;
        }
        
        .dropdown-menu a:hover {
        background: #f1f5f9;
        }
        
        .user-profile:hover .dropdown-menu {
            display: block;
        }
        
        .container {
            max-width: 1200px;
            margin: 30px auto;
            padding: 0 20px;
        }
        
        .section-title {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin: 40px 0 20px;
        }
        
        .section-title h2 {
            font-size: 24px;
            color: #333;
            margin: 0;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .section-title i {
            color: #4a6cf7;
        }
        
        .view-all {
            color: #4a6cf7;
            text-decoration: none;
            font-size: 14px;
        }
        
        .view-all:hover {
            text-decoration: underline;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 40px;
            background-color: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.05);
        }
        
        th, td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        
        th {
            background-color: #4a6cf7;
            color: white;
            font-weight: 500;
        }
        
        tr:hover {
            background-color: #f8f9fa;
        }
        
        .status {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
            text-transform: capitalize;
        }
        
        .status-pending {
            background-color: #fff3cd;
            color: #856404;
        }
        
        .status-processing {
            background-color: #cce5ff;
            color: #004085;
        }
        
        .status-completed {
            background-color: #d4edda;
            color: #155724;
        }
        
        .status-cancelled {
            background-color: #f8d7da;
            color: #721c24;
        }
        
        .action-btn {
            padding: 8px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }
        
        .action-btn i {
            font-size: 12px;
        }
        
        .btn-primary {
            background-color: #4a6cf7;
            color: white;
        }
        
        .btn-primary:hover {
            background-color: #3a5ce4;
        }
        
        .btn-danger {
            background-color: #dc3545;
            color: white;
        }
        
        .btn-danger:hover {
            background-color: #c82333;
        }
        
        .btn-success {
            background-color: #28a745;
            color: white;
        }
        
        .btn-success:hover {
            background-color: #218838;
        }
        
        .btn-secondary {
            background-color: #6c757d;
            color: white;
        }
        
        .btn-secondary:hover {
            background-color: #5a6268;
        }
        
        .tech-info {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .tech-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
        }
        
        .no-orders {
            text-align: center;
            padding: 40px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.05);
        }
        
        .no-orders i {
            font-size: 50px;
            color: #ddd;
            margin-bottom: 20px;
        }
        
        .no-orders p {
            color: #777;
            margin-top: 10px;
        }
        
        /* Feedback Modal */
        .feedback-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 1000;
            justify-content: center;
            align-items: center;
        }
        
        .feedback-content {
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            width: 90%;
            max-width: 500px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
            animation: modalFadeIn 0.3s;
        }
        
        @keyframes modalFadeIn {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .feedback-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .feedback-header h3 {
            margin: 0;
            color: #333;
        }
        
        .close-btn {
            font-size: 24px;
            cursor: pointer;
            color: #777;
        }
        
        .close-btn:hover {
            color: #333;
        }
        
        .rating-stars {
            display: flex;
            justify-content: center;
            margin: 20px 0;
            direction: rtl;
        }
        
        .rating-stars input {
            display: none;
        }
        
        .rating-stars label {
            font-size: 30px;
            color: #ddd;
            cursor: pointer;
            padding: 0 5px;
        }
        
        .rating-stars input:checked ~ label,
        .rating-stars label:hover,
        .rating-stars label:hover ~ label {
            color: #ffc107;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
        }
        
        .form-group textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            resize: vertical;
            min-height: 100px;
        }
        
        .submit-feedback {
            background-color: #4a6cf7;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: all 0.3s;
            width: 100%;
        }
        
        .submit-feedback:hover {
            background-color: #3a5ce4;
        }
        
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
        }
        
        .alert-success {
            background-color: #d4edda;
            color: #155724;
        }
        
        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
        }
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <div class="nav-container">
        <a href="../index.php" class="logo">
            <i class="fas fa-tools"></i>
            <span>ReparoTech</span>
        </a>
        
        <div class="nav-links">
            <a href="../index.php"><i class="fas fa-home"></i> Beranda</a><
            <a href="service.php"><i class="fas fa-headset"></i> Layanan</a>
            <a href="pesanan.php"><i class="fas fa-clipboard-list"></i> Pesanan</a>
            <a href="riwayat-pesanan.php" class="active"><i class="fas fa-history"></i> Riwayat Pesanan</a>
            <a href="artikel.php"><i class="fas fa-clipboard-list"></i> Artikel</a>
        </div>
        
        <div class="user-actions">
            <div class="user-profile">
                <div class="user-img"><?php echo strtoupper(substr($_SESSION['username'], 0, 1)); ?></div>
                <span><?php echo htmlspecialchars($_SESSION['username']); ?></span>
                <div class="dropdown-menu">
                    <a href="profile.php"><i class="fas fa-user"></i> Profil</a>
                    <a href="riwayat-pesanan.php"><i class="fas fa-history"></i> Riwayat</a>
                    <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </div>
            </div>
        </div>
    </div>
    
    <div class="container">
        <!-- Order History Section -->
        <div class="section-title">
            <h2><i class="fas fa-history"></i> Riwayat Pesanan</h2>
            <a href="pesanan.php" class="view-all">
                <i class="fas fa-tasks"></i> Lihat Pesanan Aktif
            </a>
        </div>
        
        <?php if ($order_history->num_rows > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>ID Pesanan</th>
                        <th>Teknisi</th>
                        <th>Perangkat</th>
                        <th>Tanggal/Waktu</th>
                        <th>Status</th>
                        <th>Total</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($order = $order_history->fetch_assoc()): ?>
                    <tr>
                        <td>#<?php echo $order['id']; ?></td>
                        <td>
                            <div class="tech-info">
                                <img src="<?php echo htmlspecialchars($order['tech_image'] ?: 'https://randomuser.me/api/portraits/men/'.rand(1,99).'.jpg'); ?>" class="tech-avatar">
                                <span><?php echo htmlspecialchars($order['technician_name']); ?></span>
                            </div>
                        </td>
                        <td><?php echo htmlspecialchars($order['device']); ?></td>
                        <td>
                            <?php echo date('d M Y', strtotime($order['service_date'])); ?><br>
                            <?php echo htmlspecialchars($order['service_time']); ?>
                        </td>
                        <td>
                            <span class="status status-<?php echo strtolower($order['status']); ?>">
                                <?php echo htmlspecialchars($order['status']); ?>
                            </span>
                        </td>
                        <td>Rp <?php echo number_format($order['total_amount'], 0, ',', '.'); ?></td>
                        <td>
                            <button class="action-btn btn-primary" onclick="viewOrderDetails(<?php echo $order['id']; ?>)">
                                <i class="fas fa-eye"></i> Detail
                            </button>
                            
                            <?php if ($order['status'] === 'completed' && !$order['has_feedback']): ?>
                                <button class="action-btn btn-success" onclick="openFeedbackModal(<?php echo $order['id']; ?>, <?php echo $order['technician_id']; ?>, '<?php echo htmlspecialchars($order['technician_name']); ?>')">
                                    <i class="fas fa-star"></i> Beri Ulasan
                                </button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="no-orders">
                <i class="fas fa-history"></i>
                <h3>Tidak ada riwayat pesanan</h3>
                <p>Anda belum pernah melakukan pemesanan sebelumnya.</p>
            </div>
        <?php endif; ?>
    </div>
    
    <!-- Feedback Modal -->
    <div id="feedbackModal" class="feedback-modal">
        <div class="feedback-content">
            <div class="feedback-header">
                <h3>Beri Ulasan</h3>
                <span class="close-btn" onclick="closeFeedbackModal()">&times;</span>
            </div>
            
            <?php if (isset($feedback_success)): ?>
                <div class="alert alert-success">
                    <?php echo $feedback_success; ?>
                </div>
            <?php endif; ?>
            
            <?php if (isset($feedback_error)): ?>
                <div class="alert alert-error">
                    <?php echo $feedback_error; ?>
                </div>
            <?php endif; ?>
            
            <form id="feedbackForm" method="POST">
                <input type="hidden" name="order_id" id="feedbackOrderId">
                <input type="hidden" name="technician_id" id="feedbackTechId">
                <input type="hidden" name="submit_feedback" value="1">
                
                <div class="form-group">
                    <label>Rating</label>
                    <div class="rating-stars">
                        <input type="radio" id="star5" name="rating" value="5">
                        <label for="star5">&#9733;</label>
                        <input type="radio" id="star4" name="rating" value="4">
                        <label for="star4">&#9733;</label>
                        <input type="radio" id="star3" name="rating" value="3">
                        <label for="star3">&#9733;</label>
                        <input type="radio" id="star2" name="rating" value="2">
                        <label for="star2">&#9733;</label>
                        <input type="radio" id="star1" name="rating" value="1">
                        <label for="star1">&#9733;</label>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="comment">Komentar (Opsional)</label>
                    <textarea id="comment" name="comment" placeholder="Bagaimana pengalaman Anda dengan layanan kami?"></textarea>
                </div>
                
                <button type="submit" class="submit-feedback">
                    <i class="fas fa-paper-plane"></i> Kirim Ulasan
                </button>
            </form>
        </div>
    </div>
    
    <script>
        // Function to open feedback modal
        function openFeedbackModal(orderId, techId, techName) {
            document.getElementById('feedbackOrderId').value = orderId;
            document.getElementById('feedbackTechId').value = techId;
            document.querySelector('.feedback-header h3').textContent = `Beri Ulasan untuk ${techName}`;
            document.getElementById('feedbackModal').style.display = 'flex';
            
            // Reset form
            document.getElementById('feedbackForm').reset();
            <?php if (isset($feedback_error)): ?>
                document.querySelector('.alert-error').style.display = 'none';
            <?php endif; ?>
        }
        
        // Function to close feedback modal
        function closeFeedbackModal() {
            document.getElementById('feedbackModal').style.display = 'none';
        }
        
        // Close modal when clicking outside
        window.onclick = function(event) {
            if (event.target == document.getElementById('feedbackModal')) {
                closeFeedbackModal();
            }
        }
        
        // Function to view order details
        function viewOrderDetails(orderId) {
            // In a real application, this would show detailed order information
            alert(`Menampilkan detail pesanan #${orderId}`);
            // window.location.href = `order_detail.php?id=${orderId}`;
        }

        document.querySelectorAll('.rating-stars label').forEach(star => {
            star.addEventListener('click', function() {
                const rating = this.getAttribute('for').replace('star', '');
                document.querySelector(`input[name="rating"][value="${rating}"]`).checked = true;
            });
        });
    </script>
</body>
</html>