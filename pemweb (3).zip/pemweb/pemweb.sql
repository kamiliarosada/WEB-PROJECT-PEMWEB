-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 08, 2025 at 12:39 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pemweb`
--

-- --------------------------------------------------------

--
-- Table structure for table `articles`
--

CREATE TABLE `articles` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `service_category_id` int(11) DEFAULT NULL,
  `author_id` int(11) NOT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `is_published` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `articles`
--

INSERT INTO `articles` (`id`, `title`, `content`, `category_id`, `service_category_id`, `author_id`, `image_url`, `is_published`, `created_at`, `updated_at`) VALUES
(1, 'How to Maintain Your Smartphone', 'Content about smartphone maintenance...', NULL, NULL, 1, NULL, 1, '2025-05-30 06:53:45', '2025-05-30 06:53:45'),
(2, 'Common Refrigerator Problems', 'Content about refrigerator issues...', NULL, NULL, 1, NULL, 1, '2025-05-30 06:53:45', '2025-05-30 06:53:45'),
(3, 'Basic Plumbing Tips', 'Content about plumbing maintenance...', NULL, NULL, 1, NULL, 1, '2025-05-30 06:53:45', '2025-06-07 08:03:29'),
(4, 'Electrical Safety at Home', 'Content about electrical safety...', NULL, NULL, 1, NULL, 1, '2025-05-30 06:53:45', '2025-06-07 05:40:52');

-- --------------------------------------------------------

--
-- Table structure for table `article_ratings`
--

CREATE TABLE `article_ratings` (
  `id` int(11) NOT NULL,
  `article_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `rating` tinyint(4) NOT NULL CHECK (`rating` between 1 and 5),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `chat_conversations`
--

CREATE TABLE `chat_conversations` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `technician_id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `chat_messages`
--

CREATE TABLE `chat_messages` (
  `id` int(11) NOT NULL,
  `conversation_id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `technician_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `rating` int(11) NOT NULL CHECK (`rating` between 1 and 5),
  `comment` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `user_id`, `technician_id`, `order_id`, `rating`, `comment`, `created_at`) VALUES
(1, 7, 19, 13, 5, '', '2025-06-08 10:19:01'),
(2, 7, 19, 10, 5, '', '2025-06-08 10:19:31');

-- --------------------------------------------------------

--
-- Table structure for table `item_types`
--

CREATE TABLE `item_types` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `service_category_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `technician_id` int(11) DEFAULT NULL,
  `customer_name` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `address` text NOT NULL,
  `device` varchar(100) NOT NULL,
  `service_date` date NOT NULL,
  `service_time` varchar(50) NOT NULL,
  `notes` text DEFAULT NULL,
  `item_type_id` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `status` enum('pending','processing','completed','cancelled') DEFAULT 'pending',
  `total_amount` decimal(10,2) DEFAULT NULL,
  `feedback_id` int(11) DEFAULT NULL,
  `is_verified` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `technician_id`, `customer_name`, `phone`, `address`, `device`, `service_date`, `service_time`, `notes`, `item_type_id`, `description`, `status`, `total_amount`, `feedback_id`, `is_verified`, `created_at`, `updated_at`) VALUES
(7, 7, 3, '', '', '', '', '0000-00-00', '', NULL, NULL, 'Perbaikan gayung lope lope\nNama Pelanggan: intan\nTelepon: 08543215678\nAlamat: jakarte\nTanggal: 2025-06-28\nWaktu: 08:00-10:00\nCatatan: tak de', 'pending', 250000.00, NULL, 1, '2025-06-08 07:50:16', '2025-06-08 10:31:00'),
(8, 7, 3, '', '', '', '', '0000-00-00', '', NULL, NULL, 'Perbaikan gayung lope lope\nNama Pelanggan: tan\nTelepon: 234567890\nAlamat: pulu pulu\nTanggal: 2025-06-26\nWaktu: 10:00-12:00\nCatatan: cek 12 3 cek', 'pending', 250000.00, NULL, 1, '2025-06-08 08:09:09', '2025-06-08 10:30:59'),
(9, 7, 4, '', '', '', '', '0000-00-00', '', NULL, NULL, 'Perbaikan y\nNama Pelanggan: iki\nTelepon: 08483727777\nAlamat: y\nTanggal: 2025-06-25\nWaktu: 08:00-10:00\nCatatan: y', 'pending', 400000.00, NULL, 1, '2025-06-08 08:36:34', '2025-06-08 10:30:58'),
(10, 7, 19, '', '', '', '', '0000-00-00', '', NULL, NULL, 'Perbaikan t\nNama Pelanggan: g\nTelepon: 8888888888\nAlamat: t\nTanggal: 2025-06-10\nWaktu: 08:00-10:00\nCatatan: t', 'completed', 280000.00, NULL, 1, '2025-06-08 08:39:56', '2025-06-08 10:30:57'),
(11, 7, 19, '', '', '', '', '0000-00-00', '', NULL, NULL, 'Perbaikan g\nNama Pelanggan: y\nTelepon: 8765432455\nAlamat: g\nTanggal: 2025-06-12\nWaktu: 10:00-12:00\nCatatan: g', 'completed', 280000.00, NULL, 1, '2025-06-08 08:40:40', '2025-06-08 10:30:56'),
(12, 7, 19, '', '', '', '', '0000-00-00', '', NULL, NULL, 'Perbaikan y\nNama Pelanggan: tan\nTelepon: 081234156789\nAlamat: y\nTanggal: 2025-06-11\nWaktu: 10:00-12:00\nCatatan: y', 'completed', 280000.00, NULL, 1, '2025-06-08 09:01:13', '2025-06-08 10:30:55'),
(13, 7, 19, 'intan', '08512345678', 'y', 'y', '2025-06-26', '08:00-10:00', 'y', NULL, 'Perbaikan y\nNama Pelanggan: intan\nTelepon: 08512345678\nAlamat: y\nTanggal: 2025-06-26\nWaktu: 08:00-10:00\nCatatan: y', 'completed', 280000.00, NULL, 1, '2025-06-08 09:54:34', '2025-06-08 10:30:54');

-- --------------------------------------------------------

--
-- Table structure for table `service_categories`
--

CREATE TABLE `service_categories` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `service_categories`
--

INSERT INTO `service_categories` (`id`, `name`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Kulkas', 'Perbaikan segala merek kulkas 1 pintu, 2 pintu, side by side, dan showcase. Termasuk ganti kompresor, thermostat, dan kebocoran freon.', '2025-06-08 06:07:22', '2025-06-08 06:07:22'),
(2, 'AC', 'Service berkala, isi freon, perbaikan outdoor/indoor unit, ganti kapasitor, hingga pemasangan AC baru untuk rumah dan kantor.', '2025-06-08 06:07:22', '2025-06-08 06:07:22'),
(3, 'Mesin Cuci', 'Perbaikan mesin cuci top loading, front loading, 1 tabung/2 tabung. Ganti bearing, seal, pompa drain, dan modul kontrol.', '2025-06-08 06:07:22', '2025-06-08 06:07:22'),
(4, 'TV', 'Servis TV LED, OLED, QLED, dan Smart TV. Perbaikan layar, backlight, power supply, dan masalah software.', '2025-06-08 06:07:22', '2025-06-08 06:07:22'),
(5, 'Laptop', 'Upgrade hardware, ganti LCD, keyboard, baterai, perbaikan motherboard, cleaning, dan instalasi sistem operasi.', '2025-06-08 06:07:22', '2025-06-08 06:07:22'),
(6, 'Hp', 'perbaiki apalah apalah', '2025-06-08 10:33:12', '2025-06-08 10:33:12');

-- --------------------------------------------------------

--
-- Table structure for table `technicians`
--

CREATE TABLE `technicians` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `specialization` varchar(100) DEFAULT NULL,
  `experience_years` int(11) DEFAULT NULL,
  `certification` varchar(255) DEFAULT NULL,
  `rate` decimal(10,2) DEFAULT 0.00,
  `is_verified` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `technicians`
--

INSERT INTO `technicians` (`id`, `user_id`, `specialization`, `experience_years`, `certification`, `rate`, `is_verified`, `created_at`, `updated_at`) VALUES
(1, 50, 'Kulkas', 5, 'Sertifikasi Teknisi Kulkas Berpengalaman', 150000.00, 1, '2025-06-08 06:50:06', '2025-06-08 06:50:06'),
(2, 51, 'AC', 4, 'Sertifikasi Teknisi AC Level Advance', 175000.00, 1, '2025-06-08 06:50:06', '2025-06-08 06:50:06'),
(3, 52, 'Mesin Cuci', 3, 'Sertifikasi Resmi Teknisi Mesin Cuci', 125000.00, 1, '2025-06-08 06:50:06', '2025-06-08 06:50:06'),
(4, 53, 'TV', 6, 'Sertifikasi Master Teknisi TV', 200000.00, 1, '2025-06-08 06:50:06', '2025-06-08 06:50:06'),
(5, 54, 'Laptop', 5, 'Sertifikasi Teknisi Laptop Internasional', 225000.00, 1, '2025-06-08 06:50:06', '2025-06-08 06:50:06'),
(6, 55, 'Kulkas', 2, 'Sertifikasi Dasar Perbaikan Kulkas', 120000.00, 1, '2025-06-08 06:50:06', '2025-06-08 06:50:06'),
(7, 56, 'AC', 7, 'Sertifikasi Master AC + Pemasangan', 250000.00, 1, '2025-06-08 06:50:06', '2025-06-08 06:50:06'),
(8, 57, 'Mesin Cuci', 4, 'Sertifikasi Mesin Cuci Multimerek', 140000.00, 1, '2025-06-08 06:50:06', '2025-06-08 06:50:06'),
(9, 58, 'TV', 3, 'Sertifikasi Teknisi Smart TV', 180000.00, 1, '2025-06-08 06:50:06', '2025-06-08 06:50:06'),
(10, 59, 'Laptop', 6, 'Sertifikasi Advanced Chip-Level Laptop', 240000.00, 1, '2025-06-08 06:50:06', '2025-06-08 06:50:06'),
(11, 60, 'Kulkas', 5, 'Sertifikasi Teknisi Kulkas Komersial', 160000.00, 1, '2025-06-08 06:50:06', '2025-06-08 06:50:06'),
(12, 61, 'AC', 4, 'Sertifikasi Teknisi AC Central', 190000.00, 1, '2025-06-08 06:50:06', '2025-06-08 06:50:06'),
(13, 62, 'Mesin Cuci', 2, 'Sertifikasi Dasar Mesin Cuci Modern', 110000.00, 1, '2025-06-08 06:50:06', '2025-06-08 06:50:06'),
(14, 63, 'TV', 5, 'Sertifikasi Teknisi TV Proyektor', 210000.00, 1, '2025-06-08 06:50:06', '2025-06-08 06:50:06'),
(15, 64, 'Laptop', 3, 'Sertifikasi Teknisi Laptop Gaming', 190000.00, 1, '2025-06-08 06:50:06', '2025-06-08 06:50:06'),
(16, 65, 'Kulkas', 6, 'Sertifikasi Master Kulkas Industri', 180000.00, 1, '2025-06-08 06:50:06', '2025-06-08 06:50:06'),
(17, 66, 'AC', 4, 'Sertifikasi Teknisi AC Inverter', 170000.00, 1, '2025-06-08 06:50:06', '2025-06-08 06:50:06'),
(18, 67, 'Mesin Cuci', 5, 'Sertifikasi Mesin Cuci Otomatis', 150000.00, 1, '2025-06-08 06:50:06', '2025-06-08 06:50:06'),
(19, 68, 'TV', 2, 'Sertifikasi Dasar TV Digital', 140000.00, 1, '2025-06-08 06:50:06', '2025-06-08 06:50:06'),
(20, 69, 'Laptop', 4, 'Sertifikasi Teknisi Laptop Premium', 200000.00, 1, '2025-06-08 06:50:06', '2025-06-08 06:50:06');

-- --------------------------------------------------------

--
-- Table structure for table `technician_skills`
--

CREATE TABLE `technician_skills` (
  `user_id` int(11) NOT NULL,
  `service_category_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `technician_skills`
--

INSERT INTO `technician_skills` (`user_id`, `service_category_id`) VALUES
(50, 1),
(50, 2),
(51, 1),
(51, 3),
(52, 4),
(52, 5),
(53, 4),
(53, 5),
(54, 1),
(54, 2),
(54, 3),
(55, 2),
(55, 3),
(56, 1),
(56, 4),
(57, 3),
(57, 5),
(58, 2),
(58, 4),
(58, 5),
(59, 1),
(59, 2),
(60, 3),
(60, 4),
(61, 2),
(61, 5),
(62, 1),
(62, 3),
(62, 5),
(63, 3),
(63, 4),
(64, 2),
(64, 5),
(65, 1),
(65, 2),
(65, 4),
(66, 1),
(66, 4),
(67, 3),
(67, 5),
(68, 2),
(68, 3),
(68, 5),
(69, 1),
(69, 4);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  `gender` enum('male','female','other') DEFAULT NULL,
  `profile_picture` varchar(255) DEFAULT NULL,
  `role` enum('admin','technician','user') DEFAULT 'user',
  `is_verified` tinyint(1) DEFAULT 0,
  `is_suspended` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `email`, `password`, `phone`, `country`, `gender`, `profile_picture`, `role`, `is_verified`, `is_suspended`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'admin', 'admin@locals.com', 'admin', '', '', '', NULL, 'admin', 1, 0, '2025-05-30 06:53:45', '2025-06-07 06:20:07'),
(4, 'Mike Johnson', 'mikej', 'mike@example.com', 'mikej', '555123456', 'Canada', 'male', NULL, 'technician', 1, 0, '2025-05-30 06:53:45', '2025-06-06 10:43:40'),
(6, 'ocha', 'ocha', 'ocha@gmail', 'ocha', '12345567889', 'Indonesia', 'female', 'semangka.jpg', 'user', 1, 0, '2025-06-03 05:27:10', '2025-06-08 10:35:03'),
(7, 'tan', 'tan', 'tan@gmail.com', '123', '234567890', 'Indonesia', 'male', 'DIAGRAM-kepribadian-manusia.jpg', 'user', 1, 0, '2025-06-06 10:42:48', '2025-06-08 10:32:26'),
(9, 'salsa', 'salsa', 'salsa@unram.com', '123456', NULL, NULL, NULL, NULL, 'admin', 1, 0, '2025-06-07 05:28:14', '2025-06-07 05:28:14'),
(50, 'Budi Setiawan', 'tech_budi', 'budi.setiawan@example.com', 'password123', '081234567890', 'Indonesia', 'male', NULL, 'technician', 1, 0, '2025-06-08 06:07:22', '2025-06-08 06:07:22'),
(51, 'Siti Nurhaliza', 'siti_tech', 'siti.nurhaliza@example.com', 'password123', '082345678901', 'Indonesia', 'female', NULL, 'technician', 1, 0, '2025-06-08 06:07:22', '2025-06-08 06:07:22'),
(52, 'Agus Kurniawan', 'agus_elektro', 'agus.kurniawan@example.com', 'password123', '083456789012', 'Indonesia', 'male', NULL, 'technician', 1, 0, '2025-06-08 06:07:22', '2025-06-08 06:07:22'),
(53, 'Dewi Anggraeni', 'dewi_repair', 'dewi.anggraeni@example.com', 'password123', '084567890123', 'Indonesia', 'female', NULL, 'technician', 1, 0, '2025-06-08 06:07:22', '2025-06-08 06:07:22'),
(54, 'Joko Susilo', 'joko_handyman', 'joko.susilo@example.com', 'password123', '085678901234', 'Indonesia', 'male', NULL, 'technician', 1, 0, '2025-06-08 06:07:22', '2025-06-08 06:07:22'),
(55, 'Ani Wijayanti', 'ani_techno', 'ani.wijayanti@example.com', 'password123', '086789012345', 'Indonesia', 'female', NULL, 'technician', 1, 0, '2025-06-08 06:07:22', '2025-06-08 06:07:22'),
(56, 'Eko Pratama', 'eko_fix', 'eko.pratama@example.com', 'password123', '087890123456', 'Indonesia', 'male', NULL, 'technician', 1, 0, '2025-06-08 06:07:22', '2025-06-08 06:07:22'),
(57, 'Rina Amelia', 'rina_tech', 'rina.amelia@example.com', 'password123', '088901234567', 'Indonesia', 'female', NULL, 'technician', 1, 0, '2025-06-08 06:07:22', '2025-06-08 06:07:22'),
(58, 'Hendra Kurnia', 'hendra_service', 'hendra.kurnia@example.com', 'password123', '089012345678', 'Indonesia', 'male', NULL, 'technician', 1, 0, '2025-06-08 06:07:22', '2025-06-08 06:07:22'),
(59, 'Linda Permata', 'linda_fixit', 'linda.permata@example.com', 'password123', '081123456789', 'Indonesia', 'female', NULL, 'technician', 1, 0, '2025-06-08 06:07:22', '2025-06-08 06:07:22'),
(60, 'Ahmad Yusuf', 'ahmad_repair', 'ahmad.yusuf@example.com', 'password123', '082234567890', 'Indonesia', 'male', NULL, 'technician', 1, 0, '2025-06-08 06:07:22', '2025-06-08 06:07:22'),
(61, 'Yuni Kartika', 'yuni_techie', 'yuni.kartika@example.com', 'password123', '083345678901', 'Indonesia', 'female', NULL, 'technician', 1, 0, '2025-06-08 06:07:22', '2025-06-08 06:07:22'),
(62, 'Rudi Cahyadi', 'rudi_servis', 'rudi.cahyadi@example.com', 'password123', '084456789012', 'Indonesia', 'male', NULL, 'technician', 1, 0, '2025-06-08 06:07:22', '2025-06-08 06:07:22'),
(63, 'Maya Indah', 'maya_tech', 'maya.indah@example.com', 'password123', '085567890123', 'Indonesia', 'female', NULL, 'technician', 1, 0, '2025-06-08 06:07:22', '2025-06-08 06:07:22'),
(64, 'Fajar Nugroho', 'fajar_elektro', 'fajar.nugroho@example.com', 'password123', '086678901234', 'Indonesia', 'male', NULL, 'technician', 1, 0, '2025-06-08 06:07:22', '2025-06-08 06:07:22'),
(65, 'Dian Puspita', 'dian_fix', 'dian.puspita@example.com', 'password123', '087789012345', 'Indonesia', 'female', NULL, 'technician', 1, 0, '2025-06-08 06:07:22', '2025-06-08 06:07:22'),
(66, 'Irfan Mahendra', 'irfan_tech', 'irfan.mahendra@example.com', 'password123', '088890123456', 'Indonesia', 'male', NULL, 'technician', 1, 0, '2025-06-08 06:07:22', '2025-06-08 06:07:22'),
(67, 'Nur Aisyah', 'nur_repair', 'nur.aisyah@example.com', 'password123', '089901234567', 'Indonesia', 'female', NULL, 'technician', 1, 0, '2025-06-08 06:07:22', '2025-06-08 06:07:22'),
(68, 'Adi Saputro', 'adi_service', 'adi.saputro@example.com', 'password123', '081012345678', 'Indonesia', 'male', NULL, 'technician', 1, 0, '2025-06-08 06:07:22', '2025-06-08 06:07:22'),
(69, 'Ratna Wulandari', 'ratna_techie', 'ratna.wulandari@example.com', 'password123', '082123456789', 'Indonesia', 'female', NULL, 'technician', 1, 0, '2025-06-08 06:07:22', '2025-06-08 06:07:22');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `author_id` (`author_id`),
  ADD KEY `service_category_id` (`service_category_id`);

--
-- Indexes for table `article_ratings`
--
ALTER TABLE `article_ratings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `article_id` (`article_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `chat_conversations`
--
ALTER TABLE `chat_conversations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `technician_id` (`technician_id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indexes for table `chat_messages`
--
ALTER TABLE `chat_messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `conversation_id` (`conversation_id`),
  ADD KEY `sender_id` (`sender_id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `technician_id` (`technician_id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indexes for table `item_types`
--
ALTER TABLE `item_types`
  ADD PRIMARY KEY (`id`),
  ADD KEY `service_category_id` (`service_category_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `technician_id` (`technician_id`),
  ADD KEY `item_type_id` (`item_type_id`),
  ADD KEY `fk_feedback` (`feedback_id`);

--
-- Indexes for table `service_categories`
--
ALTER TABLE `service_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `technicians`
--
ALTER TABLE `technicians`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `technician_skills`
--
ALTER TABLE `technician_skills`
  ADD PRIMARY KEY (`user_id`,`service_category_id`),
  ADD KEY `service_category_id` (`service_category_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `articles`
--
ALTER TABLE `articles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `article_ratings`
--
ALTER TABLE `article_ratings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `chat_conversations`
--
ALTER TABLE `chat_conversations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `chat_messages`
--
ALTER TABLE `chat_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `item_types`
--
ALTER TABLE `item_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `service_categories`
--
ALTER TABLE `service_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `technicians`
--
ALTER TABLE `technicians`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `articles`
--
ALTER TABLE `articles`
  ADD CONSTRAINT `articles_ibfk_1` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `articles_ibfk_2` FOREIGN KEY (`service_category_id`) REFERENCES `service_categories` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `article_ratings`
--
ALTER TABLE `article_ratings`
  ADD CONSTRAINT `article_ratings_ibfk_1` FOREIGN KEY (`article_id`) REFERENCES `articles` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `article_ratings_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `chat_conversations`
--
ALTER TABLE `chat_conversations`
  ADD CONSTRAINT `chat_conversations_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `chat_conversations_ibfk_2` FOREIGN KEY (`technician_id`) REFERENCES `technicians` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `chat_conversations_ibfk_3` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_conversation_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`),
  ADD CONSTRAINT `fk_conversation_technician` FOREIGN KEY (`technician_id`) REFERENCES `technicians` (`user_id`),
  ADD CONSTRAINT `fk_conversation_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `chat_messages`
--
ALTER TABLE `chat_messages`
  ADD CONSTRAINT `chat_messages_ibfk_1` FOREIGN KEY (`conversation_id`) REFERENCES `chat_conversations` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `chat_messages_ibfk_2` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_message_conversation` FOREIGN KEY (`conversation_id`) REFERENCES `chat_conversations` (`id`),
  ADD CONSTRAINT `fk_message_sender` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `feedback`
--
ALTER TABLE `feedback`
  ADD CONSTRAINT `feedback_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `feedback_ibfk_2` FOREIGN KEY (`technician_id`) REFERENCES `technicians` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `feedback_ibfk_3` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `item_types`
--
ALTER TABLE `item_types`
  ADD CONSTRAINT `item_types_ibfk_1` FOREIGN KEY (`service_category_id`) REFERENCES `service_categories` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `fk_feedback` FOREIGN KEY (`feedback_id`) REFERENCES `feedback` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`technician_id`) REFERENCES `technicians` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `orders_ibfk_3` FOREIGN KEY (`item_type_id`) REFERENCES `item_types` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `technicians`
--
ALTER TABLE `technicians`
  ADD CONSTRAINT `technicians_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `technician_skills`
--
ALTER TABLE `technician_skills`
  ADD CONSTRAINT `technician_skills_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `technician_skills_ibfk_2` FOREIGN KEY (`service_category_id`) REFERENCES `service_categories` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
