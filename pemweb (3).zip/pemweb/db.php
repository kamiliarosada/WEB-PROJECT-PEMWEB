<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "pemweb";

$conn = mysqli_connect($host, $user, $pass, $db);
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
function getTechnicianCategories() {
    global $conn;
    $categories = [];
    $result = $conn->query("SELECT DISTINCT specialization FROM technicians");
    while ($row = $result->fetch_assoc()) {
        $categories[] = $row['specialization'];
    }
    return $categories;
}
?>
