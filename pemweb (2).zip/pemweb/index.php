<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'user') {
    header('Location: login.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>ReparoTech - Solusi Perbaikan Elektronik</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: linear-gradient(135deg, #f5f7fa 0%, #e4e8f0 100%);
      color: #333;
      line-height: 1.6;
      min-height: 100vh;
    }
    
    /* Header Navigation */
    .nav-container {
      display: flex;
      justify-content: space-between;
      align-items: center;
      max-width: 1200px;
      margin: 0 auto;
      padding: 15px 20px;
      background: white;
      box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }
    
    .logo {
      display: flex;
      align-items: center;
      gap: 10px;
      font-size: 1.5rem;
      font-weight: 700;
      color: #2563eb;
      text-decoration: none;
    }
    
    .logo i {
      font-size: 1.8rem;
    }
    
    .nav-links {
      display: flex;
      gap: 25px;
    }
    
    .nav-links a {
      text-decoration: none;
      color: #1e293b;
      font-weight: 500;
      transition: color 0.3s ease;
      display: flex;
      align-items: center;
      gap: 5px;
    }
    
    .nav-links a:hover {
      color: #2563eb;
    }
    
    .nav-links a.active {
      color: #2563eb;
      font-weight: 600;
    }
    
    .user-actions {
      display: flex;
      align-items: center;
      gap: 15px;
    }
    
    .user-actions a {
      text-decoration: none;
      color: #1e293b;
      transition: color 0.3s ease;
    }
    
    .user-actions a:hover {
      color: #2563eb;
    }
    
    .user-profile {
      display: flex;
      align-items: center;
      gap: 8px;
      cursor: pointer;
      position: relative;
    }
    
    .user-img {
      width: 35px;
      height: 35px;
      border-radius: 50%;
      background: #2563eb;
      color: white;
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 600;
    }
    
    .dropdown-menu {
      position: absolute;
      top: 45px;
      right: 0;
      background: white;
      border-radius: 8px;
      box-shadow: 0 5px 15px rgba(0,0,0,0.1);
      padding: 10px 0;
      min-width: 180px;
      display: none;
      z-index: 100;
    }
    
    .dropdown-menu a {
      display: block;
      padding: 8px 15px;
      color: #334155;
      text-decoration: none;
      transition: background 0.3s;
    }
    
    .dropdown-menu a:hover {
      background: #f1f5f9;
    }
    
    .user-profile:hover .dropdown-menu {
      display: block;
    }
    
    .container {
      max-width: 1200px;
      margin: 30px auto;
      background: white;
      border-radius: 15px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
      overflow: hidden;
    }
    
    .hero-section {
      background: linear-gradient(90deg, #2563eb 0%, #1d4ed8 100%);
      color: white;
      padding: 60px 30px;
      text-align: center;
      position: relative;
      overflow: hidden;
    }
    
    .hero-section::before {
      content: "";
      position: absolute;
      top: -50%;
      left: -50%;
      width: 200%;
      height: 200%;
      background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
      transform: rotate(30deg);
    }
    
    .hero-section h1 {
      font-size: 2.8rem;
      margin-bottom: 20px;
      text-shadow: 2px 2px 4px rgba(0,0,0,0.2);
      position: relative;
    }
    
    .hero-section p {
      font-size: 1.2rem;
      max-width: 700px;
      margin: 0 auto 30px;
      position: relative;
      opacity: 0.9;
    }
    
    .why-choose-us {
      padding: 50px 30px;
      text-align: center;
    }
    
    .why-choose-us h2 {
      font-size: 2.2rem;
      color: #1e40af;
      margin-bottom: 40px;
    }
    
    .features {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 30px;
      margin-top: 40px;
    }
    
    .feature-card {
      background: white;
      border-radius: 12px;
      padding: 30px;
      box-shadow: 0 5px 15px rgba(0,0,0,0.05);
      transition: transform 0.3s ease;
    }
    
    .feature-card:hover {
      transform: translateY(-10px);
    }
    
    .feature-icon {
      font-size: 2.5rem;
      color: #2563eb;
      margin-bottom: 20px;
    }
    
    .feature-card h3 {
      color: #1e40af;
      margin-bottom: 15px;
      font-size: 1.4rem;
    }
    
    .feature-card p {
      color: #4b5563;
      line-height: 1.7;
    }
    
    .cta-section {
      background: #f8fafc;
      padding: 60px 30px;
      text-align: center;
      border-top: 1px solid #e2e8f0;
    }
    
    .cta-section h2 {
      font-size: 2rem;
      color: #1e40af;
      margin-bottom: 20px;
    }
    
    .cta-section p {
      max-width: 600px;
      margin: 0 auto 30px;
      color: #4b5563;
      font-size: 1.1rem;
    }
    
    .btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      padding: 12px 30px;
      background: linear-gradient(90deg, #2563eb 0%, #1d4ed8 100%);
      color: white;
      text-decoration: none;
      border-radius: 8px;
      font-weight: 600;
      transition: all 0.3s ease;
      border: none;
      cursor: pointer;
      box-shadow: 0 4px 10px rgba(37, 99, 235, 0.3);
      font-size: 1rem;
    }
    
    .btn:hover {
      background: linear-gradient(90deg, #1d4ed8 0%, #1e40af 100%);
      box-shadow: 0 6px 15px rgba(37, 99, 235, 0.4);
      transform: translateY(-2px);
    }
    
    .btn i {
      margin-right: 8px;
    }
    
    .btn-outline {
      background: transparent;
      border: 2px solid #2563eb;
      color: #2563eb;
      box-shadow: none;
      margin-left: 15px;
    }
    
    .btn-outline:hover {
      background: #2563eb;
      color: white;
    }
    
    footer {
      text-align: center;
      padding: 30px;
      background: #1e293b;
      color: #cbd5e1;
    }
    
    .footer-content {
      max-width: 600px;
      margin: 0 auto;
    }
    
    .social-icons {
      display: flex;
      justify-content: center;
      gap: 20px;
      margin: 20px 0;
    }
    
    .social-icons a {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 40px;
      height: 40px;
      background: #334155;
      border-radius: 50%;
      color: white;
      transition: all 0.3s ease;
    }
    
    .social-icons a:hover {
      background: #2563eb;
      transform: translateY(-3px);
    }
    
    .copyright {
      margin-top: 20px;
      font-size: 0.9rem;
      opacity: 0.8;
    }
    
    @media (max-width: 768px) {
      .hero-section h1 {
        font-size: 2.2rem;
      }
      
      .nav-links {
        display: none;
      }
      
      .btn {
        width: 100%;
        margin-bottom: 10px;
      }
      
      .btn-outline {
        margin-left: 0;
      }
    }
    
    @media (max-width: 480px) {
      .hero-section {
        padding: 40px 20px;
      }
      
      .hero-section h1 {
        font-size: 1.8rem;
      }
      
      .hero-section p {
        font-size: 1rem;
      }
      
      .why-choose-us h2 {
        font-size: 1.8rem;
      }
    }
  </style>
</head>
<body>

  <!-- Navigation Bar -->
  <div class="nav-container">
    <a href="../index.php" class="logo">
      <i class="fas fa-tools"></i>
      <span>ReparoTech</span>
    </a>
    
    <div class="nav-links">
      <a href="index.php"><i class="fas fa-home"></i> Beranda</a>
      <a href="#" class="active"><i class="fas fa-info-circle"></i> Tentang Kami</a>
      <a href="users/service.php"><i class="fas fa-headset"></i> Layanan</a>
      <a href="users/pesanan.php"><i class="fas fa-clipboard-list"></i> Pesanan</a>
      <a href="users/artikel.php"><i class="fas fa-clipboard-list"></i> Artikel</a>
    </div>
    
    <div class="user-actions">
      <div class="user-profile">
        <div class="user-img"><?php echo strtoupper(substr($_SESSION['username'], 0, 1)); ?></div>
        <span><?php echo htmlspecialchars($_SESSION['username']); ?></span>
        <div class="dropdown-menu">
          <a href="users/profile.php"><i class="fas fa-user"></i> Profil</a>
          <a href="users/riwayat-pesanan.php"><i class="fas fa-history"></i> Riwayat</a>
          <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
      </div>
    </div>
  </div>

  <div class="container">
    <section class="hero-section">
      <h1>ReparoTech - Solusi Perbaikan Elektronik Terpercaya</h1>
      <p>Kami hadir untuk memberikan solusi terbaik untuk semua masalah perangkat elektronik Anda dengan teknisi profesional dan layanan berkualitas tinggi.</p>
      <a href="service.php" class="btn"><i class="fas fa-tools"></i> Lihat Layanan Kami</a>
      <a href="pesanan.php" class="btn btn-outline"><i class="fas fa-calendar-check"></i> Buat Pesanan</a>
    </section>
    
    <section class="why-choose-us">
      <h2>Mengapa Harus Memilih ReparoTech?</h2>
      
      <div class="features">
        <div class="feature-card">
          <div class="feature-icon">
            <i class="fas fa-certificate"></i>
          </div>
          <h3>Teknisi Bersertifikat</h3>
          <p>Tim teknisi kami telah tersertifikasi dan memiliki pengalaman luas dalam menangani berbagai masalah elektronik.</p>
        </div>
        
        <div class="feature-card">
          <div class="feature-icon">
            <i class="fas fa-shield-alt"></i>
          </div>
          <h3>Garansi Resmi</h3>
          <p>Kami memberikan garansi 90 hari untuk semua perbaikan yang kami lakukan sebagai bukti kepercayaan kami.</p>
        </div>
        
        <div class="feature-card">
          <div class="feature-icon">
            <i class="fas fa-bolt"></i>
          </div>
          <h3>Layanan Cepat</h3>
          <p>Proses perbaikan yang efisien dengan waktu penyelesaian yang lebih cepat tanpa mengorbankan kualitas.</p>
        </div>
        
        <div class="feature-card">
          <div class="feature-icon">
            <i class="fas fa-dollar-sign"></i>
          </div>
          <h3>Harga Terjangkau</h3>
          <p>Biaya perbaikan yang transparan dan kompetitif tanpa ada biaya tersembunyi.</p>
        </div>
      </div>
    </section>
    
    <section class="cta-section">
      <h2>Siap Memperbaiki Perangkat Anda?</h2>
      <p>Pesan sekarang dan dapatkan pengalaman service elektronik terbaik dengan tim profesional kami.</p>
      <a href="pesanan.php" class="btn"><i class="fas fa-calendar-check"></i> Buat Pesanan Sekarang</a>
    </section>
  </div>
  
  <footer>
    <div class="footer-content">
      <h3>ReparoTech</h3>
      <p>Solusi perbaikan elektronik terbaik dengan kualitas dan kepercayaan sebagai prioritas utama kami.</p>
      <div class="social-icons">
        <a href="#"><i class="fab fa-facebook-f"></i></a>
        <a href="#"><i class="fab fa-twitter"></i></a>
        <a href="#"><i class="fab fa-instagram"></i></a>
        <a href="#"><i class="fab fa-whatsapp"></i></a>
      </div>
      <p class="copyright">&copy; 2023 ReparoTech. All Rights Reserved.</p>
    </div>
  </footer>
</body>
</html>