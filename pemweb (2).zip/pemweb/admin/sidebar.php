<?php
/**
 * NEW SIDEBAR NAVIGATION SYSTEM
 * - Menggunakan absolute path yang konsisten
 * - Mendukung deep linking
 * - Auto-detect active menu
 * - Struktur data terpusat
 */

// Configurasi dasar
$admin_root = '/pemweb/admin/'; // Sesuaikan dengan struktur Anda
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://';
$base_url = $protocol . $_SERVER['HTTP_HOST'] . $admin_root;

// Daftar menu dengan struktur terpusat
$menu_items = [
    'dashboard' => [
        'title' => 'Dashboard',
        'icon' => 'speedometer2',
        'url' => 'dashboard.php',
        'children' => []
    ],
    'user_management' => [
        'title' => 'User Management',
        'icon' => 'people',
        'url' => 'users/index.php',
        'children' => []
    ],
    'technician_management' => [
        'title' => 'Technician Management',
        'icon' => 'tools',
        'url' => 'technicians/index.php',
        'children' => []
    ],
    'content_management' => [
        'title' => 'Content Management',
        'icon' => 'file-earmark-text',
        'url' => 'articles/index.php',
        'children' => []
    ],
    'service_management' => [
        'title' => 'Service Management',
        'icon' => 'list-check',
        'url' => 'item_types/index.php',
        'children' => [
            'categories' => [
                'title' => 'Service Categories',
                'icon' => 'tags',
                'url' => 'categories/index.php'
            ]
        ]
    ],
    'order_management' => [
        'title' => 'Order Management',
        'icon' => 'cart',
        'url' => 'orders/index.php',
        'children' => []
    ],
    'reports' => [
        'title' => 'Reports',
        'icon' => 'graph-up',
        'url' => 'stats/index.php',
        'children' => []
    ]
];

// Fungsi untuk menentukan menu aktif
function isMenuActive($menuUrl, $currentUri) {
    $menuPath = parse_url($menuUrl, PHP_URL_PATH);
    $currentPath = parse_url($currentUri, PHP_URL_PATH);
    
    // Exact match
    if ($menuPath === $currentPath) {
        return true;
    }
    
    // Partial match untuk parent menu
    if (strpos($currentPath, dirname($menuPath)) === 0) {
        return true;
    }
    
    return false;
}

$current_uri = $_SERVER['REQUEST_URI'];
?>

<!-- HTML Structure -->
<div class="list-group" id="newSideNav">
    <?php foreach ($menu_items as $key => $menu): ?>
        <?php if (empty($menu['children'])): ?>
            <!-- Single Menu Item -->
            <a href="<?= $base_url . $menu['url'] ?>" 
               class="list-group-item list-group-item-action <?= isMenuActive($base_url . $menu['url'], $current_uri) ? 'active' : '' ?>">
                <i class="bi bi-<?= $menu['icon'] ?>"></i> <?= $menu['title'] ?>
            </a>
        <?php else: ?>
            <!-- Parent Menu with Children -->
            <div class="list-group-item list-group-item-dark">
                <i class="bi bi-<?= $menu['icon'] ?>"></i> <?= $menu['title'] ?>
            </div>
            
            <!-- Parent Link -->
            <a href="<?= $base_url . $menu['url'] ?>" 
               class="list-group-item list-group-item-action <?= isMenuActive($base_url . $menu['url'], $current_uri) ? 'active' : '' ?>">
                <i class="bi bi-<?= $menu['icon'] ?>"></i> Manage <?= str_replace(' Management', '', $menu['title']) ?>
            </a>
            
            <!-- Children -->
            <?php foreach ($menu['children'] as $child): ?>
                <a href="<?= $base_url . $child['url'] ?>" 
                   class="list-group-item list-group-item-action child-item <?= isMenuActive($base_url . $child['url'], $current_uri) ? 'active' : '' ?>">
                    <i class="bi bi-<?= $child['icon'] ?>"></i> <?= $child['title'] ?>
                </a>
            <?php endforeach; ?>
        <?php endif; ?>
    <?php endforeach; ?>
    
    <!-- Profile Management -->
    <div class="list-group-item"></div>
    <a href="<?= $base_url ?>profile/index.php" 
       class="list-group-item list-group-item-action <?= isMenuActive($base_url . 'profile/index.php', $current_uri) ? 'active' : '' ?>">
        <i class="bi bi-person"></i> Manage Profile
    </a>
    
    <!-- Logout -->
    <a href="<?= $base_url ?>../logout.php" class="list-group-item list-group-item-action text-danger">
        <i class="bi bi-box-arrow-right"></i> Logout
    </a>
</div>

<style>
/* Tambahkan indent untuk child items */
.child-item {
    padding-left: 2rem !important;
}
</style>

<script>
// Script untuk handle navigation
document.getElementById('newSideNav').addEventListener('click', function(e) {
    const target = e.target.closest('a');
    if (!target) return;
    
    // Skip logout
    if (target.href.includes('../logout.php')) return;
    
    // Debug URL
    console.log('Navigating to:', target.href);
    
    // Optional: Tambahkan loading indicator
    target.innerHTML = '<i class="bi bi-arrow-repeat"></i> Loading...';
});
</script>