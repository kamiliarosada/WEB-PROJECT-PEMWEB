<?php
session_start();
require_once '../../db.php';

if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../../login.php');
    exit;
}

// Handle actions
if (isset($_GET['action']) && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    
    switch ($_GET['action']) {
        case 'verify':
            $conn->query("UPDATE technicians SET is_verified = 1 WHERE id = $id");
            $_SESSION['success'] = "Technician verified successfully";
            break;
            
        case 'unverify':
            $conn->query("UPDATE technicians SET is_verified = 0 WHERE id = $id");
            $_SESSION['success'] = "Technician unverified successfully";
            break;
            
        case 'delete':
            // First delete the technician record
            $conn->query("DELETE FROM technicians WHERE id = $id");
            // Then update the user role to 'user'
            $userId = $conn->query("SELECT user_id FROM technicians WHERE id = $id")->fetch_assoc()['user_id'];
            if ($userId) {
                $conn->query("UPDATE users SET role = 'user' WHERE id = $userId");
            }
            $_SESSION['success'] = "Technician deleted successfully";
            break;
    }
    
    header('Location: index.php');
    exit;
}

// Get all technicians with user details
$technicians = $conn->query("
    SELECT t.*, u.name, u.email, u.phone, u.profile_picture, u.is_verified as user_verified
    FROM technicians t
    JOIN users u ON t.user_id = u.id
    ORDER BY t.is_verified DESC, u.name
");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Technician Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        .verified-badge {
            color: #28a745;
        }
        .unverified-badge {
            color: #dc3545;
        }
        .action-column {
            width: 150px;
        }
    </style>
</head>
<body>
    <?php include '../navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <div class="row">
            <div class="col-md-3">
                <?php include '../sidebar.php'; ?>
            </div>
            <div class="col-md-9">
                <h2>Technician Management</h2>
                
                <!-- Alert Messages -->
                <?php if (isset($_SESSION['success'])): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?= $_SESSION['success'] ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <?php unset($_SESSION['success']); ?>
                <?php endif; ?>
                
                <?php if (isset($_SESSION['error'])): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?= $_SESSION['error'] ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <?php unset($_SESSION['error']); ?>
                <?php endif; ?>
                
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5>Technician List</h5>
                        <span class="badge bg-primary">
                            Total: <?= $technicians->num_rows ?> technicians
                        </span>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover table-striped">
                                <thead class="table-light">
                                    <tr>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Specialization</th>
                                        <th>Rate</th>
                                        <th>Status</th>
                                        <th class="action-column">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if ($technicians->num_rows > 0): ?>
                                        <?php while($tech = $technicians->fetch_assoc()): ?>
                                        <tr>
                                            <td><?= $tech['id'] ?></td>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <img src="<?= $tech['profile_picture'] ? '../../uploads/profiles/'.$tech['profile_picture'] : 'https://via.placeholder.com/40' ?>" 
                                                         class="rounded-circle me-2" width="40" height="40">
                                                    <div>
                                                        <strong><?= htmlspecialchars($tech['name']) ?></strong><br>
                                                        <small class="text-muted"><?= $tech['email'] ?></small>
                                                    </div>
                                                </div>
                                            </td>
                                            <td><?= htmlspecialchars($tech['specialization']) ?></td>
                                            <td>Rp <?= number_format($tech['rate'], 0, ',', '.') ?></td>
                                            <td>
                                                <?php if ($tech['is_verified'] && $tech['user_verified']): ?>
                                                    <span class="verified-badge"><i class="bi bi-check-circle-fill"></i> Verified</span>
                                                <?php else: ?>
                                                    <span class="unverified-badge"><i class="bi bi-exclamation-circle-fill"></i> Unverified</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <div class="btn-group btn-group-sm" role="group">
                                                    <a href="detail.php?id=<?= $tech['id'] ?>" class="btn btn-info" title="View">
                                                        <i class="bi bi-eye"></i>
                                                    </a>
                                                    <?php if ($tech['is_verified']): ?>
                                                        <a href="?action=unverify&id=<?= $tech['id'] ?>" class="btn btn-warning" title="Unverify">
                                                            <i class="bi bi-x-circle"></i>
                                                        </a>
                                                    <?php else: ?>
                                                        <a href="?action=verify&id=<?= $tech['id'] ?>" class="btn btn-success" title="Verify">
                                                            <i class="bi bi-check-circle"></i>
                                                        </a>
                                                    <?php endif; ?>
                                                    <a href="?action=delete&id=<?= $tech['id'] ?>" class="btn btn-danger" title="Delete" onclick="return confirm('Are you sure to delete this technician?')">
                                                        <i class="bi bi-trash"></i>
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endwhile; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="6" class="text-center text-muted">No technicians found</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>