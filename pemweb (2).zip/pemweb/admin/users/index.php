<?php
session_start();
require_once '../../db.php';

if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../../login.php');
    exit;
}

// Handle user actions
if (isset($_GET['action']) && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    
    // Periksa apakah user mencoba memodifikasi dirinya sendiri
    if ($id == $_SESSION['user_id']) {
        $_SESSION['error'] = 'Anda tidak dapat memodifikasi akun Anda sendiri!';
    } else {
        switch ($_GET['action']) {
            case 'verify':
                $conn->query("UPDATE users SET is_verified = 1 WHERE id = $id");
                // Jika user adalah teknisi, verifikasi juga di tabel technicians
                $technician_check = $conn->query("SELECT id FROM technicians WHERE user_id = $id");
                if ($technician_check->num_rows > 0) {
                    $conn->query("UPDATE technicians SET is_verified = 1 WHERE user_id = $id");
                }
                $_SESSION['message'] = 'User verified successfully';
                break;
                
            case 'suspend':
                $conn->query("UPDATE users SET is_suspended = 1 WHERE id = $id");
                $_SESSION['message'] = 'User suspended successfully';
                break;
                
            case 'unsuspend':
                $conn->query("UPDATE users SET is_suspended = 0 WHERE id = $id");
                $_SESSION['message'] = 'User unsuspended successfully';
                break;
                
            case 'delete':
                // Hapus relasi terlebih dahulu
                $conn->query("DELETE FROM technicians WHERE user_id = $id");
                $conn->query("DELETE FROM feedback WHERE user_id = $id OR technician_id = $id");
                $conn->query("DELETE FROM orders WHERE user_id = $id OR technician_id = $id");
                // Hapus user
                $conn->query("DELETE FROM users WHERE id = $id");
                $_SESSION['message'] = 'User deleted successfully';
                break;
        }
    }
    
    header('Location: index.php');
    exit;
}

// Get all users with pagination
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

$total_users = $conn->query("SELECT COUNT(*) as total FROM users")->fetch_assoc()['total'];
$total_pages = ceil($total_users / $limit);

$users = $conn->query("SELECT * FROM users ORDER BY created_at DESC LIMIT $limit OFFSET $offset");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        .technician-fields {
            margin-top: 20px;
            padding: 15px;
            background-color: #f9f9f9;
            border-radius: 4px;
            border: 1px solid #ddd;
        }
        .required-field::after {
            content: " *";
            color: red;
        }
        .pagination {
            justify-content: center;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <?php include '../navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <div class="row">
            <div class="col-md-3">
                <?php include '../sidebar.php'; ?>
            </div>
            <div class="col-md-9">
                <?php if (isset($_SESSION['message'])): ?>
                    <div class="alert alert-success alert-dismissible fade show">
                        <?= $_SESSION['message'] ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <?php unset($_SESSION['message']); ?>
                <?php endif; ?>
                
                <?php if (isset($_SESSION['error'])): ?>
                    <div class="alert alert-danger alert-dismissible fade show">
                        <?= $_SESSION['error'] ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <?php unset($_SESSION['error']); ?>
                <?php endif; ?>
                
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2>User Management</h2>
                    <a href="#" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addUserModal">
                        <i class="bi bi-plus"></i> Add User
                    </a>
                </div>
                
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Role</th>
                                        <th>Status</th>
                                        <th>Joined</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while($user = $users->fetch_assoc()): ?>
                                    <tr>
                                        <td><?= $user['id'] ?></td>
                                        <td><?= htmlspecialchars($user['name']) ?></td>
                                        <td><?= htmlspecialchars($user['email']) ?></td>
                                        <td>
                                            <span class="badge bg-<?= 
                                                $user['role'] == 'admin' ? 'danger' : 
                                                ($user['role'] == 'technician' ? 'info' : 'secondary')
                                            ?>">
                                                <?= ucfirst($user['role']) ?>
                                            </span>
                                        </td>
                                        <td>
                                            <?php if($user['is_suspended']): ?>
                                                <span class="badge bg-danger">Suspended</span>
                                            <?php elseif(!$user['is_verified']): ?>
                                                <span class="badge bg-warning text-dark">Unverified</span>
                                            <?php else: ?>
                                                <span class="badge bg-success">Active</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?= date('M d, Y', strtotime($user['created_at'])) ?></td>
                                        <td>
                                            <div class="btn-group" role="group">
                                                <?php if(!$user['is_verified'] && $user['role'] !== 'admin'): ?>
                                                    <a href="?action=verify&id=<?= $user['id'] ?>" class="btn btn-sm btn-success" title="Verify">
                                                        <i class="bi bi-check-circle"></i>
                                                    </a>
                                                <?php endif; ?>
                                                
                                                <?php if(!$user['is_suspended'] && $user['role'] !== 'admin'): ?>
                                                    <a href="?action=suspend&id=<?= $user['id'] ?>" class="btn btn-sm btn-warning" title="Suspend">
                                                        <i class="bi bi-lock"></i>
                                                    </a>
                                                <?php elseif($user['is_suspended']): ?>
                                                    <a href="?action=unsuspend&id=<?= $user['id'] ?>" class="btn btn-sm btn-warning" title="Unsuspend">
                                                        <i class="bi bi-unlock"></i>
                                                    </a>
                                                <?php endif; ?>
                                                
                                                <?php if($user['role'] !== 'admin'): ?>
                                                    <a href="?action=delete&id=<?= $user['id'] ?>" class="btn btn-sm btn-danger" title="Delete" onclick="return confirm('Are you sure you want to delete this user?')">
                                                        <i class="bi bi-trash"></i>
                                                    </a>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                            
                            <!-- Pagination -->
                            <nav aria-label="Page navigation">
                                <ul class="pagination">
                                    <?php if($page > 1): ?>
                                        <li class="page-item">
                                            <a class="page-link" href="?page=<?= $page - 1 ?>" aria-label="Previous">
                                                <span aria-hidden="true">&laquo;</span>
                                            </a>
                                        </li>
                                    <?php endif; ?>
                                    
                                    <?php for($i = 1; $i <= $total_pages; $i++): ?>
                                        <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                                            <a class="page-link" href="?page=<?= $i ?>"><?= $i ?></a>
                                        </li>
                                    <?php endfor; ?>
                                    
                                    <?php if($page < $total_pages): ?>
                                        <li class="page-item">
                                            <a class="page-link" href="?page=<?= $page + 1 ?>" aria-label="Next">
                                                <span aria-hidden="true">&raquo;</span>
                                            </a>
                                        </li>
                                    <?php endif; ?>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Add User Modal -->
    <div class="modal fade" id="addUserModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add New User</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="add_user.php" method="POST">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label required-field">Nama Lengkap</label>
                                    <input type="text" name="name" class="form-control" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label required-field">Username</label>
                                    <input type="text" name="username" class="form-control" required>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label required-field">Email</label>
                                    <input type="email" name="email" class="form-control" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label required-field">Role</label>
                                    <select name="role" class="form-select" required id="roleSelect">
                                        <option value="user">User Biasa</option>
                                        <option value="technician">Teknisi</option>
                                        <option value="admin">Admin</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label required-field">Password</label>
                                    <input type="password" name="password" class="form-control" required minlength="6">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label required-field">Confirm Password</label>
                                    <input type="password" name="confirm_password" class="form-control" required minlength="6">
                                </div>
                            </div>
                        </div>
                        
                        <!-- Technician Fields -->
                        <div class="technician-fields" id="technicianFields">
                            <h6>Data Teknisi</h6>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Spesialisasi</label>
                                        <input type="text" name="specialization" class="form-control" placeholder="Contoh: Elektronik, Plumbing, Listrik">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Pengalaman (tahun)</label>
                                        <input type="number" name="experience_years" class="form-control" placeholder="Contoh: 3" min="0" max="50">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Sertifikasi</label>
                                        <input type="text" name="certification" class="form-control" placeholder="Contoh: CCNA, CompTIA A+">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Rate per Jam (Rp)</label>
                                        <input type="number" name="rate" class="form-control" placeholder="Contoh: 50000" min="10000" step="5000">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Add User</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Show/hide technician fields based on role selection
        document.getElementById('roleSelect').addEventListener('change', function() {
            const technicianFields = document.getElementById('technicianFields');
            if (this.value === 'technician') {
                technicianFields.style.display = 'block';
                
                // Make technician fields required
                const inputs = technicianFields.querySelectorAll('input');
                inputs.forEach(input => {
                    input.required = true;
                });
            } else {
                technicianFields.style.display = 'none';
                
                // Remove required from technician fields
                const inputs = technicianFields.querySelectorAll('input');
                inputs.forEach(input => {
                    input.required = false;
                });
            }
        });

        // Initialize on page load
        document.addEventListener('DOMContentLoaded', function() {
            const roleSelect = document.getElementById('roleSelect');
            const technicianFields = document.getElementById('technicianFields');
            
            if (roleSelect.value !== 'technician') {
                technicianFields.style.display = 'none';
            }
        });
    </script>
</body>
</html>