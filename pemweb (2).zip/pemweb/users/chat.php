<?php
require_once '../db.php';
session_start();

// Check user login
if (!isset($_SESSION['user_id'])) {
    header('Location: /pemweb/login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$technician_id = isset($_GET['technician_id']) ? intval($_GET['technician_id']) : null;

// Get all conversations for the user
$conversations_query = "SELECT c.id, u.id as tech_id, u.name, u.profile_picture, 
                        (SELECT COUNT(*) FROM chat_messages m 
                         WHERE m.conversation_id = c.id AND m.is_read = 0 AND m.sender_id != ?) as unread_count,
                        (SELECT m.message FROM chat_messages m 
                         WHERE m.conversation_id = c.id ORDER BY m.created_at DESC LIMIT 1) as last_message
                        FROM chat_conversations c
                        JOIN users u ON c.technician_id = u.id
                        WHERE c.user_id = ?
                        ORDER BY (SELECT MAX(m.created_at) FROM chat_messages m WHERE m.conversation_id = c.id) DESC";
$stmt = $conn->prepare($conversations_query);
$stmt->bind_param("ii", $user_id, $user_id);
$stmt->execute();
$conversations = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Get or create conversation with selected technician
if ($technician_id) {
    // Check if conversation exists
    $conv_query = "SELECT id FROM chat_conversations 
                   WHERE (user_id = ? AND technician_id = ?)";
    $stmt = $conn->prepare($conv_query);
    $stmt->bind_param("ii", $user_id, $technician_id);
    $stmt->execute();
    $conversation = $stmt->get_result()->fetch_assoc();
    
    if (!$conversation) {
        // Create new conversation
        $insert_query = "INSERT INTO chat_conversations (user_id, technician_id) VALUES (?, ?)";
        $stmt = $conn->prepare($insert_query);
        $stmt->bind_param("ii", $user_id, $technician_id);
        $stmt->execute();
        $conversation_id = $stmt->insert_id;
    } else {
        $conversation_id = $conversation['id'];
    }
    
    // Get messages for this conversation
    $messages_query = "SELECT m.*, u.name as sender_name, u.profile_picture as sender_pic
                       FROM chat_messages m
                       JOIN users u ON m.sender_id = u.id
                       WHERE m.conversation_id = ?
                       ORDER BY m.created_at ASC";
    $stmt = $conn->prepare($messages_query);
    $stmt->bind_param("i", $conversation_id);
    $stmt->execute();
    $messages = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    
    // Mark messages as read
    if (!empty($messages)) {
        $update_query = "UPDATE chat_messages SET is_read = 1 
                         WHERE conversation_id = ? AND sender_id != ? AND is_read = 0";
        $stmt = $conn->prepare($update_query);
        $stmt->bind_param("ii", $conversation_id, $user_id);
        $stmt->execute();
    }
    
    // Get technician info
    $tech_query = "SELECT * FROM users WHERE id = ?";
    $stmt = $conn->prepare($tech_query);
    $stmt->bind_param("i", $technician_id);
    $stmt->execute();
    $technician = $stmt->get_result()->fetch_assoc();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Chat Teknisi - FixIt</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link rel="stylesheet" href="style_chat.css">
</head>
<body>

  <!-- Header -->
  <header>
    <div class="nav-container">
      <a href="index.html" class="logo">
        <i class="fas fa-tools"></i>
        <span>FixIt</span>
      </a>
      <button class="back-btn" onclick="window.history.back()">
        <i class="fas fa-arrow-left"></i>
        Kembali
      </button>
    </div>
  </header>

  <!-- Main Content -->
  <div class="container">
    <?php if (!$technician_id): ?>
      <!-- Conversation List View -->
      <div class="card">
        <div class="card-header">
          <h4><i class="fas fa-comments"></i> Percakapan Saya</h4>
        </div>
        <div class="card-body p-0">
          <div class="conversation-list">
            <?php if (!empty($conversations)): ?>
              <?php foreach ($conversations as $conv): ?>
                <a href="?technician_id=<?= $conv['tech_id'] ?>" class="conversation-item">
                  <div class="conversation-content">
                    <img src="<?= $conv['profile_picture'] ?: 'https://via.placeholder.com/50' ?>" 
                         class="conversation-avatar" alt="Profile">
                    <div class="conversation-details">
                      <div class="conversation-name"><?= htmlspecialchars($conv['name']) ?></div>
                      <div class="conversation-preview">
                        <?= $conv['last_message'] ? htmlspecialchars($conv['last_message']) : 'No messages yet' ?>
                      </div>
                    </div>
                    <?php if ($conv['unread_count'] > 0): ?>
                      <span class="unread-badge"><?= $conv['unread_count'] ?></span>
                    <?php endif; ?>
                  </div>
                </a>
              <?php endforeach; ?>
            <?php else: ?>
              <div class="empty-state">
                <i class="fas fa-comment-slash"></i>
                <h5>Belum ada percakapan</h5>
                <p>Mulai percakapan baru dengan teknisi kami</p>
              </div>
            <?php endif; ?>
          </div>
        </div>
      </div>
    <?php else: ?>
      <!-- Chat View -->
      <div class="chat-container">
        <div class="header-chat">
          <div class="profile-img" style="background-image: url('<?= $technician['profile_picture'] ?: 'https://via.placeholder.com/50' ?>')"></div>
          <div>
            <div class="profile-info"><?= htmlspecialchars($technician['name']) ?></div>
            <div class="status">
              <div class="status-indicator"></div>
              <span>Tersedia</span>
            </div>
          </div>
        </div>

        <div class="messages" id="messages">
          <?php if (!empty($messages)): ?>
            <?php foreach ($messages as $message): ?>
              <div class="message <?= $message['sender_id'] == $user_id ? 'user' : 'tech' ?>">
                <div class="message-content">
                  <?= htmlspecialchars($message['message']) ?>
                  <div class="message-time">
                    <?= date('H:i', strtotime($message['created_at'])) ?>
                    <?php if ($message['sender_id'] == $user_id && $message['is_read']): ?>
                      <i class="fas fa-check-double" style="margin-left: 5px;"></i>
                    <?php elseif ($message['sender_id'] == $user_id): ?>
                      <i class="fas fa-check" style="margin-left: 5px;"></i>
                    <?php endif; ?>
                  </div>
                </div>
              </div>
            <?php endforeach; ?>
          <?php else: ?>
            <div class="empty-state">
              <i class="fas fa-comment-alt"></i>
              <h5>Belum ada pesan</h5>
              <p>Mulai percakapan dengan teknisi</p>
            </div>
          <?php endif; ?>
        </div>

        <div class="typing-indicator" id="typingIndicator">
          <span></span>
          <span></span>
          <span></span>
        </div>

        <div class="chat-footer">
          <input type="text" id="messageInput" placeholder="Ketik pesan..." onkeypress="handleKeyPress(event)" />
          <button onclick="sendMessage()">
            <i class="fas fa-paper-plane"></i>
            <span>Kirim</span>
          </button>
        </div>
      </div>
    <?php endif; ?>
  </div>

  <script>
    <?php if ($technician_id): ?>
    const messagesContainer = document.getElementById("messages");
    const typingIndicator = document.getElementById("typingIndicator");
    const conversationId = <?= $conversation_id ?>;
    const userId = <?= $user_id ?>;
    const technicianId = <?= $technician_id ?>;
    let lastMessageId = <?= !empty($messages) ? end($messages)['id'] : 0 ?>;

    // Function to format current time
    const getCurrentTime = () => {
      const now = new Date();
      return `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
    };

    // Function to add message to chat
    const addMessage = (sender, text, messageId, isRead, timestamp) => {
      const messageDiv = document.createElement("div");
      messageDiv.classList.add("message");
      messageDiv.classList.add(sender);
      
      const contentDiv = document.createElement("div");
      contentDiv.classList.add("message-content");
      contentDiv.textContent = text;
      
      const timeSpan = document.createElement("div");
      timeSpan.classList.add("message-time");
      timeSpan.textContent = timestamp || getCurrentTime();
      
      if (sender === 'user') {
        const readIcon = document.createElement("i");
        readIcon.classList.add("fas");
        readIcon.classList.add(isRead ? "fa-check-double" : "fa-check");
        readIcon.style.marginLeft = "5px";
        timeSpan.appendChild(readIcon);
      }
      
      messageDiv.appendChild(contentDiv);
      messageDiv.appendChild(timeSpan);
      
      messagesContainer.appendChild(messageDiv);
      messagesContainer.scrollTop = messagesContainer.scrollHeight;
      
      // Update last message ID
      if (messageId && messageId > lastMessageId) {
        lastMessageId = messageId;
      }
    };

    // Send new message
    const sendMessage = () => {
      const messageInput = document.getElementById("messageInput");
      const messageText = messageInput.value.trim();

      if (messageText !== "") {
        // Add message to UI immediately
        addMessage("user", messageText);
        messageInput.value = "";
        
        // Send message to server
        const formData = new FormData();
        formData.append('conversation_id', conversationId);
        formData.append('sender_id', userId);
        formData.append('message', messageText);
        
        fetch('send_message.php', {
          method: 'POST',
          body: formData
        })
        .then(response => response.json())
        .then(data => {
          if (!data.success) {
            console.error('Failed to send message:', data.error);
          }
        })
        .catch(error => {
          console.error('Error:', error);
        });
      }
    };

    // Handle Enter key press
    const handleKeyPress = (event) => {
      if (event.key === "Enter") {
        sendMessage();
      }
    };

    // Check for new messages
    const checkForNewMessages = () => {
      fetch(`get_messages.php?conversation_id=${conversationId}&last_id=${lastMessageId}`)
      .then(response => response.json())
      .then(data => {
        if (data.messages && data.messages.length > 0) {
          data.messages.forEach(msg => {
            addMessage(
              msg.sender_id == userId ? 'user' : 'tech',
              msg.message,
              msg.id,
              msg.is_read,
              new Date(msg.created_at).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})
            );
          });
        }
      })
      .catch(error => {
        console.error('Error fetching messages:', error);
      });
    };

    // Poll for new messages every 3 seconds
    setInterval(checkForNewMessages, 3000);

    // Initial scroll to bottom
    window.onload = () => {
      messagesContainer.scrollTop = messagesContainer.scrollHeight;
    };
    <?php endif; ?>
  </script>
</body>
</html>