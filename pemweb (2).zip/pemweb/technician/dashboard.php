<?php
session_start();
require_once '../db.php';

// Check if user is logged in and is a technician
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'technician') {
    header('Location: ../login.php');
    exit;
}

// Langsung ambil user_id dari session
$user_id = (int)$_SESSION['user_id'];

// Get statistics
$total_orders = $conn->query("SELECT COUNT(*) FROM orders o JOIN technicians t ON o.technician_id = t.id WHERE t.user_id = $user_id")->fetch_row()[0];
$pending_orders = $conn->query("SELECT COUNT(*) FROM orders o JOIN technicians t ON o.technician_id = t.id WHERE t.user_id = $user_id AND o.status = 'pending'")->fetch_row()[0];
$completed_orders = $conn->query("SELECT COUNT(*) FROM orders o JOIN technicians t ON o.technician_id = t.id WHERE t.user_id = $user_id AND o.status = 'completed'")->fetch_row()[0];

// Get average rating
$avg_rating_result = $conn->query("
    SELECT AVG(f.rating) as avg_rating 
    FROM feedback f 
    JOIN technicians t ON f.technician_id = t.id 
    WHERE t.user_id = $user_id
");
$avg_rating = $avg_rating_result ? ($avg_rating_result->fetch_assoc()['avg_rating'] ?? 0) : 0;

// Get recent orders
$recent_orders = $conn->query("
    SELECT o.id, u.name as user_name, it.name as item_type, o.status, o.created_at
    FROM orders o
    JOIN technicians t ON o.technician_id = t.id
    JOIN users u ON o.user_id = u.id
    JOIN item_types it ON o.item_type_id = it.id
    WHERE t.user_id = $user_id
    ORDER BY o.created_at DESC
    LIMIT 5
");

// Get recent feedback
$recent_feedback = $conn->query("
    SELECT f.rating, f.comment, u.name as user_name, o.id as order_id
    FROM feedback f
    JOIN orders o ON f.order_id = o.id
    JOIN technicians t ON f.technician_id = t.id
    JOIN users u ON o.user_id = u.id
    WHERE t.user_id = $user_id
    ORDER BY f.created_at DESC
    LIMIT 3
");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Technician Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        .stat-card {
            transition: transform 0.3s;
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
        .star-rating {
            color: gold;
            font-size: 1.2rem;
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <div class="row">
            <div class="col-md-3">
                <?php include 'sidebar.php'; ?>
            </div>
            <div class="col-md-9">
                <h2>Technician Dashboard</h2>
                <p class="text-muted">Welcome back, <?= htmlspecialchars($_SESSION['username']) ?>!</p>
                
                <div class="row mb-4">
                    <div class="col-md-3">
                        <div class="card stat-card bg-primary text-white">
                            <div class="card-body">
                                <h5 class="card-title">Total Orders</h5>
                                <h2><?= $total_orders ?></h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card stat-card bg-warning text-dark">
                            <div class="card-body">
                                <h5 class="card-title">Pending Orders</h5>
                                <h2><?= $pending_orders ?></h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card stat-card bg-success text-white">
                            <div class="card-body">
                                <h5 class="card-title">Completed</h5>
                                <h2><?= $completed_orders ?></h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card stat-card bg-info text-white">
                            <div class="card-body">
                                <h5 class="card-title">Avg Rating</h5>
                                <h2>
                                    <?= number_format($avg_rating, 1) ?>
                                    <i class="bi bi-star-fill text-warning"></i>
                                </h2>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="card mb-4">
                            <div class="card-header">
                                <h5>Recent Orders</h5>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th>Order ID</th>
                                                <th>Customer</th>
                                                <th>Service</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if ($recent_orders && $recent_orders->num_rows > 0): ?>
                                                <?php while($order = $recent_orders->fetch_assoc()): ?>
                                                <tr>
                                                    <td>#<?= $order['id'] ?></td>
                                                    <td><?= htmlspecialchars($order['user_name']) ?></td>
                                                    <td><?= htmlspecialchars($order['item_type']) ?></td>
                                                    <td>
                                                        <span class="badge bg-<?= 
                                                            $order['status'] == 'completed' ? 'success' : 
                                                            ($order['status'] == 'processing' ? 'info' : 'warning')
                                                        ?>">
                                                            <?= ucfirst($order['status']) ?>
                                                        </span>
                                                    </td>
                                                </tr>
                                                <?php endwhile; ?>
                                            <?php else: ?>
                                                <tr>
                                                    <td colspan="4" class="text-center text-muted py-4">
                                                        <i class="bi bi-inbox" style="font-size: 3rem;"></i>
                                                        <p class="mt-2">No orders found</p>
                                                    </td>
                                                </tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="card mb-4">
                            <div class="card-header">
                                <h5>Recent Feedback</h5>
                            </div>
                            <div class="card-body">
                                <?php if ($recent_feedback && $recent_feedback->num_rows > 0): ?>
                                    <?php while($feedback = $recent_feedback->fetch_assoc()): ?>
                                    <div class="mb-3 p-3 border rounded">
                                        <div class="d-flex justify-content-between">
                                            <strong><?= htmlspecialchars($feedback['user_name']) ?></strong>
                                            <div class="star-rating">
                                                <?php for($i = 1; $i <= 5; $i++): ?>
                                                    <i class="bi bi-star<?= $i <= $feedback['rating'] ? '-fill' : '' ?>"></i>
                                                <?php endfor; ?>
                                            </div>
                                        </div>
                                        <small class="text-muted">Order #<?= $feedback['order_id'] ?></small>
                                        <p class="mt-2"><?= htmlspecialchars($feedback['comment']) ?></p>
                                    </div>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <div class="text-center text-muted p-4">
                                        <i class="bi bi-chat-left-text" style="font-size: 3rem;"></i>
                                        <p class="mt-2">No feedback yet</p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>