<?php
/**
 * TECH SIDEBAR - WITH CHAT & USER MANAGEMENT
 */

$tech_root = '/pemweb/technician/';
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://';
$base_url = $protocol . $_SERVER['HTTP_HOST'] . $tech_root;

// Enhanced menu structure with chat and user management
$menu_items = [
    'dashboard' => [
        'title' => 'Dashboard',
        'icon' => 'speedometer2',
        'url' => 'dashboard.php'
    ],
    'orders' => [
        'title' => 'My Orders',
        'icon' => 'list-task',
        'url' => 'orders.php'
    ],
    'schedule' => [
        'title' => 'My Schedule',
        'icon' => 'calendar-check',
        'url' => 'schedule.php'
    ],
    'chats' => [
        'title' => 'Customer Chats',
        'icon' => 'chat-dots',
        'url' => 'chats/index.php'
    ],
    'customers' => [
        'title' => 'Customer List',
        'icon' => 'people',
        'url' => 'customers/index.php'
    ],
    'performance' => [
        'title' => 'My Performance',
        'icon' => 'graph-up',
        'url' => 'performance.php'
    ],
    'feedback' => [
        'title' => 'Customer Feedback',
        'icon' => 'chat-left-text',
        'url' => 'feedback.php'
    ],
    'articles' => [
        'title' => 'My Articles',
        'icon' => 'journal-text',
        'url' => 'articles/index.php'
    ],
    'profile' => [
        'title' => 'My Profile',
        'icon' => 'person-circle',
        'url' => 'profile.php'
    ],
    'settings' => [
        'title' => 'Account Settings',
        'icon' => 'gear',
        'url' => 'settings.php'
    ]
];

function isActiveMenu($menuPath, $currentPath) {
    // Normalize paths
    $menuPath = rtrim($menuPath, '/');
    $currentPath = rtrim($currentPath, '/');
    
    // Check if current path starts with menu path (for subpages)
    if (strpos($currentPath, $menuPath) === 0) {
        // For index pages, check exact match
        if (basename($menuPath) === 'index.php') {
            return $menuPath === $currentPath;
        }
        return true;
    }
    
    return false;
}

$current_path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$current_path = rtrim($current_path, '/');
?>

<div class="list-group" id="techSideNav">
    <!-- Group: Main -->
    <div class="list-group-item list-group-item-dark">
        <i class="bi bi-menu-button-wide"></i> Main Menu
    </div>
    
    <?php foreach(['dashboard', 'orders', 'schedule'] as $key): ?>
        <a href="<?= $base_url . $menu_items[$key]['url'] ?>" 
           class="list-group-item list-group-item-action <?= isActiveMenu($menu_items[$key]['url'], $current_path) ? 'active' : '' ?>">
            <i class="bi bi-<?= $menu_items[$key]['icon'] ?>"></i> <?= $menu_items[$key]['title'] ?>
        </a>
    <?php endforeach; ?>
    
    <!-- Group: Communication -->
    <div class="list-group-item list-group-item-dark">
        <i class="bi bi-chat-left-text"></i> Communication
    </div>
    
    <?php foreach(['chats', 'customers'] as $key): ?>
        <a href="<?= $base_url . $menu_items[$key]['url'] ?>" 
           class="list-group-item list-group-item-action <?= isActiveMenu($menu_items[$key]['url'], $current_path) ? 'active' : '' ?>">
            <i class="bi bi-<?= $menu_items[$key]['icon'] ?>"></i> <?= $menu_items[$key]['title'] ?>
        </a>
    <?php endforeach; ?>
    
    <!-- Group: Performance -->
    <div class="list-group-item list-group-item-dark">
        <i class="bi bi-graph-up"></i> Performance
    </div>
    
    <?php foreach(['performance', 'feedback'] as $key): ?>
        <a href="<?= $base_url . $menu_items[$key]['url'] ?>" 
           class="list-group-item list-group-item-action <?= isActiveMenu($menu_items[$key]['url'], $current_path) ? 'active' : '' ?>">
            <i class="bi bi-<?= $menu_items[$key]['icon'] ?>"></i> <?= $menu_items[$key]['title'] ?>
        </a>
    <?php endforeach; ?>
    
    <!-- Group: Content -->
    <div class="list-group-item list-group-item-dark">
        <i class="bi bi-file-earmark-text"></i> Content
    </div>
    
    <a href="<?= $base_url . $menu_items['articles']['url'] ?>" 
       class="list-group-item list-group-item-action <?= isActiveMenu($menu_items['articles']['url'], $current_path) ? 'active' : '' ?>">
        <i class="bi bi-<?= $menu_items['articles']['icon'] ?>"></i> <?= $menu_items['articles']['title'] ?>
    </a>
    
    <!-- Group: Account -->
    <div class="list-group-item list-group-item-dark">
        <i class="bi bi-person-circle"></i> Account
    </div>
    
    <?php foreach(['profile', 'settings'] as $key): ?>
        <a href="<?= $base_url . $menu_items[$key]['url'] ?>" 
           class="list-group-item list-group-item-action <?= isActiveMenu($menu_items[$key]['url'], $current_path) ? 'active' : '' ?>">
            <i class="bi bi-<?= $menu_items[$key]['icon'] ?>"></i> <?= $menu_items[$key]['title'] ?>
        </a>
    <?php endforeach; ?>
    
    <!-- Logout -->
    <div class="list-group-item"></div>
    <a href="<?= $base_url ?>../logout.php" class="list-group-item list-group-item-action text-danger">
        <i class="bi bi-box-arrow-right"></i> Logout
    </a>
</div>

<style>
#techSideNav .active {
    /* Hapus background-color dan border-color biru */
    background-color: transparent !important;
    border-color: transparent !important;
    /* Tambahkan indikator lain jika perlu */
    border-left: 3px solid var(--bs-primary);
    color: var(--bs-primary) !important;
    font-weight: bold;
}

#techSideNav .list-group-item-dark {
    background-color: var(--bs-gray-800);
    color: white;
}

#techSideNav a:not(.active):hover {
    background-color: rgba(0, 0, 0, 0.05);
}

/* Tambahan untuk indikator aktif yang lebih subtle */
#techSideNav a.active i {
    color: var(--bs-primary);
}
</style>