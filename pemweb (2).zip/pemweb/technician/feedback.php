<?php
session_start();
require_once '../db.php';

// Check if user is logged in and is a technician
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'technician') {
    header('Location: ../login.php');
    exit;
}

$user_id = (int)$_SESSION['user_id'];

// Get all feedback for this technician
$feedback = $conn->query("
    SELECT f.rating, f.comment, u.name as user_name, o.id as order_id, f.created_at
    FROM feedback f
    JOIN orders o ON f.order_id = o.id
    JOIN technicians t ON f.technician_id = t.id
    JOIN users u ON o.user_id = u.id
    WHERE t.user_id = $user_id
    ORDER BY f.created_at DESC
");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Feedback</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <div class="row">
            <div class="col-md-3">
                <?php include 'sidebar.php'; ?>
            </div>
            <div class="col-md-9">
                <h2>Customer Feedback</h2>
                
                <?php if ($feedback && $feedback->num_rows > 0): ?>
                    <?php while($fb = $feedback->fetch_assoc()): ?>
                    <div class="card mb-3">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <h5 class="card-title"><?= htmlspecialchars($fb['user_name']) ?></h5>
                                <div class="star-rating">
                                    <?php for($i = 1; $i <= 5; $i++): ?>
                                        <i class="bi bi-star<?= $i <= $fb['rating'] ? '-fill' : '' ?>"></i>
                                    <?php endfor; ?>
                                </div>
                            </div>
                            <h6 class="card-subtitle mb-2 text-muted">Order #<?= $fb['order_id'] ?> - <?= date('d M Y', strtotime($fb['created_at'])) ?></h6>
                            <p class="card-text"><?= htmlspecialchars($fb['comment']) ?></p>
                        </div>
                    </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div class="text-center text-muted p-4">
                        <i class="bi bi-chat-left-text" style="font-size: 3rem;"></i>
                        <p class="mt-2">No feedback yet</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>