<?php
session_start();
require_once '../db.php';

// Check if user is logged in and is a technician
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'technician') {
    header('Location: ../login.php');
    exit;
}

if (!isset($_GET['id']) || !isset($_GET['status'])) {
    header('Location: orders.php');
    exit;
}

$order_id = (int)$_GET['id'];
$status = $_GET['status'];
$user_id = (int)$_SESSION['user_id'];

// Validate status
$allowed_statuses = ['processing', 'completed'];
if (!in_array($status, $allowed_statuses)) {
    header('Location: orders.php');
    exit;
}

// Check if order belongs to this technician
$order_check = $conn->query("
    SELECT o.id 
    FROM orders o
    JOIN technicians t ON o.technician_id = t.id
    WHERE o.id = $order_id AND t.user_id = $user_id
");

if ($order_check->num_rows === 0) {
    header('Location: orders.php');
    exit;
}

// Update status
$conn->query("UPDATE orders SET status = '$status' WHERE id = $order_id");

// Redirect back with success message
$redirect = isset($_GET['from']) && $_GET['from'] == 'view' ? 
            "view_order.php?id=$order_id" : 
            "orders.php";
            
header("Location: $redirect?success=Order+status+updated+successfully");
exit;