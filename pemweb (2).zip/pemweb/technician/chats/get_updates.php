<?php
session_start();
require '../../db.php';

header('Content-Type: application/json');

// Check authentication
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'technician') {
    echo json_encode(['new_messages' => []]);
    exit;
}

$chat_id = (int)($_GET['chat_id'] ?? 0);
$last_id = (int)($_GET['last_id'] ?? 0);

// Verify chat belongs to technician
$check = $conn->prepare("SELECT id FROM chat_conversations WHERE id = ? AND technician_id = ?");
$check->bind_param("ii", $chat_id, $_SESSION['user_id']);
$check->execute();

if ($check->get_result()->num_rows === 0) {
    echo json_encode(['new_messages' => []]);
    exit;
}

// Get new messages
$messages = $conn->query("
    SELECT id FROM chat_messages 
    WHERE conversation_id = $chat_id AND id > $last_id AND sender_id != {$_SESSION['user_id']}
")->fetch_all(MYSQLI_ASSOC);

echo json_encode(['new_messages' => $messages]);