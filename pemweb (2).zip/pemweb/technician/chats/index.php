<?php
require_once '../../db.php';
session_start();

// Check technician login
if (!isset($_SESSION['username'])) {
    header('Location: /pemweb/login.php');
    exit;
}

$technician_id = $_SESSION['user_id'];
$customer_id = isset($_GET['customer_id']) ? intval($_GET['customer_id']) : null;

// Get all conversations for the technician
$conversations_query = "SELECT c.id, u.id as user_id, u.name, u.profile_picture, 
                        (SELECT COUNT(*) FROM chat_messages m 
                         WHERE m.conversation_id = c.id AND m.is_read = 0 AND m.sender_id != ?) as unread_count,
                        (SELECT m.message FROM chat_messages m 
                         WHERE m.conversation_id = c.id ORDER BY m.created_at DESC LIMIT 1) as last_message
                        FROM chat_conversations c
                        JOIN users u ON c.user_id = u.id
                        WHERE c.technician_id = ?
                        ORDER BY (SELECT MAX(m.created_at) FROM chat_messages m WHERE m.conversation_id = c.id) DESC";
$stmt = $conn->prepare($conversations_query);
$stmt->bind_param("ii", $technician_id, $technician_id);
$stmt->execute();
$conversations = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Get or create conversation with selected customer
if ($customer_id) {
    // Check if conversation exists
    $conv_query = "SELECT id FROM chat_conversations 
                   WHERE (user_id = ? AND technician_id = ?) 
                   OR (user_id = ? AND technician_id = ?)";
    $stmt = $conn->prepare($conv_query);
    $stmt->bind_param("iiii", $customer_id, $technician_id, $technician_id, $customer_id);
    $stmt->execute();
    $conversation = $stmt->get_result()->fetch_assoc();
    
    if (!$conversation) {
        // Create new conversation
        $insert_query = "INSERT INTO chat_conversations (user_id, technician_id) VALUES (?, ?)";
        $stmt = $conn->prepare($insert_query);
        $stmt->bind_param("ii", $customer_id, $technician_id);
        $stmt->execute();
        $conversation_id = $stmt->insert_id;
    } else {
        $conversation_id = $conversation['id'];
    }
    
    // Get messages for this conversation
    $messages_query = "SELECT m.*, u.name as sender_name, u.profile_picture as sender_pic
                       FROM chat_messages m
                       JOIN users u ON m.sender_id = u.id
                       WHERE m.conversation_id = ?
                       ORDER BY m.created_at ASC";
    $stmt = $conn->prepare($messages_query);
    $stmt->bind_param("i", $conversation_id);
    $stmt->execute();
    $messages = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    
    // Mark messages as read
    if (!empty($messages)) {
        $update_query = "UPDATE chat_messages SET is_read = 1 
                         WHERE conversation_id = ? AND sender_id != ? AND is_read = 0";
        $stmt = $conn->prepare($update_query);
        $stmt->bind_param("ii", $conversation_id, $technician_id);
        $stmt->execute();
    }
    
    // Get customer info
    $customer_query = "SELECT * FROM users WHERE id = ?";
    $stmt = $conn->prepare($customer_query);
    $stmt->bind_param("i", $customer_id);
    $stmt->execute();
    $customer = $stmt->get_result()->fetch_assoc();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Chats</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        .chat-container {
            height: calc(100vh - 200px);
            overflow-y: auto;
        }
        .conversation-list {
            height: calc(100vh - 200px);
            overflow-y: auto;
            border-right: 1px solid #dee2e6;
        }
        .message {
            max-width: 70%;
            margin-bottom: 10px;
            padding: 10px 15px;
            border-radius: 15px;
        }
        .received {
            background-color: #f1f1f1;
            align-self: flex-start;
        }
        .sent {
            background-color: #007bff;
            color: white;
            align-self: flex-end;
        }
        .unread-badge {
            position: absolute;
            top: 5px;
            right: 5px;
            font-size: 0.7rem;
        }
        .active-conversation {
            background-color: rgba(0, 123, 255, 0.1);
        }
        .profile-pic-sm {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
        }
    </style>
</head>
<body>
    <?php include '../navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <div class="row">
            <div class="col-md-3">
                <?php include '../sidebar.php'; ?>
            </div>
            <div class="col-md-9">
                <h2><i class="bi bi-chat-left-text"></i> Customer Chats</h2>
                
                <div class="card">
                    <div class="card-body p-0">
                        <div class="row g-0">
                            <!-- Conversation list -->
                            <div class="col-md-4">
                                <div class="p-3 border-bottom">
                                    <input type="text" class="form-control" placeholder="Search conversations...">
                                </div>
                                <div class="conversation-list">
                                    <?php foreach ($conversations as $conv): ?>
                                        <a href="?customer_id=<?= $conv['user_id'] ?>" 
                                           class="d-block p-3 text-decoration-none text-dark position-relative 
                                                  <?= ($customer_id == $conv['user_id']) ? 'active-conversation' : '' ?>">
                                            <div class="d-flex align-items-center">
                                                <img src="<?= $conv['profile_picture'] ?: 'https://via.placeholder.com/40' ?>" 
                                                     class="profile-pic-sm me-3" alt="Profile">
                                                <div>
                                                    <h6 class="mb-0"><?= htmlspecialchars($conv['name']) ?></h6>
                                                    <small class="text-muted text-truncate d-block" style="max-width: 200px;">
                                                        <?= $conv['last_message'] ? htmlspecialchars($conv['last_message']) : 'No messages yet' ?>
                                                    </small>
                                                </div>
                                            </div>
                                            <?php if ($conv['unread_count'] > 0): ?>
                                                <span class="badge bg-danger unread-badge"><?= $conv['unread_count'] ?></span>
                                            <?php endif; ?>
                                        </a>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                            
                            <!-- Chat area -->
                            <div class="col-md-8">
                                <?php if ($customer_id): ?>
                                    <!-- Chat header -->
                                    <div class="p-3 border-bottom d-flex align-items-center">
                                        <img src="<?= $customer['profile_picture'] ?: 'https://via.placeholder.com/40' ?>" 
                                             class="profile-pic-sm me-3" alt="Profile">
                                        <div>
                                            <h5 class="mb-0"><?= htmlspecialchars($customer['name']) ?></h5>
                                            <small class="text-muted">
                                                <?= $customer['email'] ?>
                                            </small>
                                        </div>
                                        <div class="ms-auto">
                                            <a href="../customers/?customer_id=<?= $customer_id ?>" 
                                               class="btn btn-sm btn-outline-primary">
                                                <i class="bi bi-person"></i> Profile
                                            </a>
                                        </div>
                                    </div>
                                    
                                    <!-- Messages -->
                                    <div class="chat-container p-3 d-flex flex-column" id="messageContainer">
                                        <?php if (!empty($messages)): ?>
                                            <?php foreach ($messages as $message): ?>
                                                <div class="message <?= $message['sender_id'] == $technician_id ? 'sent' : 'received' ?>">
                                                    <div class="d-flex align-items-center mb-1">
                                                        <img src="<?= $message['sender_pic'] ?: 'https://via.placeholder.com/30' ?>" 
                                                             class="rounded-circle me-2" width="20" height="20">
                                                        <small><strong><?= htmlspecialchars($message['sender_name']) ?></strong></small>
                                                    </div>
                                                    <?= htmlspecialchars($message['message']) ?>
                                                    <div class="text-end mt-1">
                                                        <small class="text-muted">
                                                            <?= date('h:i A', strtotime($message['created_at'])) ?>
                                                            <?php if ($message['sender_id'] == $technician_id && $message['is_read']): ?>
                                                                <i class="bi bi-check-all text-primary"></i>
                                                            <?php elseif ($message['sender_id'] == $technician_id): ?>
                                                                <i class="bi bi-check text-muted"></i>
                                                            <?php endif; ?>
                                                        </small>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <div class="text-center text-muted mt-5">
                                                <i class="bi bi-chat-square-text" style="font-size: 3rem;"></i>
                                                <p class="mt-2">No messages yet. Start the conversation!</p>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <!-- Message input -->
                                    <div class="p-3 border-top">
                                        <form id="messageForm" method="POST" action="send_message.php">
                                            <input type="hidden" name="conversation_id" value="<?= $conversation_id ?>">
                                            <input type="hidden" name="sender_id" value="<?= $technician_id ?>">
                                            <div class="input-group">
                                                <input type="text" name="message" class="form-control" placeholder="Type your message..." required>
                                                <button class="btn btn-primary" type="submit">
                                                    <i class="bi bi-send"></i> Send
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                <?php else: ?>
                                    <div class="text-center text-muted p-5">
                                        <i class="bi bi-chat-left-text" style="font-size: 3rem;"></i>
                                        <h4 class="mt-3">Select a conversation</h4>
                                        <p>Choose a customer from the list to start chatting</p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Auto-scroll to bottom of messages
        const messageContainer = document.getElementById('messageContainer');
        if (messageContainer) {
            messageContainer.scrollTop = messageContainer.scrollHeight;
        }
        
        // AJAX form submission for sending messages
        document.getElementById('messageForm')?.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const form = e.target;
            const formData = new FormData(form);
            
            fetch(form.action, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Reload the page to show new message
                    window.location.reload();
                } else {
                    alert('Failed to send message: ' + (data.error || 'Unknown error'));
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Failed to send message');
            });
        });
        
        // Poll for new messages every 5 seconds
        <?php if ($customer_id): ?>
        setInterval(() => {
            fetch('get_messages.php?conversation_id=<?= $conversation_id ?>&last_id=<?= !empty($messages) ? end($messages)['id'] : 0 ?>')
            .then(response => response.json())
            .then(data => {
                if (data.messages && data.messages.length > 0) {
                    window.location.reload();
                }
            });
        }, 5000);
        <?php endif; ?>
    </script>
</body>
</html>