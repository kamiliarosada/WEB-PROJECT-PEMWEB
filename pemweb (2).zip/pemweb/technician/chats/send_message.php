<?php
require_once '../../db.php';
session_start();

header('Content-Type: application/json');

// Check technician login
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'technician') {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

$technician_id = $_SESSION['user_id'];
$conversation_id = isset($_POST['conversation_id']) ? intval($_POST['conversation_id']) : 0;
$message = isset($_POST['message']) ? trim($_POST['message']) : '';

// Validate input
if (empty($message)) {
    echo json_encode(['success' => false, 'error' => 'Message cannot be empty']);
    exit;
}

// Check if conversation exists and belongs to this technician
$check_query = "SELECT id FROM chat_conversations WHERE id = ? AND technician_id = ?";
$stmt = $conn->prepare($check_query);
$stmt->bind_param("ii", $conversation_id, $technician_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(['success' => false, 'error' => 'Invalid conversation']);
    exit;
}

// Insert message
$insert_query = "INSERT INTO chat_messages (conversation_id, sender_id, message) VALUES (?, ?, ?)";
$stmt = $conn->prepare($insert_query);
$stmt->bind_param("iis", $conversation_id, $technician_id, $message);

if ($stmt->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => 'Database error']);
}
?>