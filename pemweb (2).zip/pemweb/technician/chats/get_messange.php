<?php
require_once '../../db.php';
session_start();

header('Content-Type: application/json');

// Check technician login
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'technician') {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

$conversation_id = isset($_GET['conversation_id']) ? intval($_GET['conversation_id']) : 0;
$last_id = isset($_GET['last_id']) ? intval($_GET['last_id']) : 0;

// Verify conversation belongs to technician
$check_query = "SELECT id FROM chat_conversations WHERE id = ? AND technician_id = ?";
$stmt = $conn->prepare($check_query);
$stmt->bind_param("ii", $conversation_id, $_SESSION['user_id']);
$stmt->execute();

if ($stmt->get_result()->num_rows === 0) {
    echo json_encode(['success' => false, 'error' => 'Invalid conversation']);
    exit;
}

// Get new messages
$query = "SELECT m.*, u.name as sender_name, u.profile_picture as sender_pic
          FROM chat_messages m
          JOIN users u ON m.sender_id = u.id
          WHERE m.conversation_id = ? AND m.id > ?
          ORDER BY m.created_at ASC";
$stmt = $conn->prepare($query);
$stmt->bind_param("ii", $conversation_id, $last_id);
$stmt->execute();
$result = $stmt->get_result();

$messages = [];
while ($row = $result->fetch_assoc()) {
    $messages[] = $row;
}

// Mark messages as read if they're from the customer
if (!empty($messages)) {
    $update_query = "UPDATE chat_messages SET is_read = 1 
                     WHERE conversation_id = ? AND id > ? AND sender_id != ?";
    $stmt = $conn->prepare($update_query);
    $stmt->bind_param("iii", $conversation_id, $last_id, $_SESSION['user_id']);
    $stmt->execute();
}

echo json_encode(['success' => true, 'messages' => $messages]);
?>