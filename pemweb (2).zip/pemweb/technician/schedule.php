<?php
session_start();
require_once '../db.php';

// Check if user is logged in and is a technician
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'technician') {
    header('Location: ../login.php');
    exit;
}

$user_id = (int)$_SESSION['user_id'];

// Query yang sesuai dengan struktur tabel orders
$schedules = $conn->query("
    SELECT 
        o.id, 
        o.customer_name as user_name,
        o.device,
        o.phone,
        o.address,
        o.service_date as order_date,
        o.service_time as time_slot,
        COALESCE(o.description, o.notes) as description,
        o.status,
        o.created_at
    FROM orders o
    JOIN technicians t ON o.technician_id = t.id
    WHERE t.user_id = $user_id AND o.status IN ('pending', 'processing')
    ORDER BY o.service_date ASC, o.service_time ASC
");

if (!$schedules) {
    die("Query failed: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Schedule</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        .badge-pending {
            background-color: #ffc107;
            color: #000;
        }
        .badge-processing {
            background-color: #0dcaf0;
            color: #000;
        }
        .badge-completed {
            background-color: #198754;
        }
        .badge-cancelled {
            background-color: #dc3545;
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <div class="row">
            <div class="col-md-3">
                <?php include 'sidebar.php'; ?>
            </div>
            <div class="col-md-9">
                <h2><i class="bi bi-calendar-check"></i> My Schedule</h2>
                
                <?php if (isset($_GET['success'])): ?>
                    <div class="alert alert-success alert-dismissible fade show">
                        <?= htmlspecialchars($_GET['success']) ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead class="table-light">
                            <tr>
                                <th>Order ID</th>
                                <th>Customer</th>
                                <th>Contact</th>
                                <th>Device</th>
                                <th>Service Date & Time</th>
                                <th>Address</th>
                                <th>Description</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($schedules && $schedules->num_rows > 0): ?>
                                <?php while($schedule = $schedules->fetch_assoc()): ?>
                                <tr>
                                    <td>#<?= $schedule['id'] ?></td>
                                    <td><?= htmlspecialchars($schedule['user_name']) ?></td>
                                    <td><?= htmlspecialchars($schedule['phone']) ?></td>
                                    <td><?= htmlspecialchars($schedule['device']) ?></td>
                                    <td>
                                        <?= date('d M Y', strtotime($schedule['order_date'])) ?><br>
                                        <?= htmlspecialchars($schedule['time_slot']) ?>
                                    </td>
                                    <td><?= htmlspecialchars($schedule['address']) ?></td>
                                    <td><?= htmlspecialchars($schedule['description']) ?></td>
                                    <td>
                                        <span class="badge rounded-pill badge-<?= $schedule['status'] ?>">
                                            <?= ucfirst($schedule['status']) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <a href="view_order.php?id=<?= $schedule['id'] ?>" class="btn btn-sm btn-primary">
                                            <i class="bi bi-eye"></i> View
                                        </a>
                                        <?php if ($schedule['status'] == 'pending'): ?>
                                            <a href="update_status.php?id=<?= $schedule['id'] ?>&status=processing" class="btn btn-sm btn-info">
                                                <i class="bi bi-check-circle"></i> Accept
                                            </a>
                                            <a href="update_status.php?id=<?= $schedule['id'] ?>&status=cancelled" class="btn btn-sm btn-danger">
                                                <i class="bi bi-x-circle"></i> Reject
                                            </a>
                                        <?php elseif ($schedule['status'] == 'processing'): ?>
                                            <a href="update_status.php?id=<?= $schedule['id'] ?>&status=completed" class="btn btn-sm btn-success">
                                                <i class="bi bi-check-circle"></i> Complete
                                            </a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="9" class="text-center text-muted py-4">
                                        <i class="bi bi-calendar-x" style="font-size: 3rem;"></i>
                                        <p class="mt-2">No upcoming schedules</p>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>