<nav class="navbar navbar-expand-lg navbar-light" style="background-color: #e3f2fd;">
    <div class="container-fluid">
        <!-- Brand/logo -->
        <a class="navbar-brand" href="<?= $base_url ?>dashboard.php">
            <i class="bi bi-tools me-2"></i>Technician Panel
        </a>
    </div>
</nav>

<style>
/* Consistent styling with admin navbar */
.navbar {
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    padding: 0.5rem 1rem;
}

.nav-link {
    padding: 0.5rem 1rem;
    border-radius: 0.25rem;
    transition: all 0.2s;
}

.dropdown-footer {
    background-color: #f8f9fa;
    border-bottom-left-radius: 0.5rem;
    border-bottom-right-radius: 0.5rem;
}
</style>
