<?php
session_start();
require_once '../db.php';

// Check if user is logged in and is a technician
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'technician') {
    header('Location: ../login.php');
    exit;
}

$user_id = (int)$_SESSION['user_id'];

// Ambil data user dan technician
$user = $conn->query("SELECT * FROM users WHERE id = $user_id")->fetch_assoc();
$technician = $conn->query("SELECT * FROM technicians WHERE user_id = $user_id")->fetch_assoc();

// Jika form disubmit (update profile)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Mengambil input data dari form
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $country = $_POST['country'];
    $gender = $_POST['gender'];
    $specialization = $_POST['specialization'];
    $experience_years = (int)$_POST['experience_years'];
    $certification = $_POST['certification'];
    $rate = (float)$_POST['rate'];

    // Prepared statement untuk update user
    $stmt_user = $conn->prepare("UPDATE users SET name=?, phone=?, country=?, gender=? WHERE id=?");
    $stmt_user->bind_param("ssssi", $name, $phone, $country, $gender, $user_id);

    // Update user
    if ($stmt_user->execute()) {
        // Prepared statement untuk update technician
        $stmt_technician = $conn->prepare("UPDATE technicians SET specialization=?, experience_years=?, certification=?, rate=? WHERE user_id=?");
        $stmt_technician->bind_param("sissi", $specialization, $experience_years, $certification, $rate, $user_id);

        // Update technician
        if ($stmt_technician->execute()) {
            $_SESSION['message'] = "Profile updated successfully.";
        } else {
            $_SESSION['error'] = "Error updating technician profile: " . $conn->error;
        }
    } else {
        $_SESSION['error'] = "Error updating user profile: " . $conn->error;
    }

    // Refresh data after update
    $user = $conn->query("SELECT * FROM users WHERE id = $user_id")->fetch_assoc();
    $technician = $conn->query("SELECT * FROM technicians WHERE user_id = $user_id")->fetch_assoc();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <div class="row">
            <div class="col-md-3">
                <?php include 'sidebar.php'; ?>
            </div>
            <div class="col-md-9">
                <h2>My Profile</h2>

                <!-- Menampilkan pesan error atau success -->
                <?php if (isset($_SESSION['message'])): ?>
                    <div class="alert alert-success">
                        <?= $_SESSION['message']; ?>
                    </div>
                    <?php unset($_SESSION['message']); ?>
                <?php endif; ?>
                <?php if (isset($_SESSION['error'])): ?>
                    <div class="alert alert-danger">
                        <?= $_SESSION['error']; ?>
                    </div>
                    <?php unset($_SESSION['error']); ?>
                <?php endif; ?>

                <form method="POST">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="card mb-4">
                                <div class="card-header">
                                    <h5>Personal Information</h5>
                                </div>
                                <div class="card-body">
                                    <div class="mb-3">
                                        <label class="form-label">Full Name</label>
                                        <input type="text" class="form-control" name="name" value="<?= htmlspecialchars($user['name']) ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Email</label>
                                        <input type="email" class="form-control" value="<?= htmlspecialchars($user['email']) ?>" readonly>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Phone</label>
                                        <input type="text" class="form-control" name="phone" value="<?= htmlspecialchars($user['phone']) ?>">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Country</label>
                                        <input type="text" class="form-control" name="country" value="<?= htmlspecialchars($user['country']) ?>">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Gender</label>
                                        <select class="form-select" name="gender">
                                            <option value="male" <?= $user['gender'] == 'male' ? 'selected' : '' ?>>Male</option>
                                            <option value="female" <?= $user['gender'] == 'female' ? 'selected' : '' ?>>Female</option>
                                            <option value="other" <?= $user['gender'] == 'other' ? 'selected' : '' ?>>Other</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="card mb-4">
                                <div class="card-header">
                                    <h5>Professional Information</h5>
                                </div>
                                <div class="card-body">
                                    <div class="mb-3">
                                        <label class="form-label">Specialization</label>
                                        <input type="text" class="form-control" name="specialization" value="<?= htmlspecialchars($technician['specialization']) ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Experience (Years)</label>
                                        <input type="number" class="form-control" name="experience_years" value="<?= $technician['experience_years'] ?>" min="0" required>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Certification</label>
                                        <input type="text" class="form-control" name="certification" value="<?= htmlspecialchars($technician['certification']) ?>">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Rate per hour ($)</label>
                                        <input type="number" step="0.01" class="form-control" name="rate" value="<?= $technician['rate'] ?>" required>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary">Update Profile</button>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
