<?php
session_start();
require_once '../db.php';

// Check if user is logged in and has user role
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'user') {
    header('Location: ../login.php');
    exit;
}

// Check if order ID is provided
if (!isset($_GET['id'])) {
    header('Location: pesanan.php');
    exit;
}

$order_id = intval($_GET['id']);
$user_id = $_SESSION['user_id'];

// Check if order belongs to user and is pending
$order = $conn->query("
    SELECT id FROM orders 
    WHERE id = $order_id AND user_id = $user_id AND status = 'pending'
")->fetch_assoc();

if (!$order) {
    $_SESSION['error'] = "Pesanan tidak dapat dibatalkan atau tidak ditemukan";
    header('Location: pesanan.php');
    exit;
}

// Update order status to cancelled
$conn->query("
    UPDATE orders SET status = 'cancelled' 
    WHERE id = $order_id
");

// Hapus bagian yang mencoba insert ke order_status_history
// karena tabel tersebut tidak ada di database Anda

$_SESSION['success'] = "Pesanan berhasil dibatalkan";
header('Location: pesanan.php');
exit;
?>