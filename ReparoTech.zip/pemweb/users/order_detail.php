<?php
session_start();
require_once '../db.php';

// Check if user is logged in and has user role
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'user') {
    header('Location: ../login.php');
    exit;
}

// Check if order ID is provided
if (!isset($_GET['id'])) {
    header('Location: pesanan.php');
    exit;
}

$order_id = intval($_GET['id']);
$user_id = $_SESSION['user_id'];

// Get basic order details
$order = $conn->query("
    SELECT o.*, u.name as technician_name, t.rate
    FROM orders o
    LEFT JOIN technicians t ON o.technician_id = t.id
    LEFT JOIN users u ON t.user_id = u.id
    WHERE o.id = $order_id AND o.user_id = $user_id
")->fetch_assoc();

if (!$order) {
    header('Location: pesanan.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Detail - ReparoTech</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f7fa;
            color: #333;
            line-height: 1.6;
            padding: 20px;
        }
        
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        
        .order-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            border-bottom: 1px solid #eee;
            padding-bottom: 15px;
        }
        
        .order-header h2 {
            margin: 0;
            color: #333;
        }
        
        .back-btn {
            text-decoration: none;
            color: #4a6cf7;
            font-weight: 500;
        }
        
        .order-info {
            margin-bottom: 20px;
        }
        
        .info-row {
            display: flex;
            margin-bottom: 10px;
        }
        
        .info-label {
            width: 150px;
            font-weight: 500;
            color: #666;
        }
        
        .status {
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 500;
            text-transform: capitalize;
        }
        
        .status-pending {
            background-color: #fff3cd;
            color: #856404;
        }
        
        .status-processing {
            background-color: #cce5ff;
            color: #004085;
        }
        
        .status-completed {
            background-color: #d4edda;
            color: #155724;
        }
        
        .status-cancelled {
            background-color: #f8d7da;
            color: #721c24;
        }
        
        .total-amount {
            font-weight: 600;
            color: #2563eb;
            font-size: 18px;
        }
        
        .timeline {
            margin-top: 20px;
            padding-left: 20px;
            border-left: 2px solid #eee;
        }
        
        .timeline-item {
            margin-bottom: 15px;
            position: relative;
            padding-left: 20px;
        }
        
        .timeline-item:before {
            content: '';
            position: absolute;
            left: -6px;
            top: 8px;
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background-color: #4a6cf7;
        }
        
        .timeline-date {
            font-size: 12px;
            color: #666;
        }
        
        .timeline-content {
            background: #f8f9fa;
            padding: 8px 12px;
            border-radius: 4px;
        }
        
        .order-actions {
            margin-top: 20px;
            padding-top: 15px;
            border-top: 1px solid #eee;
        }
        
        .btn {
            padding: 8px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            text-decoration: none;
            display: inline-block;
        }
        
        .btn-danger {
            background-color: #dc3545;
            color: white;
        }
        
        .btn-danger:hover {
            background-color: #c82333;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="order-header">
            <h2>Order Detail #<?php echo $order['id']; ?></h2>
            <a href="pesanan.php" class="back-btn"><i class="fas fa-arrow-left"></i> Back to Orders</a>
        </div>
        
        <div class="order-info">
            <div class="info-row">
                <span class="info-label">Order Date:</span>
                <span><?php echo date('d M Y H:i', strtotime($order['created_at'])); ?></span>
            </div>
            
            <div class="info-row">
                <span class="info-label">Status:</span>
                <span class="status status-<?php echo strtolower($order['status']); ?>">
                    <?php echo htmlspecialchars($order['status']); ?>
                </span>
            </div>
            
            <div class="info-row">
                <span class="info-label">Device:</span>
                <span><?php echo htmlspecialchars($order['device']); ?></span>
            </div>
            
            <div class="info-row">
                <span class="info-label">Service Date/Time:</span>
                <span>
                    <?php echo date('d M Y', strtotime($order['service_date'])); ?> - 
                    <?php echo htmlspecialchars($order['service_time']); ?>
                </span>
            </div>
            
            <div class="info-row">
                <span class="info-label">Address:</span>
                <span><?php echo htmlspecialchars($order['address']); ?></span>
            </div>
            
            <div class="info-row">
                <span class="info-label">Issue Description:</span>
                <span><?php echo htmlspecialchars($order['description']); ?></span>
            </div>
            
            <?php if ($order['technician_id']): ?>
            <div class="info-row">
                <span class="info-label">Technician:</span>
                <span><?php echo htmlspecialchars($order['technician_name']); ?></span>
            </div>
            <?php endif; ?>
            
            <div class="info-row">
                <span class="info-label">Total Payment:</span>
                <span class="total-amount">Rp <?php echo number_format($order['total_amount'], 0, ',', '.'); ?></span>
            </div>
        </div>
        
        <?php if ($order['status'] === 'pending'): ?>
        <div class="order-actions">
            <button class="btn btn-danger" onclick="cancelOrder(<?php echo $order['id']; ?>)">
                <i class="fas fa-times"></i> Cancel Order
            </button>
        </div>
        <?php endif; ?>
    </div>
    
    <script>
        function cancelOrder(orderId) {
            if (confirm('Are you sure you want to cancel this order?')) {
                window.location.href = 'cancel_order.php?id=' + orderId;
            }
        }
    </script>
</body>
</html>