<?php
session_start();
require_once '../db.php';

// Check if user is logged in
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'user' || !isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}

// Check for success message
$success = isset($_GET['success']) ? intval($_GET['success']) : 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pesanan Berhasil</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .floating-container {
            max-width: 500px;
            width: 90%;
            margin: 100px auto;
            padding: 30px;
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            text-align: center;
            animation: fadeInUp 0.5s ease-out;
        }
        
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .alert {
            padding: 15px;
            margin-bottom: 25px;
            border-radius: 8px;
            font-size: 16px;
        }
        
        .alert-success {
            background-color: #e6f7ee;
            color: #0d6832;
            border: 1px solid #a3e9c0;
        }
        
        .alert-info {
            background-color: #e6f2ff;
            color: #0a4b8c;
            border: 1px solid #a3c6e9;
        }
        
        .order-success-actions {
            display: flex;
            flex-direction: column;
            gap: 15px;
            margin-top: 25px;
        }
        
        .btn {
            display: inline-block;
            padding: 12px 20px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        
        .btn-primary {
            background-color: #4a6cf7;
            color: white;
        }
        
        .btn-primary:hover {
            background-color: #3a5ce4;
            transform: translateY(-2px);
        }
        
        .btn-secondary {
            background-color: #f1f3f6;
            color: #333;
            border: 1px solid #ddd;
        }
        
        .btn-secondary:hover {
            background-color: #e6e9ed;
            transform: translateY(-2px);
        }
        
        .fas {
            margin-right: 8px;
        }
        
        body {
            background-color: #f5f7fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
    </style>
</head>
<body>  
    <div class="floating-container">
        <?php if ($success): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> Pesanan berhasil dibuat! Teknisi akan segera menghubungi Anda.
            </div>
            
            <div class="order-success-actions">
                <a href="service.php" class="btn btn-primary">
                    <i class="fas fa-tools"></i> Pesan Layanan Lain
                </a>
                <a href="pesanan.php" class="btn btn-secondary">
                    <i class="fas fa-history"></i> Lihat Riwayat Pesanan
                </a>
            </div>
        <?php else: ?>
            <div class="alert alert-info">
                <i class="fas fa-info-circle"></i> Tidak ada pesanan yang berhasil dibuat.
            </div>
            <a href="service.php" class="btn btn-primary">
                <i class="fas fa-arrow-left"></i> Kembali ke Layanan
            </a>
        <?php endif; ?>
    </div>
</body>
</html>