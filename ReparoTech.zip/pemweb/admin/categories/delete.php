<?php
session_start();
require_once '../../db.php';

if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../../login.php');
    exit;
}

$id = intval($_GET['id'] ?? 0);

// Get category data
$category = $conn->query("SELECT * FROM service_categories WHERE id = $id")->fetch_assoc();

if (!$category) {
    $_SESSION['error'] = "Category not found";
    header('Location: index.php');
    exit;
}

// Handle delete confirmation
if (isset($_POST['confirm_delete'])) {
    // Check if category is used in item_types
    $check = $conn->query("SELECT COUNT(*) as count FROM item_types WHERE service_category_id = $id")->fetch_assoc();
    
    if ($check['count'] > 0) {
        $_SESSION['error'] = "Cannot delete category. It's being used by some items.";
    } else {
        $conn->query("DELETE FROM service_categories WHERE id = $id");
        $_SESSION['success'] = "Category deleted successfully";
    }
    
    header('Location: index.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Category</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <div class="row">
            <div class="col-md-3">
                <?php include '../sidebar.php'; ?>
            </div>
            <div class="col-md-9">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2>Delete Category</h2>
                    <a href="index.php" class="btn btn-secondary">
                        <i class="bi bi-arrow-left"></i> Back to List
                    </a>
                </div>
                
                <div class="card">
                    <div class="card-body">
                        <div class="alert alert-danger">
                            <h4 class="alert-heading">Confirm Deletion</h4>
                            <p>Are you sure you want to delete the category: <strong><?= htmlspecialchars($category['name']) ?></strong>?</p>
                            <hr>
                            <p class="mb-0">This action cannot be undone.</p>
                        </div>
                        
                        <form method="POST">
                            <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                <a href="index.php" class="btn btn-secondary me-md-2">
                                    <i class="bi bi-x-circle"></i> Cancel
                                </a>
                                <button type="submit" name="confirm_delete" class="btn btn-danger">
                                    <i class="bi bi-trash"></i> Confirm Delete
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>