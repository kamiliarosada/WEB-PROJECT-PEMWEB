<?php
session_start();
require_once '../db.php';

// Check if user is logged in and is a technician
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'technician') {
    header('Location: ../login.php');
    exit;
}

$user_id = (int)$_SESSION['user_id'];

// Query untuk mendapatkan semua order yang pernah ditangani oleh teknisi ini
$orders = $conn->query("
    SELECT 
        o.id, 
        o.customer_name as user_name,
        o.device,
        o.phone,
        o.address,
        o.service_date as order_date,
        o.service_time as time_slot,
        COALESCE(o.description, o.notes) as description,
        o.status,
        o.created_at,
        f.rating,
        f.comment as feedback,
        f.created_at as feedback_date
    FROM orders o
    JOIN technicians t ON o.technician_id = t.id
    LEFT JOIN feedback f ON o.id = f.order_id
    WHERE t.user_id = $user_id AND o.status IN ('completed', 'cancelled')
    ORDER BY o.service_date DESC, o.service_time DESC
");

if (!$orders) {
    die("Query failed: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order History</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        .badge-pending {
            background-color: #ffc107;
            color: #000;
        }
        .badge-processing {
            background-color: #0dcaf0;
            color: #000;
        }
        .badge-completed {
            background-color: #198754;
        }
        .badge-cancelled {
            background-color: #dc3545;
        }
        .star-rating {
            color: #ffc107;
            font-size: 1.2rem;
        }
        .feedback-card {
            background-color: #f8f9fa;
            border-radius: 8px;
            padding: 15px;
            margin-top: 10px;
        }
        .no-feedback {
            color: #6c757d;
            font-style: italic;
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <div class="row">
            <div class="col-md-3">
                <?php include 'sidebar.php'; ?>
            </div>
            <div class="col-md-9">
                <h2><i class="bi bi-clock-history"></i> Order History</h2>
                
                <?php if (isset($_GET['success'])): ?>
                    <div class="alert alert-success alert-dismissible fade show">
                        <?= htmlspecialchars($_GET['success']) ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead class="table-light">
                            <tr>
                                <th>Order ID</th>
                                <th>Customer</th>
                                <th>Device</th>
                                <th>Service Date</th>
                                <th>Status</th>
                                <th>Rating</th>
                                <th>Feedback</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($orders && $orders->num_rows > 0): ?>
                                <?php while($order = $orders->fetch_assoc()): ?>
                                <tr>
                                    <td>#<?= $order['id'] ?></td>
                                    <td>
                                        <?= htmlspecialchars($order['user_name']) ?><br>
                                        <small class="text-muted"><?= htmlspecialchars($order['phone']) ?></small>
                                    </td>
                                    <td><?= htmlspecialchars($order['device']) ?></td>
                                    <td>
                                        <?= date('d M Y', strtotime($order['order_date'])) ?><br>
                                        <small><?= htmlspecialchars($order['time_slot']) ?></small>
                                    </td>
                                    <td>
                                        <span class="badge rounded-pill badge-<?= $order['status'] ?>">
                                            <?= ucfirst($order['status']) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($order['rating']): ?>
                                            <div class="star-rating">
                                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                                    <i class="bi bi-star<?= $i <= $order['rating'] ? '-fill' : '' ?>"></i>
                                                <?php endfor; ?>
                                            </div>
                                        <?php else: ?>
                                            <span class="text-muted">No rating</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($order['feedback']): ?>
                                            <small><?= nl2br(htmlspecialchars($order['feedback'])) ?></small><br>
                                            <small class="text-muted">
                                                <?= date('d M Y', strtotime($order['feedback_date'])) ?>
                                            </small>
                                        <?php else: ?>
                                            <span class="no-feedback">No feedback</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="8" class="text-center text-muted py-4">
                                        <i class="bi bi-clipboard-x" style="font-size: 3rem;"></i>
                                        <p class="mt-2">No order history found</p>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>