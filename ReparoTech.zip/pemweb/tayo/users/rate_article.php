<?php
session_start();
require_once '../db.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Anda harus login terlebih dahulu']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Metode request tidak valid']);
    exit;
}

$article_id = isset($_POST['article_id']) ? intval($_POST['article_id']) : 0;
$rating = isset($_POST['rating']) ? intval($_POST['rating']) : 0;

if ($article_id <= 0 || $rating < 1 || $rating > 5) {
    echo json_encode(['success' => false, 'message' => 'Data tidak valid']);
    exit;
}

// Check if article exists
$article_check = $conn->prepare("SELECT id FROM articles WHERE id = ?");
$article_check->bind_param("i", $article_id);
$article_check->execute();
if ($article_check->get_result()->num_rows === 0) {
    echo json_encode(['success' => false, 'message' => 'Artikel tidak ditemukan']);
    exit;
}

// Check if user has already rated this article
$check_stmt = $conn->prepare("SELECT id FROM article_ratings WHERE article_id = ? AND user_id = ?");
$check_stmt->bind_param("ii", $article_id, $_SESSION['user_id']);
$check_stmt->execute();
if ($check_stmt->get_result()->num_rows > 0) {
    echo json_encode(['success' => false, 'message' => 'Anda sudah memberikan rating untuk artikel ini']);
    exit;
}

// Insert new rating
$insert_stmt = $conn->prepare("INSERT INTO article_ratings (article_id, user_id, rating) VALUES (?, ?, ?)");
$insert_stmt->bind_param("iii", $article_id, $_SESSION['user_id'], $rating);
if ($insert_stmt->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => 'Gagal menyimpan rating']);
}