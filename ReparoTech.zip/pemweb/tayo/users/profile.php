<?php
session_start();
require_once '../db.php';

// Cek login
if (!isset($_SESSION['username'])) {
    header('Location: ../login.php');
    exit;
}

$user_id = (int)$_SESSION['user_id'];

// Ambil data pengguna
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_profile'])) {
        $name = $conn->real_escape_string($_POST['name']);
        $email = $conn->real_escape_string($_POST['email']);
        $phone = $conn->real_escape_string($_POST['phone']);
        $country = $conn->real_escape_string($_POST['country']);
        $gender = $conn->real_escape_string($_POST['gender']);
        
        // Konversi gender
        $db_gender = 'other';
        if ($gender === 'Laki-laki') $db_gender = 'male';
        if ($gender === 'Perempuan') $db_gender = 'female';
        
        // Cek email
        if ($email !== $user['email']) {
            $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $email_check = $stmt->get_result();
            
            if ($email_check->num_rows > 0) {
                $error_message = "Email sudah digunakan!";
            } else {
                $stmt = $conn->prepare("UPDATE users SET name=?, email=?, phone=?, country=?, gender=? WHERE id=?");
                $stmt->bind_param("sssssi", $name, $email, $phone, $country, $db_gender, $user_id);
                $stmt->execute();
                $stmt->close();
                
                // Refresh data
                $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
                $stmt->bind_param("i", $user_id);
                $stmt->execute();
                $result = $stmt->get_result();
                $user = $result->fetch_assoc();
                $stmt->close();
                
                $success_message = "Profil berhasil diperbarui!";
            }
        } else {
            $stmt = $conn->prepare("UPDATE users SET name=?, phone=?, country=?, gender=? WHERE id=?");
            $stmt->bind_param("ssssi", $name, $phone, $country, $db_gender, $user_id);
            $stmt->execute();
            $stmt->close();
            
            // Refresh data
            $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $user = $result->fetch_assoc();
            $stmt->close();
            
            $success_message = "Profil berhasil diperbarui!";
        }
    }
    
    // Handle password change (PLAINTEXT)
    if (isset($_POST['change_password'])) {
        $current_password = $_POST['current_password'];
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];
        
        // Bandingkan password plaintext
        if ($current_password === $user['password']) {
            if ($new_password === $confirm_password) {
                // Update password (plaintext)
                $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
                $stmt->bind_param("si", $new_password, $user_id);
                $stmt->execute();
                $stmt->close();
                
                $success_message = "Password berhasil diubah!";
            } else {
                $error_message = "Password baru tidak cocok!";
            }
        } else {
            $error_message = "Password saat ini salah!";
        }
    }
}

$display_gender = 'Lainnya';
if ($user['gender'] === 'male') $display_gender = 'Laki-laki';
if ($user['gender'] === 'female') $display_gender = 'Perempuan';
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Profil Pengguna | Reparo</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: linear-gradient(135deg, #f5f7fa 0%, #e4e8f0 100%);
      color: #333;
      line-height: 1.6;
      min-height: 100vh;
    }
    
    /* Header Navigation */
    .nav-container {
      display: flex;
      justify-content: space-between;
      align-items: center;
      max-width: 1200px;
      margin: 0 auto;
      padding: 15px 20px;
    }
    
    .logo {
      display: flex;
      align-items: center;
      gap: 10px;
      font-size: 1.5rem;
      font-weight: 700;
      color: #2563eb;
      text-decoration: none;
    }
    
    .logo i {
      font-size: 1.8rem;
    }
    
    .nav-links {
      display: flex;
      gap: 25px;
    }
    
    .nav-links a {
      text-decoration: none;
      color: #1e293b;
      font-weight: 500;
      transition: color 0.3s ease;
    }
    
    .nav-links a:hover {
      color: #2563eb;
    }
    
    .user-actions {
      display: flex;
      align-items: center;
      gap: 15px;
    }
    
    .user-actions a {
      text-decoration: none;
      color: #1e293b;
      transition: color 0.3s ease;
    }
    
    .user-actions a:hover {
      color: #2563eb;
    }
    
    .user-profile {
      display: flex;
      align-items: center;
      gap: 8px;
      cursor: pointer;
      position: relative;
    }
    
    .user-img {
      width: 35px;
      height: 35px;
      border-radius: 50%;
      background: #2563eb;
      color: white;
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 600;
    }
    
    .dropdown-menu {
      position: absolute;
      top: 45px;
      right: 0;
      background: white;
      border-radius: 8px;
      box-shadow: 0 5px 15px rgba(0,0,0,0.1);
      padding: 10px 0;
      min-width: 180px;
      display: none;
      z-index: 100;
    }
    
    .dropdown-menu a {
      display: block;
      padding: 8px 15px;
      color: #334155;
      text-decoration: none;
      transition: background 0.3s;
    }
    
    .dropdown-menu a:hover {
      background: #f1f5f9;
    }
    
    .user-profile:hover .dropdown-menu {
      display: block;
    }
    
    .container {
      max-width: 1200px;
      margin: 30px auto;
      background: white;
      border-radius: 15px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
      overflow: hidden;
    }
    
    .profile-header {
      background: linear-gradient(90deg, #2563eb 0%, #1d4ed8 100%);
      color: white;
      padding: 30px;
      text-align: center;
      position: relative;
      overflow: hidden;
    }
    
    .profile-header::before {
      content: "";
      position: absolute;
      top: -50%;
      left: -50%;
      width: 200%;
      height: 200%;
      background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
      transform: rotate(30deg);
    }
    
    .profile-header h1 {
      font-size: 2.8rem;
      margin-bottom: 10px;
      text-shadow: 2px 2px 4px rgba(0,0,0,0.2);
      position: relative;
    }
    
    .profile-content {
      display: flex;
      flex-wrap: wrap;
      padding: 30px;
    }
    
    .profile-section {
      flex: 1;
      min-width: 300px;
      padding: 20px;
    }
    
    .profile-card {
      background: white;
      border-radius: 12px;
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
      padding: 30px;
      margin-bottom: 30px;
    }
    
    .profile-card h2 {
      color: #2563eb;
      margin-bottom: 20px;
      font-size: 1.5rem;
      border-bottom: 2px solid #e2e8f0;
      padding-bottom: 10px;
    }
    
    .form-group {
      margin-bottom: 20px;
    }
    
    .form-group label {
      display: block;
      margin-bottom: 8px;
      font-weight: 600;
      color: #334155;
    }
    
    .form-control {
      width: 100%;
      padding: 12px 15px;
      border: 1px solid #cbd5e1;
      border-radius: 8px;
      font-size: 1rem;
      transition: border-color 0.3s;
    }
    
    .form-control:focus {
      outline: none;
      border-color: #2563eb;
      box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
    }
    
    .btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      padding: 12px 25px;
      background: linear-gradient(90deg, #2563eb 0%, #1d4ed8 100%);
      color: white;
      text-decoration: none;
      border-radius: 8px;
      font-weight: 600;
      transition: all 0.3s ease;
      border: none;
      cursor: pointer;
      box-shadow: 0 4px 10px rgba(37, 99, 235, 0.3);
    }
    
    .btn:hover {
      background: linear-gradient(90deg, #1d4ed8 0%, #1e40af 100%);
      box-shadow: 0 6px 15px rgba(37, 99, 235, 0.4);
      transform: translateY(-2px);
    }
    
    .btn i {
      margin-right: 8px;
    }
    
    .btn-block {
      display: block;
      width: 100%;
    }
    
    .alert {
      padding: 15px;
      border-radius: 8px;
      margin-bottom: 20px;
    }
    
    .alert-success {
      background-color: #d1fae5;
      color: #065f46;
      border: 1px solid #a7f3d0;
    }
    
    .alert-danger {
      background-color: #fee2e2;
      color: #b91c1c;
      border: 1px solid #fecaca;
    }
    
    .profile-avatar {
      text-align: center;
      margin-bottom: 20px;
    }
    
    .avatar {
      width: 120px;
      height: 120px;
      border-radius: 50%;
      background: #2563eb;
      color: white;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 3rem;
      font-weight: 600;
      margin: 0 auto 15px;
    }
    
    .avatar-upload {
      display: flex;
      justify-content: center;
      margin-top: 15px;
    }
    
    .avatar-upload input {
      display: none;
    }
    
    .avatar-upload label {
      cursor: pointer;
      color: #2563eb;
      font-weight: 500;
    }
    
    .avatar-upload label:hover {
      text-decoration: underline;
    }
    
    @media (max-width: 768px) {
      .profile-header h1 {
        font-size: 2.2rem;
      }
      
      .profile-content {
        flex-direction: column;
      }
      
      .profile-section {
        width: 100%;
      }
    }
    
    @media (max-width: 480px) {
      .profile-header {
        padding: 20px;
      }
      
      .profile-header h1 {
        font-size: 1.8rem;
      }
    }
  </style>
</head>
<body>

  <!-- Navigation Bar -->
  <div class="nav-container">
    <a href="../index.php" class="logo">
      <i class="fas fa-tools"></i>
      <span>ReparoTech</span>
    </a>
    
    <div class="nav-links">
      <a href="../index.php"><i class="fas fa-home"></i> Beranda</a>
      <a href="service.php"><i class="fas fa-headset"></i> Layanan</a>
      <a href="pesanan.php"><i class="fas fa-clipboard-list"></i> Pesanan</a>
       <a href="riwayat-pesanan.php"><i class="fas fa-clipboard-list"></i> Riwayat Pesanan</a>
      <a href="artikel.php"><i class="fas fa-clipboard-list"></i> Artikel</a>
    </div>
    
    <div class="user-actions">
      <div class="user-profile">
        <div class="user-img"><?php echo strtoupper(substr($_SESSION['username'], 0, 1)); ?></div>
        <span><?php echo htmlspecialchars($_SESSION['username']); ?></span>
        <div class="dropdown-menu">
          <a href="profile.php"><i class="fas fa-user"></i> Profil</a>
          <a href="riwayat-pesanan.php"><i class="fas fa-history"></i> Riwayat</a>
          <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
      </div>
    </div>
  </div>

  <!-- Profile Content -->
  <div class="container">
    <div class="profile-header">
      <h1>Profil Pengguna</h1>
      <p>Kelola informasi profil dan keamanan akun Anda</p>
    </div>
    
    <div class="profile-content">
      <div class="profile-section">
        <div class="profile-card">
          <div class="profile-avatar">
            <div class="avatar">
              <?php echo strtoupper(substr($user['name'], 0, 1)); ?>
            </div>
            <div class="avatar-upload">
              <input type="file" id="avatar-upload" accept="image/*">
              <label for="avatar-upload"><i class="fas fa-camera"></i> Ubah Foto Profil</label>
            </div>
          </div>
          
          <?php if (isset($success_message)): ?>
            <div class="alert alert-success">
              <i class="fas fa-check-circle"></i> <?php echo $success_message; ?>
            </div>
          <?php endif; ?>
          
          <?php if (isset($error_message)): ?>
            <div class="alert alert-danger">
              <i class="fas fa-exclamation-circle"></i> <?php echo $error_message; ?>
            </div>
          <?php endif; ?>
          
          <h2>Informasi Profil</h2>
          <form method="POST" action="">
            <div class="form-group">
              <label for="name">Nama Lengkap</label>
              <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($user['name']); ?>" required>
            </div>
            
            <div class="form-group">
              <label for="email">Email</label>
              <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
            </div>
            
            <div class="form-group">
              <label for="phone">Nomor Telepon</label>
              <input type="tel" class="form-control" id="phone" name="phone" value="<?php echo htmlspecialchars($user['phone']); ?>">
            </div>
            
            <div class="form-group">
              <label for="country">Negara</label>
              <input type="text" class="form-control" id="country" name="country" value="<?php echo htmlspecialchars($user['country']); ?>">
            </div>
            
            <div class="form-group">
              <label for="gender">Jenis Kelamin</label>
              <select class="form-control" id="gender" name="gender">
                <option value="Laki-laki" <?php echo ($user['gender'] == 'Laki-laki') ? 'selected' : ''; ?>>Laki-laki</option>
                <option value="Perempuan" <?php echo ($user['gender'] == 'Perempuan') ? 'selected' : ''; ?>>Perempuan</option>
                <option value="Lainnya" <?php echo ($user['gender'] == 'Lainnya') ? 'selected' : ''; ?>>Lainnya</option>
              </select>
            </div>
            
            <button type="submit" name="update_profile" class="btn btn-block">
              <i class="fas fa-save"></i> Simpan Perubahan
            </button>
          </form>
        </div>
      </div>
      
      <div class="profile-section">
        <div class="profile-card">
          <h2>Keamanan Akun</h2>
          <form method="POST" action="">
            <div class="form-group">
              <label for="current_password">Password Saat Ini</label>
              <input type="password" class="form-control" id="current_password" name="current_password" required>
            </div>
            
            <div class="form-group">
              <label for="new_password">Password Baru</label>
              <input type="password" class="form-control" id="new_password" name="new_password" required>
            </div>
            
            <div class="form-group">
              <label for="confirm_password">Konfirmasi Password Baru</label>
              <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
            </div>
            
            <button type="submit" name="change_password" class="btn btn-block">
              <i class="fas fa-key"></i> Ubah Password
            </button>
          </form>
        </div>
        
        <div class="profile-card">
          <h2>Informasi Akun</h2>
          <div class="form-group">
            <label>Username</label>
            <p><?php echo htmlspecialchars($user['username']); ?></p>
          </div>
          
          <div class="form-group">
            <label>Tanggal Bergabung</label>
            <p><?php echo date('d F Y', strtotime($user['created_at'])); ?></p>
          </div>
          
          <div class="form-group">
            <label>Status Akun</label>
            <p><span class="badge" style="background: #d1fae5; color: #065f46; padding: 5px 10px; border-radius: 20px;">Aktif</span></p>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  <script>
    // Simple script to show image preview when avatar is selected
    document.getElementById('avatar-upload').addEventListener('change', function(e) {
      const file = e.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = function(event) {
          document.querySelector('.avatar').style.backgroundImage = `url(${event.target.result})`;
          document.querySelector('.avatar').textContent = '';
        }
        reader.readAsDataURL(file);
      }
    });
  </script>
</body>
</html>