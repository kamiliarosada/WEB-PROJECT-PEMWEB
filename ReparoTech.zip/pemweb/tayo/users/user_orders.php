<?php
session_start();
require_once 'db.php';

$userId = $_SESSION['user_id'];

// Ambil pesanan user
$orders = $conn->query("
    SELECT o.id, o.created_at, o.status, o.total_amount, t.id as tech_id, u.name as tech_name, it.name as item_type
    FROM orders o
    JOIN technicians t ON o.technician_id = t.id
    JOIN users u ON t.user_id = u.id
    JOIN item_types it ON o.item_type_id = it.id
    WHERE o.user_id = $userId
    ORDER BY o.created_at DESC
");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pesanan Saya</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <?php include 'navbar.php'; ?>

    <div class="container mt-4">
        <h2 class="mb-4">Pesanan Saya</h2>
        
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Tanggal</th>
                        <th>Teknisi</th>
                        <th>Jenis Barang</th>
                        <th>Total</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($order = $orders->fetch_assoc()): ?>
                    <tr>
                        <td>#<?= $order['id'] ?></td>
                        <td><?= date('d M Y', strtotime($order['created_at'])) ?></td>
                        <td><?= htmlspecialchars($order['tech_name']) ?></td>
                        <td><?= htmlspecialchars($order['item_type']) ?></td>
                        <td>Rp <?= number_format($order['total_amount'], 0, ',', '.') ?></td>
                        <td>
                            <span class="badge bg-<?= 
                                $order['status'] == 'completed' ? 'success' : 
                                ($order['status'] == 'processing' ? 'info' : 'warning')
                            ?>">
                                <?= ucfirst($order['status']) ?>
                            </span>
                        </td>
                        <td>
                            <a href="view_order.php?id=<?= $order['id'] ?>" class="btn btn-sm btn-primary">
                                <i class="bi bi-eye"></i> Detail
                            </a>
                            <?php if ($order['status'] == 'completed'): ?>
                                <a href="give_feedback.php?order_id=<?= $order['id'] ?>" class="btn btn-sm btn-success">
                                    <i class="bi bi-star"></i> Beri Ulasan
                                </a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>