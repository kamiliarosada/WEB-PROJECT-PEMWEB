<?php
require_once '../db.php';

// Get parameters
$tech_id = isset($_GET['tech_id']) ? intval($_GET['tech_id']) : 0;
$date = isset($_GET['date']) ? $_GET['date'] : '';

if (!$tech_id || !$date) {
    echo json_encode(['is_available' => false]);
    exit;
}

// Check how many orders the technician has on this date
$stmt = $conn->prepare("
    SELECT COUNT(*) as order_count 
    FROM orders 
    WHERE technician_id = ? 
    AND service_date = ? 
    AND status NOT IN ('cancelled', 'rejected')
");
$stmt->bind_param("is", $tech_id, $date);
$stmt->execute();
$result = $stmt->get_result();
$count = $result->fetch_assoc()['order_count'];

// Technician can only take 2 orders per day
$is_available = $count < 2;

echo json_encode(['is_available' => $is_available]);
?>