<?php
$admin_root = '/pemweb/admin/'; 
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://';
$base_url = $protocol . $_SERVER['HTTP_HOST'] . $admin_root;

$menu_items = [
    'dashboard' => [
        'title' => 'Dashboard',
        'icon' => 'speedometer2',
        'url' => 'dashboard.php',
        'children' => []
    ],
    'user_management' => [
        'title' => 'User Management',
        'icon' => 'people',
        'url' => 'users/index.php',
        'children' => []
    ],
    'technician_management' => [
        'title' => 'Technician Management',
        'icon' => 'tools',
        'url' => 'technicians/index.php',
        'children' => []
    ],
    'content_management' => [
        'title' => 'Content Management',
        'icon' => 'file-earmark-text',
        'url' => 'articles/index.php',
        'children' => []
    ],
    'service_categories' => [
        'title' => 'Service Categories',
        'icon' => 'tags',
        'url' => 'categories/index.php',
        'children' => []
    ],
    'order_management' => [
        'title' => 'Order Management',
        'icon' => 'cart',
        'url' => 'orders/index.php',
        'children' => []
    ],
    'reports' => [
        'title' => 'Reports',
        'icon' => 'graph-up',
        'url' => 'stats/index.php',
        'children' => []
    ]
];

function isMenuActive($menuUrl, $currentUri) {
    $menuPath = parse_url($menuUrl, PHP_URL_PATH);
    $currentPath = parse_url($currentUri, PHP_URL_PATH);
    
    if ($menuPath === $currentPath) {
        return true;
    }
    
    if (strpos($currentPath, dirname($menuPath)) === 0) {
        return true;
    }
    
    return false;
}

$current_uri = $_SERVER['REQUEST_URI'];
?>

<div class="list-group" id="adminSideNav">
    <!-- Group: Administration -->
    <div class="list-group-item list-group-item-dark">
        <i class="bi bi-gear"></i> Administration
    </div>
    
    <!-- Dashboard -->
    <a href="<?= $base_url . $menu_items['dashboard']['url'] ?>" 
       class="list-group-item list-group-item-action <?= isMenuActive($base_url . $menu_items['dashboard']['url'], $current_uri) ? 'active' : '' ?>">
        <i class="bi bi-<?= $menu_items['dashboard']['icon'] ?>"></i> <?= $menu_items['dashboard']['title'] ?>
    </a>
    
    <!-- Group: User Management -->
    <div class="list-group-item list-group-item-dark">
        <i class="bi bi-people"></i> User Management
    </div>
    
    <?php foreach(['user_management', 'technician_management'] as $key): ?>
        <a href="<?= $base_url . $menu_items[$key]['url'] ?>" 
           class="list-group-item list-group-item-action <?= isMenuActive($base_url . $menu_items[$key]['url'], $current_uri) ? 'active' : '' ?>">
            <i class="bi bi-<?= $menu_items[$key]['icon'] ?>"></i> <?= $menu_items[$key]['title'] ?>
        </a>
    <?php endforeach; ?>
    
    <!-- Group: Content -->
    <div class="list-group-item list-group-item-dark">
        <i class="bi bi-file-earmark-text"></i> Content
    </div>
    
    <a href="<?= $base_url . $menu_items['content_management']['url'] ?>" 
       class="list-group-item list-group-item-action <?= isMenuActive($base_url . $menu_items['content_management']['url'], $current_uri) ? 'active' : '' ?>">
        <i class="bi bi-<?= $menu_items['content_management']['icon'] ?>"></i> <?= $menu_items['content_management']['title'] ?>
    </a>
    
    <!-- Group: Services -->
    <div class="list-group-item list-group-item-dark">
        <i class="bi bi-list-check"></i> Services
    </div>
    
    <!-- Service Categories (direct link) -->
    <a href="<?= $base_url . $menu_items['service_categories']['url'] ?>" 
       class="list-group-item list-group-item-action <?= isMenuActive($base_url . $menu_items['service_categories']['url'], $current_uri) ? 'active' : '' ?>">
        <i class="bi bi-<?= $menu_items['service_categories']['icon'] ?>"></i> <?= $menu_items['service_categories']['title'] ?>
    </a>
    
    <!-- Group: Orders -->
    <div class="list-group-item list-group-item-dark">
        <i class="bi bi-cart"></i> Orders
    </div>
    
    <a href="<?= $base_url . $menu_items['order_management']['url'] ?>" 
       class="list-group-item list-group-item-action <?= isMenuActive($base_url . $menu_items['order_management']['url'], $current_uri) ? 'active' : '' ?>">
        <i class="bi bi-<?= $menu_items['order_management']['icon'] ?>"></i> <?= $menu_items['order_management']['title'] ?>
    </a>
    
    <!-- Group: Analytics -->
    <div class="list-group-item list-group-item-dark">
        <i class="bi bi-graph-up"></i> Analytics
    </div>
    
    <a href="<?= $base_url . $menu_items['reports']['url'] ?>" 
       class="list-group-item list-group-item-action <?= isMenuActive($base_url . $menu_items['reports']['url'], $current_uri) ? 'active' : '' ?>">
        <i class="bi bi-<?= $menu_items['reports']['icon'] ?>"></i> <?= $menu_items['reports']['title'] ?>
    </a>
    
    <!-- Group: Account -->
    <div class="list-group-item list-group-item-dark">
        <i class="bi bi-person-circle"></i> Account
    </div>
    
    <!-- Profile Management -->
    <a href="<?= $base_url ?>profile/index.php" 
       class="list-group-item list-group-item-action <?= isMenuActive($base_url . 'profile/index.php', $current_uri) ? 'active' : '' ?>">
        <i class="bi bi-person"></i> Manage Profile
    </a>
    
    <!-- Logout -->
    <div class="list-group-item"></div>
    <a href="<?= $base_url ?>../logout.php" class="list-group-item list-group-item-action text-danger">
        <i class="bi bi-box-arrow-right"></i> Logout
    </a>
</div>

<style>
#adminSideNav .active {
    background-color: var(--bs-primary) !important;
    color: white !important;
    font-weight: bold;
    border-color: var(--bs-primary) !important;
}

#adminSideNav .list-group-item-dark {
    background-color: var(--bs-gray-800);
    color: white;
}

#adminSideNav a:not(.active):hover {
    background-color: rgb(148, 144, 144);
}

#adminSideNav a.active i {
    color: white !important;
}
</style>

<script>
document.getElementById('adminSideNav').addEventListener('click', function(e) {
    const target = e.target.closest('a');
    if (!target) return;

    if (target.href.includes('../logout.php')) return;

    console.log('Navigating to:', target.href);

    target.innerHTML = '<i class="bi bi-arrow-repeat"></i> Loading...';
});
</script>