<?php

$admin_root = '/pemweb/admin/';
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://';
$base_url = $protocol . $_SERVER['HTTP_HOST'] . $admin_root;
?>

<nav class="navbar navbar-expand-lg navbar-light" style="background-color: #e3f2fd;">
    <div class="container-fluid">

        <a class="navbar-brand" href="<?= $base_url ?>dashboard.php">
            <i class="bi bi-speedometer2 me-2"></i>Admin Panel
        </a>

        <div class="collapse navbar-collapse" id="navbarContent">
        </div>
    </div>
</nav>

<style>
.navbar {
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    padding: 0.5rem 1rem;
}

.nav-link {
    padding: 0.5rem 1rem;
    border-radius: 0.25rem;
    transition: all 0.2s;
}

.nav-link:hover, .nav-link:focus {
    background-color: rgba(0,0,0,0.05);
}

.dropdown-menu {
    border: none;
    box-shadow: 0 0.5rem 1rem rgba(0,0,0,0.1);
    border-radius: 0.5rem;
    margin-top: 0.5rem;
}

.dropdown-item {
    padding: 0.5rem 1rem;
    border-radius: 0.25rem;
}

.dropdown-item.text-danger {
    color: #dc3545 !important;
}

.dropdown-item.text-danger:hover {
    background-color: rgba(220,53,69,0.1);
}
</style>