<?php
session_start();
require_once '../db.php';

// Check if user is logged in and is a technician
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'technician') {
    header('Location: ../login.php');
    exit;
}

if (!isset($_GET['id'])) {
    header('Location: schedule.php');
    exit;
}

$order_id = (int)$_GET['id'];
$user_id = (int)$_SESSION['user_id'];

// Get order details
$order_query = $conn->query("
    SELECT 
        o.*,
        t.user_id as technician_user_id
    FROM orders o
    JOIN technicians t ON o.technician_id = t.id
    WHERE o.id = $order_id AND t.user_id = $user_id
");

if ($order_query->num_rows === 0) {
    header('Location: schedule.php');
    exit;
}

$order = $order_query->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Details</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        .badge-pending {
            background-color: #ffc107;
            color: #000;
        }
        .badge-processing {
            background-color: #0dcaf0;
            color: #000;
        }
        .badge-completed {
            background-color: #198754;
        }
        .badge-cancelled {
            background-color: #dc3545;
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <div class="row">
            <div class="col-md-3">
                <?php include 'sidebar.php'; ?>
            </div>
            <div class="col-md-9">
                <h2><i class="bi bi-file-text"></i> Order Details</h2>
                
                <?php if (isset($_GET['success'])): ?>
                    <div class="alert alert-success alert-dismissible fade show">
                        <?= htmlspecialchars($_GET['success']) ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <div class="card">
                    <div class="card-header">
                        <h5>Order #<?= $order['id'] ?></h5>
                        <span class="badge rounded-pill badge-<?= $order['status'] ?>">
                            <?= ucfirst($order['status']) ?>
                        </span>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <h6>Customer Information</h6>
                                <p><strong>Name:</strong> <?= htmlspecialchars($order['customer_name']) ?></p>
                                <p><strong>Phone:</strong> <?= htmlspecialchars($order['phone']) ?></p>
                                <p><strong>Address:</strong> <?= htmlspecialchars($order['address']) ?></p>
                            </div>
                            <div class="col-md-6">
                                <h6>Service Details</h6>
                                <p><strong>Device:</strong> <?= htmlspecialchars($order['device']) ?></p>
                                <p><strong>Service Date:</strong> <?= date('d M Y', strtotime($order['service_date'])) ?></p>
                                <p><strong>Time Slot:</strong> <?= htmlspecialchars($order['service_time']) ?></p>
                            </div>
                        </div>
                        
                        <div class="mt-3">
                            <h6>Description/Notes</h6>
                            <p><?= htmlspecialchars($order['description'] ?? $order['notes']) ?></p>
                        </div>
                        
                        <div class="mt-4">
                            <?php if ($order['status'] == 'pending'): ?>
                                <a href="update_status.php?id=<?= $order['id'] ?>&status=processing&from=view" class="btn btn-info">
                                    <i class="bi bi-check-circle"></i> Accept Order
                                </a>
                                <a href="update_status.php?id=<?= $order['id'] ?>&status=cancelled&from=view" class="btn btn-danger">
                                    <i class="bi bi-x-circle"></i> Reject Order
                                </a>
                            <?php elseif ($order['status'] == 'processing'): ?>
                                <a href="update_status.php?id=<?= $order['id'] ?>&status=completed&from=view" class="btn btn-success">
                                    <i class="bi bi-check-circle"></i> Mark as Completed
                                </a>
                            <?php endif; ?>
                            <a href="schedule.php" class="btn btn-secondary">
                                <i class="bi bi-arrow-left"></i> Back to Schedule
                            </a>
                        </div>
                    </div>
                    <div class="card-footer text-muted">
                        Created at: <?= date('d M Y H:i', strtotime($order['created_at'])) ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>