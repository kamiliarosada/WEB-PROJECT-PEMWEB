<nav class="navbar navbar-expand-lg navbar-light" style="background-color: #e3f2fd;">
    <div class="container-fluid">
        <!-- Brand/logo -->
        <a class="navbar-brand" href="<?= $base_url ?>dashboard.php">
            <i class="bi bi-tools me-2"></i>Technician Panel
        </a>
    </div>
</nav>

<style>
.navbar {
    box-shadow: 0 2px 4px rgb(254, 253, 253);
    padding: 0.5rem 1rem;
}

.nav-link {
    padding: 0.5rem 1rem;
    border-radius: 0.25rem;
    transition: all 0.2s;
}

.dropdown-footer {
    background-color:rgb(5, 46, 251);
    border-bottom-left-radius: 0.5rem;
    border-bottom-right-radius: 0.5rem;
}
</style>
