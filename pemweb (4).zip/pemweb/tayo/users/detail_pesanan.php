<?php
session_start();
require_once '../db.php';

// Check if user is logged in and has user role
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'user') {
    header('Location: ../login.php');
    exit;
}

// Check if order ID is provided
if (!isset($_GET['id'])) {
    header('Location: pesanan.php');
    exit;
}

$order_id = intval($_GET['id']);
$user_id = $_SESSION['user_id'];

// Get order details
$order_query = $conn->prepare("
    SELECT o.*, u.name as technician_name, u.profile_picture as tech_image, 
           t.rate, t.specialization, t.experience,
           s.name as service_name, s.description as service_description
    FROM orders o
    LEFT JOIN technicians t ON o.technician_id = t.id
    LEFT JOIN users u ON t.user_id = u.id
    LEFT JOIN services s ON o.service_id = s.id
    WHERE o.id = ? AND o.user_id = ?
");
$order_query->bind_param("ii", $order_id, $user_id);
$order_query->execute();
$order = $order_query->get_result()->fetch_assoc();

if (!$order) {
    header('Location: pesanan.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Pesanan - ReparoTech</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* Gunakan CSS yang sama dengan pesanan.php */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f5f7fa;
            color: #333;
        }
        
        .nav-container {
            background-color: #4a6cf7;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        
        /* ... (salin semua CSS dari pesanan.php) ... */
        
        .order-detail-container {
            background-color: white;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.05);
            margin-bottom: 30px;
        }
        
        .order-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 20px;
            border-bottom: 1px solid #eee;
        }
        
        .order-id {
            font-size: 24px;
            font-weight: bold;
            color: #4a6cf7;
        }
        
        .order-status {
            padding: 8px 15px;
            border-radius: 20px;
            font-weight: 500;
            text-transform: capitalize;
        }
        
        .order-body {
            display: flex;
            gap: 30px;
        }
        
        .order-section {
            flex: 1;
        }
        
        .section-title {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 15px;
            color: #4a6cf7;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .detail-row {
            display: flex;
            margin-bottom: 10px;
        }
        
        .detail-label {
            width: 150px;
            font-weight: 500;
            color: #666;
        }
        
        .detail-value {
            flex: 1;
        }
        
        .tech-card {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 15px;
            background-color: #f8f9fa;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        
        .tech-avatar {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            object-fit: cover;
        }
        
        .tech-info h4 {
            margin: 0 0 5px 0;
            font-size: 18px;
        }
        
        .tech-info p {
            margin: 5px 0;
            color: #666;
        }
        
        .service-card {
            background-color: #f8f9fa;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 20px;
        }
        
        .service-card h4 {
            margin: 0 0 10px 0;
            font-size: 18px;
        }
        
        .service-card p {
            margin: 5px 0;
            color: #666;
        }
        
        .action-buttons {
            display: flex;
            gap: 10px;
            margin-top: 20px;
        }
        
        .back-button {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #6c757d;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: all 0.3s;
        }
        
        .back-button:hover {
            background-color: #5a6268;
        }
    </style>
</head>
<body>
    <!-- Navigation Bar (sama dengan pesanan.php) -->
    <div class="nav-container">
        <a href="../index.php" class="logo">
            <i class="fas fa-tools"></i>
            <span>ReparoTech</span>
        </a>
        
        <div class="nav-links">
            <a href="../index.php"><i class="fas fa-home"></i> Beranda</a>
            <a href="service.php"><i class="fas fa-headset"></i> Layanan</a>
            <a href="pesanan.php" class="active"><i class="fas fa-clipboard-list"></i> Pesanan</a>
            <a href="riwayat-pesanan.php"><i class="fas fa-history"></i> Riwayat</a>
            <a href="artikel.php"><i class="fas fa-clipboard-list"></i> Artikel</a>
        </div>
        
        <div class="user-actions">
            <div class="user-profile">
                <div class="user-img"><?php echo strtoupper(substr($_SESSION['username'], 0, 1)); ?></div>
                <span><?php echo htmlspecialchars($_SESSION['username']); ?></span>
                <div class="dropdown-menu">
                    <a href="profile.php"><i class="fas fa-user"></i> Profil</a>
                    <a href="riwayat-pesanan.php"><i class="fas fa-history"></i> Riwayat</a>
                    <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </div>
            </div>
        </div>
    </div>
    
    <div class="container">
        <a href="pesanan.php" class="back-button">
            <i class="fas fa-arrow-left"></i> Kembali ke Pesanan Aktif
        </a>
        
        <div class="order-detail-container">
            <div class="order-header">
                <div class="order-id">Pesanan #<?php echo $order['id']; ?></div>
                <div class="order-status status-<?php echo strtolower($order['status']); ?>">
                    <?php echo htmlspecialchars($order['status']); ?>
                </div>
            </div>
            
            <div class="order-body">
                <div class="order-section">
                    <h3 class="section-title"><i class="fas fa-info-circle"></i> Informasi Pesanan</h3>
                    
                    <div class="detail-row">
                        <div class="detail-label">Tanggal Pesanan</div>
                        <div class="detail-value">
                            <?php echo date('d M Y', strtotime($order['order_date'])); ?>
                        </div>
                    </div>
                    
                    <div class="detail-row">
                        <div class="detail-label">Tanggal Servis</div>
                        <div class="detail-value">
                            <?php echo date('d M Y', strtotime($order['service_date'])); ?> 
                            pukul <?php echo htmlspecialchars($order['service_time']); ?>
                        </div>
                    </div>
                    
                    <div class="detail-row">
                        <div class="detail-label">Perangkat</div>
                        <div class="detail-value">
                            <?php echo htmlspecialchars($order['device']); ?>
                        </div>
                    </div>
                    
                    <div class="detail-row">
                        <div class="detail-label">Keluhan</div>
                        <div class="detail-value">
                            <?php echo htmlspecialchars($order['issue_description']); ?>
                        </div>
                    </div>
                    
                    <div class="detail-row">
                        <div class="detail-label">Alamat</div>
                        <div class="detail-value">
                            <?php echo htmlspecialchars($order['address']); ?>
                        </div>
                    </div>
                    
                    <div class="detail-row">
                        <div class="detail-label">Total Biaya</div>
                        <div class="detail-value">
                            <strong>Rp <?php echo number_format($order['total_amount'], 0, ',', '.'); ?></strong>
                        </div>
                    </div>
                </div>
                
                <div class="order-section">
                    <h3 class="section-title"><i class="fas fa-user-cog"></i> Teknisi</h3>
                    
                    <div class="tech-card">
                        <img src="<?php echo htmlspecialchars($order['tech_image'] ?: 'https://randomuser.me/api/portraits/men/'.rand(1,99).'.jpg'); ?>" class="tech-avatar">
                        <div class="tech-info">
                            <h4><?php echo htmlspecialchars($order['technician_name']); ?></h4>
                            <p><i class="fas fa-star"></i> Rate: Rp <?php echo number_format($order['rate'], 0, ',', '.'); ?>/jam</p>
                            <p><i class="fas fa-certificate"></i> Spesialisasi: <?php echo htmlspecialchars($order['specialization']); ?></p>
                            <p><i class="fas fa-briefcase"></i> Pengalaman: <?php echo htmlspecialchars($order['experience']); ?> tahun</p>
                        </div>
                    </div>
                    
                    <h3 class="section-title"><i class="fas fa-concierge-bell"></i> Layanan</h3>
                    
                    <div class="service-card">
                        <h4><?php echo htmlspecialchars($order['service_name']); ?></h4>
                        <p><?php echo htmlspecialchars($order['service_description']); ?></p>
                    </div>
                </div>
            </div>
            
            <?php if ($order['status'] === 'pending'): ?>
                <div class="action-buttons">
                    <button class="action-btn btn-danger" onclick="cancelOrder(<?php echo $order['id']; ?>)">
                        <i class="fas fa-times"></i> Batalkan Pesanan
                    </button>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <script>
        function cancelOrder(orderId) {
            if (confirm('Apakah Anda yakin ingin membatalkan pesanan ini?')) {
                // Kirim request AJAX untuk membatalkan pesanan
                fetch(`cancel_order.php?id=${orderId}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('Pesanan berhasil dibatalkan');
                        window.location.href = 'pesanan.php';
                    } else {
                        alert('Gagal membatalkan pesanan: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Terjadi kesalahan saat membatalkan pesanan');
                });
            }
        }
    </script>
</body>
</html>