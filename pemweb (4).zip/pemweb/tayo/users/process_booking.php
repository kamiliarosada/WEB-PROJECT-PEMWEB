<?php
session_start();
require_once '../db.php';

// Check if user is logged in
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'user' || !isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}

// Process form data
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Validasi dan sanitasi input
        $tech_id = intval($_POST['tech_id']);
        $name = trim($conn->real_escape_string($_POST['name']));
        $phone = trim($conn->real_escape_string($_POST['phone']));
        $address = trim($conn->real_escape_string($_POST['address']));
        $device = trim($conn->real_escape_string($_POST['device']));
        $date = $conn->real_escape_string($_POST['date']);
        $time = $conn->real_escape_string($_POST['time']);
        $notes = trim($conn->real_escape_string($_POST['notes'] ?? ''));
        $user_id = $_SESSION['user_id'];

        // Validasi dasar
        if (empty($name) || empty($phone) || empty($address) || empty($device) || empty($date) || empty($time)) {
            throw new Exception('Semua field wajib diisi');
        }

        // Validasi format telepon
        if (!preg_match('/^[0-9]{10,15}$/', $phone)) {
            throw new Exception('Format nomor handphone tidak valid');
        }

        // Validasi tanggal tidak boleh sebelum hari ini
        $today = date('Y-m-d');
        if ($date < $today) {
            throw new Exception('Tanggal booking tidak boleh sebelum hari ini');
        }

        // Verifikasi teknisi
        $tech_check = $conn->prepare("SELECT t.id FROM technicians t 
                                    JOIN users u ON t.user_id = u.id 
                                    WHERE u.id = ? AND u.role = 'technician'");
        $tech_check->bind_param("i", $tech_id);
        $tech_check->execute();
        $tech_result = $tech_check->get_result();
        
        if ($tech_result->num_rows === 0) {
            throw new Exception('Teknisi tidak valid atau tidak ditemukan');
        }
        
        $tech_data = $tech_result->fetch_assoc();
        $valid_tech_id = $tech_data['id'];

        // Dapatkan rate teknisi
        $rate_query = $conn->prepare("SELECT rate FROM technicians WHERE id = ?");
        $rate_query->bind_param("i", $valid_tech_id);
        $rate_query->execute();
        $rate_result = $rate_query->get_result();
        
        if ($rate_result->num_rows === 0) {
            throw new Exception('Data rate teknisi tidak ditemukan');
        }
        
        $rate_row = $rate_result->fetch_assoc();
        $rate = $rate_row['rate'] ?? 50000;
        $total_amount = $rate * 2; // Contoh: 2 jam service

        // Mulai transaksi
        $conn->begin_transaction();

        try {
            // Masukkan ke tabel orders dengan semua kolom yang diperlukan
            $sql = "INSERT INTO orders (
                user_id, 
                technician_id, 
                customer_name, 
                phone, 
                address, 
                device, 
                service_date, 
                service_time, 
                notes, 
                description, 
                status, 
                total_amount, 
                created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?, NOW())";
            
            // Buat deskripsi order
            $description .= "Catatan: " . (!empty($notes) ? $notes : 'Tidak ada catatan');
            
            $stmt = $conn->prepare($sql);
            $stmt->bind_param(
                "iissssssssd", 
                $user_id, 
                $valid_tech_id,
                $name,
                $phone,
                $address,
                $device,
                $date,
                $time,
                $notes,
                $description,
                $total_amount
            );
            
            if (!$stmt->execute()) {
                throw new Exception('Gagal membuat pesanan: ' . $conn->error);
            }

            $order_id = $conn->insert_id;

            $conn->commit();
            header('Location: order.php?success=1');
            exit;
        } catch (Exception $e) {
            $conn->rollback();
            throw $e;
        }
    } catch (Exception $e) {
        header('Location: service.php?error=' . urlencode($e->getMessage()));
        exit;
    }
} else {
    header('Location: service.php');
    exit;
}