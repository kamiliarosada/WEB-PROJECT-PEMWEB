<?php
session_start();
require_once '../db.php';

// Check if user is logged in and has user role
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'user') {
    header('Location: ../login.php');
    exit;
}

// Get user ID from session
$user_id = $_SESSION['user_id'];

// Show success/error messages
if (isset($_SESSION['success'])) {
    $success_message = $_SESSION['success'];
    unset($_SESSION['success']);
}

if (isset($_SESSION['error'])) {
    $error_message = $_SESSION['error'];
    unset($_SESSION['error']);
}

// Get active orders (status not completed or cancelled)
$active_orders = $conn->query("
    SELECT o.*, u.name as technician_name, u.profile_picture as tech_image, t.rate
    FROM orders o
    LEFT JOIN technicians t ON o.technician_id = t.id
    LEFT JOIN users u ON t.user_id = u.id
    WHERE o.user_id = $user_id 
    AND o.status NOT IN ('completed', 'cancelled')
    ORDER BY o.service_date DESC, o.service_time DESC
");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pesanan Aktif - ReparoTech</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #e4e8f0 100%);
            color: #333;
            line-height: 1.6;
            min-height: 100vh;
        }
        
        /* Header Navigation */
        .nav-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1200px;
            margin: 0 auto;
            padding: 15px 20px;
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .logo {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 1.5rem;
            font-weight: 700;
            color: #2563eb;
            text-decoration: none;
        }
        
        .logo i {
            font-size: 1.8rem;
        }
        
        .nav-links {
            display: flex;
            gap: 25px;
        }
        
        .nav-links a {
            text-decoration: none;
            color: #1e293b;
            font-weight: 500;
            transition: color 0.3s ease;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .nav-links a:hover {
            color: #2563eb;
        }
        
        .nav-links a.active {
            color: #2563eb;
            font-weight: 600;
        }
        
        .user-actions {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .user-actions a {
            text-decoration: none;
            color: #1e293b;
            transition: color 0.3s ease;
        }
        
        .user-actions a:hover {
            color: #2563eb;
        }
        
        .user-profile {
            display: flex;
            align-items: center;
            gap: 8px;
            cursor: pointer;
            position: relative;
        }
        
        .user-img {
            width: 35px;
            height: 35px;
            border-radius: 50%;
            background: #2563eb;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
        }
        
        .dropdown-menu {
            position: absolute;
            top: 45px;
            right: 0;
            background: white;
            border-radius: 8px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            padding: 10px 0;
            min-width: 180px;
            display: none;
            z-index: 100;
        }
        
        .dropdown-menu a {
            display: block;
            padding: 8px 15px;
            color: #334155;
            text-decoration: none;
            transition: background 0.3s;
        }
        
        .dropdown-menu a:hover {
            background: #f1f5f9;
        }
        
        .user-profile:hover .dropdown-menu {
            display: block;
        }
        
        .container {
            max-width: 1200px;
            margin: 30px auto;
            padding: 0 20px;
        }
        
        .section-title {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin: 40px 0 20px;
        }
        
        .section-title h2 {
            font-size: 24px;
            color: #333;
            margin: 0;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .section-title i {
            color: #4a6cf7;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 40px;
            background-color: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.05);
        }
        
        th, td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        
        th {
            background-color: #4a6cf7;
            color: white;
            font-weight: 500;
        }
        
        tr:hover {
            background-color: #f8f9fa;
        }
        
        .status {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
            text-transform: capitalize;
        }
        
        .status-pending {
            background-color: #fff3cd;
            color: #856404;
        }
        
        .status-processing {
            background-color: #cce5ff;
            color: #004085;
        }
        
        .action-btn {
            padding: 8px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }
        
        .action-btn i {
            font-size: 12px;
        }
        
        .btn-primary {
            background-color: #4a6cf7;
            color: white;
        }
        
        .btn-primary:hover {
            background-color: #3a5ce4;
        }
        
        .btn-danger {
            background-color: #dc3545;
            color: white;
        }
        
        .btn-danger:hover {
            background-color: #c82333;
        }
        
        .tech-info {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .tech-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
        }
        
        .no-orders {
            text-align: center;
            padding: 40px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.05);
        }
        
        .no-orders i {
            font-size: 50px;
            color: #ddd;
            margin-bottom: 20px;
        }
        
        .no-orders p {
            color: #777;
            margin-top: 10px;
        }
        
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
        }
        
        .alert-success {
            background-color: #d4edda;
            color: #155724;
        }
        
        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
        }
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <div class="nav-container">
        <a href="../index.php" class="logo">
            <i class="fas fa-tools"></i>
            <span>ReparoTech</span>
        </a>
        
        <div class="nav-links">
            <a href="../index.php"><i class="fas fa-home"></i> Beranda</a>
            <a href="service.php"><i class="fas fa-headset"></i> Layanan</a>
            <a href="pesanan_aktif.php" class="active"><i class="fas fa-clipboard-list"></i> Pesanan Aktif</a>
            <a href="riwayat_pesanan.php"><i class="fas fa-history"></i> Riwayat Pesanan</a>
            <a href="artikel.php"><i class="fas fa-newspaper"></i> Artikel</a>
        </div>
        
        <div class="user-actions">
            <div class="user-profile">
                <div class="user-img"><?php echo strtoupper(substr($_SESSION['username'], 0, 1)); ?></div>
                <span><?php echo htmlspecialchars($_SESSION['username']); ?></span>
                <div class="dropdown-menu">
                    <a href="profile.php"><i class="fas fa-user"></i> Profil</a>
                    <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </div>
            </div>
        </div>
    </div>
    
    <div class="container">
        <?php if (isset($success_message)): ?>
            <div class="alert alert-success">
                <?php echo $success_message; ?>
            </div>
        <?php endif; ?>
        
        <?php if (isset($error_message)): ?>
            <div class="alert alert-error">
                <?php echo $error_message; ?>
            </div>
        <?php endif; ?>
        
        <!-- Active Orders Section -->
        <div class="section-title">
            <h2><i class="fas fa-tasks"></i> Pesanan Aktif</h2>
            <a href="service.php" class="action-btn btn-primary">
                <i class="fas fa-plus"></i> Pesan Layanan Baru
            </a>
        </div>
        
        <?php if ($active_orders->num_rows > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>ID Pesanan</th>
                        <th>Teknisi</th>
                        <th>Perangkat</th>
                        <th>Tanggal/Waktu</th>
                        <th>Status</th>
                        <th>Total</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($order = $active_orders->fetch_assoc()): ?>
                    <tr>
                        <td>#<?php echo $order['id']; ?></td>
                        <td>
                            <?php if ($order['technician_name']): ?>
                            <div class="tech-info">
                                <img src="<?php echo htmlspecialchars($order['tech_image'] ?: 'https://randomuser.me/api/portraits/men/'.rand(1,99).'.jpg'); ?>" class="tech-avatar">
                                <span><?php echo htmlspecialchars($order['technician_name']); ?></span>
                            </div>
                            <?php else: ?>
                                <span>Belum ditugaskan</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo htmlspecialchars($order['device']); ?></td>
                        <td>
                            <?php echo date('d M Y', strtotime($order['service_date'])); ?><br>
                            <?php echo htmlspecialchars($order['service_time']); ?>
                        </td>
                        <td>
                            <span class="status status-<?php echo strtolower($order['status']); ?>">
                                <?php echo htmlspecialchars($order['status']); ?>
                            </span>
                        </td>
                        <td>Rp <?php echo number_format($order['total_amount'], 0, ',', '.'); ?></td>
                        <td>
                            <a href="order_detail.php?id=<?php echo $order['id']; ?>" class="action-btn btn-primary">
                                <i class="fas fa-eye"></i> Detail
                            </a>
                            <?php if ($order['status'] === 'pending'): ?>
                                <button class="action-btn btn-danger" onclick="cancelOrder(<?php echo $order['id']; ?>)">
                                    <i class="fas fa-times"></i> Batalkan
                                </button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="no-orders">
                <i class="fas fa-clipboard-list"></i>
                <h3>Tidak ada pesanan aktif</h3>
                <p>Anda belum memiliki pesanan yang sedang berlangsung.</p>
                <a href="service.php" class="action-btn btn-primary">
                    <i class="fas fa-tools"></i> Pesan Layanan Sekarang
                </a>
            </div>
        <?php endif; ?>
    </div>
    
    <script>
        // Function to cancel order
        function cancelOrder(orderId) {
            if (confirm('Apakah Anda yakin ingin membatalkan pesanan ini?')) {
                window.location.href = 'cancel_order.php?id=' + orderId;
            }
        }
    </script>
</body>
</html>