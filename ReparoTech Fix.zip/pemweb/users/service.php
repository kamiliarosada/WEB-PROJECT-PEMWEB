<?php
session_start();
require_once '../db.php';

// Check if user is logged in and has user role
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'user') {
    header('Location: ../login.php');
    exit;
}

// Get user ID from session
if (!isset($_SESSION['user_id'])) {
    $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->bind_param("s", $_SESSION['username']);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $_SESSION['user_id'] = $user['id'];
}

// Handle check availability request
if (isset($_GET['check_availability'])) {
    $tech_id = isset($_GET['tech_id']) ? intval($_GET['tech_id']) : 0;
    $date = isset($_GET['date']) ? $_GET['date'] : '';

    if (!$tech_id || !$date) {
        echo json_encode(['is_available' => false]);
        exit;
    }

    // Check how many orders the technician has on this date
    $stmt = $conn->prepare("
        SELECT COUNT(*) as order_count 
        FROM orders 
        WHERE technician_id = ? 
        AND service_date = ? 
        AND status NOT IN ('cancelled', 'rejected')
    ");
    $stmt->bind_param("is", $tech_id, $date);
    $stmt->execute();
    $result = $stmt->get_result();
    $count = $result->fetch_assoc()['order_count'];

    // Technician can only take 2 orders per day
    $is_available = $count < 2;

    echo json_encode(['is_available' => $is_available]);
    exit;
}

// Handle order success display
if (isset($_GET['success'])) {
    $success = intval($_GET['success']);
    if ($success) {
        // Show success message
        echo '<!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Pesanan Berhasil</title>
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
            <style>
                .floating-container {
                    max-width: 500px;
                    width: 90%;
                    margin: 100px auto;
                    padding: 30px;
                    background: white;
                    border-radius: 15px;
                    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
                    text-align: center;
                    animation: fadeInUp 0.5s ease-out;
                }
                
                @keyframes fadeInUp {
                    from { opacity: 0; transform: translateY(20px); }
                    to { opacity: 1; transform: translateY(0); }
                }
                
                .alert {
                    padding: 15px;
                    margin-bottom: 25px;
                    border-radius: 8px;
                    font-size: 16px;
                }
                
                .alert-success {
                    background-color: #e6f7ee;
                    color: #0d6832;
                    border: 1px solid #a3e9c0;
                }
                
                .order-success-actions {
                    display: flex;
                    flex-direction: column;
                    gap: 15px;
                    margin-top: 25px;
                }
                
                .btn {
                    display: inline-block;
                    padding: 12px 20px;
                    border-radius: 8px;
                    text-decoration: none;
                    font-weight: 500;
                    transition: all 0.3s ease;
                }
                
                .btn-primary {
                    background-color: #4a6cf7;
                    color: white;
                }
                
                .btn-primary:hover {
                    background-color: #3a5ce4;
                    transform: translateY(-2px);
                }
                
                .btn-secondary {
                    background-color: #f1f3f6;
                    color: #333;
                    border: 1px solid #ddd;
                }
                
                .btn-secondary:hover {
                    background-color: #e6e9ed;
                    transform: translateY(-2px);
                }
                
                .fas { margin-right: 8px; }
                
                body {
                    background-color: #f5f7fa;
                    font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
                }
            </style>
        </head>
        <body>  
            <div class="floating-container">
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> Pesanan berhasil dibuat! Teknisi akan segera menghubungi Anda.
                </div>
                
                <div class="order-success-actions">
                    <a href="service.php" class="btn btn-primary">
                        <i class="fas fa-tools"></i> Pesan Layanan Lain
                    </a>
                    <a href="pesanan_aktif.php" class="btn btn-secondary">
                        <i class="fas fa-history"></i> Lihat Riwayat Pesanan
                    </a>
                </div>
            </div>
        </body>
        </html>';
        exit;
    } else {
        // Show error message
        echo '<!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Pesanan Gagal</title>
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
            <style>
                .floating-container {
                    max-width: 500px;
                    width: 90%;
                    margin: 100px auto;
                    padding: 30px;
                    background: white;
                    border-radius: 15px;
                    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
                    text-align: center;
                }
                
                .alert {
                    padding: 15px;
                    margin-bottom: 25px;
                    border-radius: 8px;
                    font-size: 16px;
                }
                
                .alert-info {
                    background-color: #e6f2ff;
                    color: #0a4b8c;
                    border: 1px solid #a3c6e9;
                }
                
                .btn-primary {
                    display: inline-block;
                    padding: 12px 20px;
                    border-radius: 8px;
                    background-color: #4a6cf7;
                    color: white;
                    text-decoration: none;
                    font-weight: 500;
                    transition: all 0.3s ease;
                }
                
                .btn-primary:hover {
                    background-color: #3a5ce4;
                    transform: translateY(-2px);
                }
                
                .fas { margin-right: 8px; }
                
                body {
                    background-color: #f5f7fa;
                    font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
                }
            </style>
        </head>
        <body>  
            <div class="floating-container">
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i> Tidak ada pesanan yang berhasil dibuat.
                </div>
                <a href="service.php" class="btn btn-primary">
                    <i class="fas fa-arrow-left"></i> Kembali ke Layanan
                </a>
            </div>
        </body>
        </html>';
        exit;
    }
}

// Get selected category from URL
$category_id = isset($_GET['category']) ? intval($_GET['category']) : null;
$tech_id = isset($_GET['tech_id']) ? intval($_GET['tech_id']) : null;

// Get all service categories
$categories = $conn->query("SELECT * FROM service_categories ORDER BY name");

// Get technicians based on selected category
if ($category_id) {
    $technicians = $conn->query("
        SELECT DISTINCT u.id, u.name, u.profile_picture, 
               (SELECT GROUP_CONCAT(sc.name SEPARATOR ', ') 
                FROM service_categories sc 
                JOIN technician_skills ts ON sc.id = ts.service_category_id
                WHERE ts.user_id = u.id) as skills,
               (SELECT AVG(rating) FROM feedback WHERE technician_id = u.id) as avg_rating,
               (SELECT COUNT(*) FROM feedback WHERE technician_id = u.id) as review_count,
               t.rate
        FROM users u
        LEFT JOIN technicians t ON t.user_id = u.id
        JOIN technician_skills ts ON ts.user_id = u.id
        WHERE u.is_verified = 1 
          AND u.role = 'technician' 
          AND ts.service_category_id = $category_id
        ORDER BY u.name
    ");
} else {
    $technicians = $conn->query("
        SELECT DISTINCT u.id, u.name, u.profile_picture, 
              (SELECT GROUP_CONCAT(sc.name SEPARATOR ', ') 
                FROM service_categories sc 
                JOIN technician_skills ts ON sc.id = ts.service_category_id
                WHERE ts.user_id = u.id) as skills,
              (SELECT AVG(rating) FROM feedback WHERE technician_id = u.id) as avg_rating,
              (SELECT COUNT(*) FROM feedback WHERE technician_id = u.id) as review_count,
              t.rate
        FROM technicians t
        JOIN users u ON t.user_id = u.id
        ORDER BY u.name
    ");
}

// Get accurate counts
$total_techs = $conn->query("SELECT COUNT(*) as count FROM technicians")->fetch_assoc()['count'];
$avg_rating_result = $conn->query("SELECT AVG(rating) as avg FROM feedback");
$avg_rating = $avg_rating_result->fetch_assoc()['avg'];
$satisfaction = $avg_rating ? round(($avg_rating/5)*100) : 97;
$item_types = $conn->query("SELECT COUNT(*) as count FROM item_types")->fetch_assoc()['count'];

// If tech_id is provided, get technician details
if ($tech_id) {
    $tech_stmt = $conn->prepare("
        SELECT u.id, u.name, u.profile_picture, u.email, u.phone, u.country,
               t.specialization, t.experience_years, t.certification, t.rate
        FROM technicians t
        JOIN users u ON t.user_id = u.id
        WHERE u.id = ?
    ");
    $tech_stmt->bind_param("i", $tech_id);
    $tech_stmt->execute();
    $selected_tech = $tech_stmt->get_result()->fetch_assoc();
    
    $tech_rating = $conn->query("SELECT AVG(rating) as avg_rating FROM feedback WHERE technician_id = $tech_id")->fetch_assoc()['avg_rating'] ?? 4.5;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Service Elektronik | ReparoTech</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link rel="stylesheet" href="../assets/style_service.css">
</head>
<body>

  <!-- Navigation Bar -->
  <div class="nav-container">
    <a href="../index.php" class="logo">
      <i class="fas fa-tools"></i>
      <span>ReparoTech</span>
    </a>
    
    <div class="nav-links">
      <a href="../index.php"><i class="fas fa-home"></i> Beranda</a>
      <a href="service.php" class="active"><i class="fas fa-headset"></i> Layanan</a>
      <a href="pesanan_aktif.php"><i class="fas fa-clipboard-list"></i> Pesanan Aktif</a>
      <a href="riwayat_pesanan.php"><i class="fas fa-history"></i> Riwayat Pesanan</a>
      <a href="artikel.php"><i class="fas fa-clipboard-list"></i> Artikel</a>
    </div>
    
    <div class="user-actions">
      <div class="user-profile">
        <div class="user-img"><?php echo strtoupper(substr($_SESSION['username'], 0, 1)); ?></div>
        <span><?php echo htmlspecialchars($_SESSION['username']); ?></span>
        <div class="dropdown-menu">
          <a href="profile.php"><i class="fas fa-user"></i> Profil</a>
          <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
      </div>
    </div>
  </div>
  
  <div class="container">
    <div class="hero">
      <h1>Temukan Teknisi Profesional</h1>
      <p><?= $total_techs ?> teknisi ahli siap membantu perbaikan perangkat elektronik Anda</p>
      
      <div class="stats">
        <div class="stat-item">
          <div class="number"><?= $total_techs ?></div>
          <div class="label">Teknisi Profesional</div>
        </div>
        <div class="stat-item">
          <div class="number"><?= $satisfaction ?>%</div>
          <div class="label">Kepuasan Pelanggan</div>
        </div>
        <div class="stat-item">
          <div class="number">24/7</div>
          <div class="label">Layanan Dukungan</div>
        </div>
      </div>
    </div>
    
    <div class="filters">
      <div class="filter-group">
        <div class="filter-btn <?= !$category_id ? 'active' : '' ?>" onclick="window.location.href='service.php'">
          <i class="fas fa-layer-group"></i> Semua Kategori
        </div>
        <?php 
        $categories->data_seek(0); // Reset pointer result
        while($category = $categories->fetch_assoc()): 
          // Determine icon based on category name
          $icon = 'fa-question'; // default icon
          switch($category['name']) {
            case 'Kulkas':
              $icon = 'fa-snowflake';
              break;
            case 'AC':
              $icon = 'fa-fan';
              break;
            case 'Mesin Cuci':
              $icon = 'fa-tshirt';
              break;
            case 'TV':
              $icon = 'fa-tv';
              break;
            case 'Laptop':
              $icon = 'fa-laptop';
              break;
          }
        ?>
        <div class="filter-btn <?= $category_id == $category['id'] ? 'active' : '' ?>" 
             onclick="window.location.href='service.php?category=<?= $category['id'] ?>'">
          <i class="fas <?= $icon ?>"></i> <?= htmlspecialchars($category['name']) ?>
        </div>
        <?php endwhile; ?>
      </div>
    </div>
    
    <div class="section-title">
      <h2><i class="fas fa-user-cog"></i> 
        <?php 
        if ($category_id) {
            $cat_name = $conn->query("SELECT name FROM service_categories WHERE id = $category_id")->fetch_assoc()['name'];
            echo htmlspecialchars($cat_name);
        } else {
            echo 'Semua Teknisi';
        } 
        ?>
      </h2>
      <a href="#" class="view-all">Lihat Semua <i class="fas fa-arrow-right"></i></a>
    </div>
    
    <div class="technician-grid" id="techList">
      <?php if($technicians->num_rows > 0): ?>
        <?php while($tech = $technicians->fetch_assoc()): ?>
        <div class="tech-box">
          <img src="<?= $tech['profile_picture'] ? htmlspecialchars($tech['profile_picture']) : 'https://randomuser.me/api/portraits/men/'.rand(1,99).'.jpg' ?>">
          <div class="tech-info">
            <h3><?= htmlspecialchars($tech['name']) ?></h3>
            <div class="specialty">
              <?php 
              $skills = explode(', ', $tech['skills']);
              foreach($skills as $skill): ?>
                <span class="skill-badge"><?= htmlspecialchars($skill) ?></span>
              <?php endforeach; ?>
            </div>
            <div class="stars">
              <?php 
              $rating = round($tech['avg_rating'] ?? 0);
              for($i = 1; $i <= 5; $i++): ?>
                <i class="fas fa-star<?= $i <= $rating ? '' : '-half-alt' ?>"></i>
              <?php endfor; ?>
              <span>(<?= $tech['review_count'] ?: 0 ?>)</span>
            </div>
            <div class="price">Rp <?= number_format($tech['rate'] ?? 50000, 0, ',', '.') ?>/jam</div>
            <button class="action-btn" onclick="showBookingForm(<?= $tech['id'] ?>, '<?= htmlspecialchars($tech['name']) ?>', '<?= $tech['profile_picture'] ? htmlspecialchars($tech['profile_picture']) : 'https://randomuser.me/api/portraits/men/'.rand(1,99).'.jpg' ?>', <?= $tech['rate'] ?? 50000 ?>)">
              Pilih Teknisi
            </button>
          </div>
        </div>
        <?php endwhile; ?>
      <?php else: ?>
        <div class="no-techs">
          <i class="fas fa-user-slash"></i>
          <h3>Tidak ada teknisi yang tersedia</h3>
          <p>Silakan coba kategori lain atau coba lagi nanti</p>
        </div>
      <?php endif; ?>
    </div>
    
    <!-- Booking Modal -->
    <div id="bookingModal" class="booking-modal">
        <div class="booking-content">
            <span class="close-btn" onclick="closeBookingForm()">&times;</span>
            
            <div class="tech-info-box">
                <img id="modalTechImage" src="">
                <div class="tech-info-content">
                    <h3 id="modalTechName"></h3>
                    <div class="price" id="modalTechRate"></div>
                </div>
            </div>
            
            <h2><i class="fas fa-calendar-alt"></i> Form Pemesanan</h2>
            
            <form action="process_booking.php" method="POST" id="bookingForm">
                <input type="hidden" name="tech_id" id="formTechId" value="">
                
                <div class="form-group">
                    <label for="book-name">Nama Lengkap</label>
                    <input type="text" id="book-name" name="name" class="form-control" 
                          value="<?= isset($_SESSION['name']) ? htmlspecialchars($_SESSION['name']) : '' ?>" 
                          placeholder="Masukkan nama Anda" required>
                </div>
                
                <div class="form-group">
                    <label for="book-phone">Nomor Handphone</label>
                    <input type="tel" id="book-phone" name="phone" class="form-control" 
                          value="<?= isset($_SESSION['phone']) ? htmlspecialchars($_SESSION['phone']) : '' ?>"
                          placeholder="Contoh: 081234567890" required>
                </div>
                
                <div class="form-group">
                    <label for="book-address">Alamat Lengkap</label>
                    <textarea id="book-address" name="address" class="form-control" 
                              placeholder="Masukkan alamat lengkap untuk perbaikan" required></textarea>
                </div>
                
                <div class="form-group">
                    <label for="book-device">Perangkat yang Akan Diperbaiki</label>
                    <input type="text" id="book-device" name="device" class="form-control" 
                          placeholder="Contoh: TV Samsung 32 inch" required>
                </div>
                
                <div class="form-group">
                    <label for="book-date">Tanggal Perbaikan</label>
                    <input type="date" id="book-date" name="date" class="form-control" required>
                    <div id="date-warning" class="date-warning">
                        <i class="fas fa-exclamation-circle"></i> Teknisi sudah memiliki 2 pesanan pada tanggal ini
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="book-time">Waktu Perbaikan</label>
                    <select id="book-time" name="time" class="form-control" required>
                        <option value="">Pilih Waktu</option>
                        <option value="08:00-10:00">08:00 - 10:00</option>
                        <option value="10:00-12:00">10:00 - 12:00</option>
                        <option value="13:00-15:00">13:00 - 15:00</option>
                        <option value="15:00-17:00">15:00 - 17:00</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="payment-type">Metode Pembayaran</label>
                    <select id="payment-type" name="payment_type" class="form-control" required>
                        <option value="">Pilih Metode Pembayaran</option>
                        <option value="full">Bayar Penuh Online</option>
                        <option value="cod">Bayar di Tempat (COD)</option>
                    </select>
                </div>
                
                <div id="payment-method-container" style="display: none;">
                    <div class="form-group">
                        <label for="payment-method">Metode Pembayaran</label>
                        <select id="payment-method" name="payment_method" class="form-control">
                            <option value="">Pilih Metode Pembayaran</option>
                            <?php
                            // Get user's payment methods
                            if (isset($_SESSION['user_id'])) {
                                $payment_methods = $conn->query("SELECT * FROM payment_methods WHERE user_id = " . $_SESSION['user_id']);
                                while($method = $payment_methods->fetch_assoc()) {
                                    echo '<option value="' . $method['id'] . '">' . 
                                        htmlspecialchars($method['bank_name']) . ' - ' . 
                                        htmlspecialchars($method['account_number']) . '</option>';
                                }
                            }
                            ?>
                            <option value="new">+ Tambah Metode Pembayaran Baru</option>
                        </select>
                    </div>
                    
                    <div id="new-payment-method" style="display: none;">
                        <div class="form-group">
                            <label for="bank-name">Nama Bank</label>
                            <input type="text" id="bank-name" name="bank_name" class="form-control" placeholder="Contoh: BCA">
                        </div>
                        <div class="form-group">
                            <label for="account-number">Nomor Rekening</label>
                            <input type="text" id="account-number" name="account_number" class="form-control" placeholder="Contoh: 1234567890">
                        </div>
                        <div class="form-group">
                            <label for="account-name">Nama Pemilik Rekening</label>
                            <input type="text" id="account-name" name="account_name" class="form-control" placeholder="Nama sesuai rekening">
                        </div>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="book-notes">Catatan Tambahan (Opsional)</label>
                    <textarea id="book-notes" name="notes" class="form-control" 
                              placeholder="Masukkan catatan tambahan jika ada"></textarea>
                </div>
                
                <div class="form-group">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="terms" required>
                        <label class="form-check-label" for="terms">
                            Saya menyetujui <a href="#" data-bs-toggle="modal" data-bs-target="#termsModal">Syarat dan Ketentuan</a>
                        </label>
                    </div>
                </div>
                
                <button type="submit" class="submit-btn">
                    <i class="fas fa-check-circle"></i>
                    Pesan Teknisi
                </button>
            </form>
        </div>
    </div>
  </div>
  
  <footer>
    <div class="footer-content">
      <h3>ReparoTech</h3>
      <p>Solusi perbaikan elektronik terbaik dengan kualitas dan kepercayaan sebagai prioritas utama kami.</p>
      <div class="social-icons">
        <a href="#"><i class="fab fa-facebook-f"></i></a>
        <a href="#"><i class="fab fa-twitter"></i></a>
        <a href="#"><i class="fab fa-instagram"></i></a>
        <a href="#"><i class="fab fa-whatsapp"></i></a>
      </div>
      <p class="copyright">&copy; 2023 ReparoTech. All Rights Reserved.</p>
    </div>
  </footer>
  
  <script>
    // Initialize technicians with animation
    document.addEventListener('DOMContentLoaded', function() {
      const techBoxes = document.querySelectorAll('.tech-box');
      techBoxes.forEach((box, index) => {
        setTimeout(() => {
          box.style.opacity = '1';
          box.style.transform = 'translateY(0)';
        }, index * 100);
      });
      
      // Set minimum date to tomorrow
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      document.getElementById('book-date').min = tomorrow.toISOString().split('T')[0];
      
      // Hide date warning initially
      document.getElementById('date-warning').style.display = 'none';
    });
    
    // Show/hide payment method fields based on payment type
    document.getElementById('payment-type').addEventListener('change', function() {
        const paymentType = this.value;
        const paymentMethodContainer = document.getElementById('payment-method-container');
        
        if (paymentType === 'cod') {
            paymentMethodContainer.style.display = 'none';
        } else {
            paymentMethodContainer.style.display = 'block';
        }
    });
    
    // Show/hide new payment method fields
    document.getElementById('payment-method').addEventListener('change', function() {
        const paymentMethod = this.value;
        const newPaymentMethod = document.getElementById('new-payment-method');
        
        if (paymentMethod === 'new') {
            newPaymentMethod.style.display = 'block';
            // Make fields required
            document.getElementById('bank-name').required = true;
            document.getElementById('account-number').required = true;
            document.getElementById('account-name').required = true;
        } else {
            newPaymentMethod.style.display = 'none';
            // Remove required
            document.getElementById('bank-name').required = false;
            document.getElementById('account-number').required = false;
            document.getElementById('account-name').required = false;
        }
    });
    
    // Show booking form
    function showBookingForm(techId, techName, techImage, techRate) {
      // First check availability for the default date (tomorrow)
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      const defaultDate = tomorrow.toISOString().split('T')[0];
      
      // Check technician availability
      checkTechAvailability(techId, defaultDate).then(isAvailable => {
        if (!isAvailable) {
          document.getElementById('date-warning').style.display = 'block';
        }
        
        document.getElementById('modalTechImage').src = techImage;
        document.getElementById('modalTechName').textContent = techName;
        document.getElementById('modalTechRate').textContent = 'Rp ' + techRate.toLocaleString('id-ID') + '/jam';
        document.getElementById('formTechId').value = techId;
        
        // Set default date
        document.getElementById('book-date').value = defaultDate;
        
        // Pre-fill user data if available
        document.getElementById('book-name').value = '<?= isset($_SESSION['name']) ? addslashes($_SESSION['name']) : '' ?>';
        document.getElementById('book-phone').value = '<?= isset($_SESSION['phone']) ? addslashes($_SESSION['phone']) : '' ?>';
        
        document.getElementById('bookingModal').style.display = 'block';
      });
    }
    
    // Check technician availability
    function checkTechAvailability(techId, date) {
      return fetch(`service.php?check_availability=1&tech_id=${techId}&date=${date}`)
        .then(response => response.json())
        .then(data => {
          const warningElement = document.getElementById('date-warning');
          if (data.is_available) {
            warningElement.style.display = 'none';
            return true;
          } else {
            warningElement.style.display = 'block';
            return false;
          }
        })
        .catch(() => {
          // If there's an error, assume available but show warning
          document.getElementById('date-warning').style.display = 'none';
          return true;
        });
    }
    
    // Close booking form
    function closeBookingForm() {
      document.getElementById('bookingModal').style.display = 'none';
      document.getElementById('date-warning').style.display = 'none';
    }
    
    // Close modal when clicking outside
    window.onclick = function(event) {
      if (event.target == document.getElementById('bookingModal')) {
        closeBookingForm();
      }
    }
    
    // Form submission handler
    document.getElementById('bookingForm').addEventListener('submit', function(e) {
      const techId = document.getElementById('formTechId').value;
      const date = document.getElementById('book-date').value;
      
      if (!techId || !date) {
        e.preventDefault();
        alert('Silakan lengkapi semua field yang diperlukan');
        return;
      }
      
      // Perform one final availability check before submitting
      checkTechAvailability(techId, date).then(isAvailable => {
        if (!isAvailable) {
          e.preventDefault();
          alert('Teknisi ini sudah memiliki 2 pesanan pada tanggal yang dipilih. Silakan pilih tanggal lain.');
          document.getElementById('book-date').focus();
        }
      });
    });
    
    // Update availability check when date changes
    document.getElementById('book-date').addEventListener('change', function() {
      const techId = document.getElementById('formTechId').value;
      const date = this.value;
      
      if (techId && date) {
        checkTechAvailability(techId, date);
      }
    });
  </script>
</body>
</html>