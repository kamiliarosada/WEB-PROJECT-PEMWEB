<?php
session_start();
require_once '../db.php';

if (!isset($_GET['order_id'])) {
    header('Location: user_orders.php');
    exit;
}

$orderId = intval($_GET['order_id']);
$userId = $_SESSION['user_id'];

// Proses form ulasan
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $rating = intval($_POST['rating']);
    $comment = $conn->real_escape_string($_POST['comment']);
    
    // Dapatkan technician_id dari pesanan
    $order = $conn->query("SELECT technician_id FROM orders WHERE id = $orderId")->fetch_assoc();
    $techId = $order['technician_id'];
    
    $conn->query("
        INSERT INTO feedback (order_id, technician_id, rating, comment, created_at)
        VALUES ($orderId, $techId, $rating, '$comment', NOW())
    ");
    
    if ($conn->affected_rows > 0) {
        $_SESSION['feedback_success'] = true;
        header('Location: user_orders.php');
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Beri Ulasan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <?php include 'navbar.php'; ?>

    <div class="container mt-4">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h4>Beri Ulasan</h4>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <div class="mb-3">
                                <label class="form-label">Rating</label>
                                <div>
                                    <?php for($i=1; $i<=5; $i++): ?>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="rating" id="rating<?= $i ?>" value="<?= $i ?>">
                                            <label class="form-check-label" for="rating<?= $i ?>">
                                                <?= str_repeat('★', $i) ?>
                                            </label>
                                        </div>
                                    <?php endfor; ?>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Komentar</label>
                                <textarea name="comment" class="form-control" rows="3" required></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary">Kirim Ulasan</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>