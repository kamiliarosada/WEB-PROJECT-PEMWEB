<?php
session_start();
require_once '../db.php';

// Check if user is logged in
if (!isset($_SESSION['username'])) {
    header('Location: ../login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Handle payment methods management
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_method'])) {
    // Handle adding new payment method
    $bank_name = $conn->real_escape_string($_POST['bank_name']);
    $account_number = $conn->real_escape_string($_POST['account_number']);
    $account_name = $conn->real_escape_string($_POST['account_name']);
    
    $conn->query("
        INSERT INTO payment_methods (user_id, bank_name, account_number, account_name)
        VALUES ($user_id, '$bank_name', '$account_number', '$account_name')
    ");
    
    $_SESSION['success'] = "Metode pembayaran berhasil ditambahkan";
    header('Location: service.php');
    exit;
}

// Check cancellation limit
$cancellation_check = $conn->query("
    SELECT cancellation_count, last_cancellation_date 
    FROM users 
    WHERE id = $user_id
")->fetch_assoc();

// Block if too many cancellations
if ($cancellation_check['cancellation_count'] >= 3 && 
    strtotime($cancellation_check['last_cancellation_date']) > strtotime('-30 days')) {
    $_SESSION['error'] = "Akun Anda dibekukan sementara karena terlalu banyak pembatalan pesanan";
    header('Location: service.php');
    exit;
}

// Process form data
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tech_id'])) {
    try {
        // Validate and sanitize input
        $tech_id = intval($_POST['tech_id']);
        $name = trim($conn->real_escape_string($_POST['name']));
        $phone = trim($conn->real_escape_string($_POST['phone']));
        $address = trim($conn->real_escape_string($_POST['address']));
        $device = trim($conn->real_escape_string($_POST['device']));
        $date = $conn->real_escape_string($_POST['date']);
        $time = $conn->real_escape_string($_POST['time']);
        $notes = trim($conn->real_escape_string($_POST['notes'] ?? ''));
        $payment_type = $conn->real_escape_string($_POST['payment_type']);
        $payment_method_id = isset($_POST['payment_method']) ? intval($_POST['payment_method']) : null;
        
        // Basic validation
        if (empty($name) || empty($phone) || empty($address) || empty($device) || empty($date) || empty($time)) {
            throw new Exception('Semua field wajib diisi');
        }

        // Validate phone format
        if (!preg_match('/^[0-9]{10,15}$/', $phone)) {
            throw new Exception('Format nomor handphone tidak valid');
        }

        // Validate date not before today
        $today = date('Y-m-d');
        if ($date < $today) {
            throw new Exception('Tanggal booking tidak boleh sebelum hari ini');
        }

        // Verify technician
        $tech_check = $conn->prepare("SELECT t.id FROM technicians t 
                                    JOIN users u ON t.user_id = u.id 
                                    WHERE u.id = ? AND u.role = 'technician'");
        $tech_check->bind_param("i", $tech_id);
        $tech_check->execute();
        $tech_result = $tech_check->get_result();
        
        if ($tech_result->num_rows === 0) {
            throw new Exception('Teknisi tidak valid atau tidak ditemukan');
        }
        
        $tech_data = $tech_result->fetch_assoc();
        $valid_tech_id = $tech_data['id'];

        // Get technician rate
        $rate_query = $conn->prepare("SELECT rate FROM technicians WHERE id = ?");
        $rate_query->bind_param("i", $valid_tech_id);
        $rate_query->execute();
        $rate_result = $rate_query->get_result();
        
        if ($rate_result->num_rows === 0) {
            throw new Exception('Data rate teknisi tidak ditemukan');
        }
        
        $rate_row = $rate_result->fetch_assoc();
        $rate = $rate_row['rate'] ?? 50000;
        $total_amount = $rate * 2; // 2 hours service
        
        // Check technician availability
        $availability_check = $conn->prepare("
            SELECT COUNT(*) as order_count 
            FROM orders 
            WHERE technician_id = ? 
            AND service_date = ? 
            AND status NOT IN ('cancelled', 'rejected')
        ");
        $availability_check->bind_param("is", $valid_tech_id, $date);
        $availability_check->execute();
        $availability_result = $availability_check->get_result();
        $order_count = $availability_result->fetch_assoc()['order_count'];

        if ($order_count >= 2) {
            throw new Exception('Teknisi ini sudah memiliki 2 pesanan pada tanggal yang dipilih. Silakan pilih tanggal lain.');
        }

        // Start transaction
        $conn->begin_transaction();

        try {
            // Insert into orders table
            $sql = "INSERT INTO orders (
                user_id, 
                technician_id, 
                customer_name, 
                phone, 
                address, 
                device, 
                service_date, 
                service_time, 
                notes, 
                description, 
                status, 
                total_amount, 
                created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?, NOW())";
            
            // Create order description
            $description = "Catatan: " . (!empty($notes) ? $notes : 'Tidak ada catatan');
            
            $stmt = $conn->prepare($sql);
            $stmt->bind_param(
                "iissssssssd", 
                $user_id, 
                $valid_tech_id,
                $name,
                $phone,
                $address,
                $device,
                $date,
                $time,
                $notes,
                $description,
                $total_amount
            );
            
            if (!$stmt->execute()) {
                throw new Exception('Gagal membuat pesanan: ' . $conn->error);
            }

            $order_id = $conn->insert_id;
            
            // Handle payment method if new
            if ($payment_type !== 'cod' && isset($_POST['payment_method']) && $_POST['payment_method'] === 'new') {
                $bank_name = $conn->real_escape_string($_POST['bank_name']);
                $account_number = $conn->real_escape_string($_POST['account_number']);
                $account_name = $conn->real_escape_string($_POST['account_name']);
                
                $insert_payment = $conn->query("
                    INSERT INTO payment_methods (user_id, bank_name, account_number, account_name)
                    VALUES ($user_id, '$bank_name', '$account_number', '$account_name')
                ");
                
                if (!$insert_payment) {
                    throw new Exception('Gagal menambahkan metode pembayaran: ' . $conn->error);
                }
                
                $payment_method_id = $conn->insert_id;
            }
            
            // Calculate payment amount based on type
            $payment_amount = $total_amount;
            if ($payment_type === 'deposit') {
                $payment_amount = $total_amount * 0.5; // 50% deposit
            } elseif ($payment_type === 'cod') {
                $payment_amount = 0; // No upfront payment for COD
            }
            
            // Create transaction record
            $transaction_sql = "INSERT INTO transactions (
                order_id,
                payment_method_id,
                amount,
                payment_type,
                status,
                transaction_date
            ) VALUES (?, ?, ?, ?, 'pending', NOW())";
            
            $transaction_stmt = $conn->prepare($transaction_sql);
            $transaction_stmt->bind_param(
                "iids",
                $order_id,
                $payment_method_id,
                $payment_amount,
                $payment_type
            );
            
            if (!$transaction_stmt->execute()) {
                throw new Exception('Gagal membuat transaksi: ' . $conn->error);
            }

            $conn->commit();
            
            // Redirect to payment page if not COD
            if ($payment_type !== 'cod') {
                header("Location: process_payment.php?order_id=$order_id");
                exit;
            } else {
                header('Location: service.php?success=1');
                exit;
            }
        } catch (Exception $e) {
            $conn->rollback();
            throw $e;
        }
    } catch (Exception $e) {
        header('Location: service.php?error=' . urlencode($e->getMessage()));
        exit;
    }
} else {
    header('Location: service.php');
    exit;
}