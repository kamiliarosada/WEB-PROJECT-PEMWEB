<?php
session_start();
require_once '../db.php';

// Check if user is logged in and has user role
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'user') {
    header('Location: ../login.php');
    exit;
}

// Check if order ID is provided
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    $_SESSION['error'] = "ID pesanan tidak valid";
    header('Location: pesanan_aktif.php');
    exit;
}

$order_id = intval($_GET['id']);
$user_id = $_SESSION['user_id'];

// Check if order belongs to user and is pending
$order = $conn->prepare("
    SELECT id, status FROM orders 
    WHERE id = ? AND user_id = ? AND status = 'pending'
");
$order->bind_param("ii", $order_id, $user_id);
$order->execute();
$order_result = $order->get_result();
$order_data = $order_result->fetch_assoc();

if (!$order_data) {
    $_SESSION['error'] = "Pesanan tidak dapat dibatalkan atau tidak ditemukan";
    header('Location: pesanan_aktif.php');
    exit;
}

// Start transaction
$conn->begin_transaction();

try {
    // Update order status to cancelled
    $update_order = $conn->prepare("UPDATE orders SET status = 'cancelled' WHERE id = ?");
    $update_order->bind_param("i", $order_id);
    $update_order->execute();
    
    // Check if there's a transaction to refund
    $transaction = $conn->prepare("
        SELECT id, amount, payment_type, status 
        FROM transactions 
        WHERE order_id = ?
    ");
    $transaction->bind_param("i", $order_id);
    $transaction->execute();
    $transaction_result = $transaction->get_result();
    $transaction_data = $transaction_result->fetch_assoc();
    
    if ($transaction_data && $transaction_data['status'] === 'completed') {
        // Mark transaction as refunded
        $update_transaction = $conn->prepare("
            UPDATE transactions 
            SET status = 'refunded' 
            WHERE id = ?
        ");
        $update_transaction->bind_param("i", $transaction_data['id']);
        $update_transaction->execute();
        
        // TODO: Implement actual refund process here
        // This would typically involve calling your payment gateway API
    }
    
    // Update user cancellation count
    $update_user = $conn->prepare("
        UPDATE users 
        SET cancellation_count = cancellation_count + 1,
            last_cancellation_date = NOW() 
        WHERE id = ?
    ");
    $update_user->bind_param("i", $user_id);
    $update_user->execute();
    
    $conn->commit();
    
    $_SESSION['success'] = "Pesanan berhasil dibatalkan";
    header('Location: pesanan_aktif.php');
    exit;
} catch (Exception $e) {
    $conn->rollback();
    $_SESSION['error'] = "Gagal membatalkan pesanan: " . $e->getMessage();
    header('Location: pesanan_aktif.php');
    exit;
}