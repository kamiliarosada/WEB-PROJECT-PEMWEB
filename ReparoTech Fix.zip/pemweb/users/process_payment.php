<?php
session_start();
require_once '../db.php';

if (!isset($_SESSION['username'])) {
    header('Location: ../login.php');
    exit;
}

if (!isset($_GET['order_id'])) {
    header('Location: service.php');
    exit;
}

$order_id = intval($_GET['order_id']);
$user_id = $_SESSION['user_id'];

// Get order and transaction details
$order = $conn->query("
    SELECT o.*, t.amount, t.payment_type, t.status as payment_status,
           pm.bank_name, pm.account_number, pm.account_name
    FROM orders o
    JOIN transactions t ON o.id = t.order_id
    LEFT JOIN payment_methods pm ON t.payment_method_id = pm.id
    WHERE o.id = $order_id AND o.user_id = $user_id
")->fetch_assoc();

if (!$order) {
    header('Location: service.php');
    exit;
}

// Handle payment completion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['complete_payment'])) {
    $conn->query("
        UPDATE transactions 
        SET status = 'completed', completed_at = NOW() 
        WHERE order_id = $order_id
    ");
    
    header('Location: service.php?success=1');
    exit;
}

// Calculate company fee (20%)
$company_fee = $order['amount'] * 0.2;
$technician_amount = $order['amount'] - $company_fee;
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pembayaran - ReparoTech</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            padding-top: 20px;
        }
        .payment-card {
            max-width: 600px;
            margin: 0 auto;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .payment-header {
            background-color: #2563eb;
            color: white;
            border-radius: 10px 10px 0 0;
            padding: 15px;
        }
        .payment-details {
            padding: 20px;
        }
        .bank-info {
            background-color: #f8f9fa;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 20px;
        }
        .amount-details {
            margin-top: 20px;
        }
        .alert-warning {
            background-color: #fff3cd;
            border-color: #ffeeba;
            color: #856404;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="payment-card">
                    <div class="payment-header text-center">
                        <h3>Pembayaran Pesanan #<?= $order_id ?></h3>
                    </div>
                    
                    <div class="payment-details">
                        <div class="alert alert-info">
                            <h5>Instruksi Pembayaran</h5>
                            <p>Silakan transfer sesuai jumlah di bawah ini ke rekening perusahaan kami:</p>
                        </div>
                        
                        <div class="bank-info">
                            <h5>Transfer ke:</h5>
                            <p><strong>Bank:</strong> <?= htmlspecialchars($order['bank_name'] ?? 'BCA (Bank Central Asia)') ?></p>
                            <p><strong>Nomor Rekening:</strong> <?= htmlspecialchars($order['account_number'] ?? '1234567890') ?></p>
                            <p><strong>Atas Nama:</strong> <?= htmlspecialchars($order['account_name'] ?? 'PT Reparo Tech Indonesia') ?></p>
                            <p><strong>Jumlah Transfer:</strong> Rp <?= number_format($order['amount'], 0, ',', '.') ?></p>
                            <p><strong>Kode Unik:</strong> <?= $order_id ?></p>
                        </div>
                        
                        <div class="alert alert-warning">
                            <h5>Penting!</h5>
                            <p>1. Pastikan jumlah transfer sesuai<br>
                            2. Sistem akan otomatis mendeteksi pembayaran Anda<br>
                            3. Jika dalam 1 jam pembayaran belum terdeteksi, hubungi kami</p>
                        </div>
                        
                        <div class="amount-details">
                            <table class="table table-bordered">
                                <tr>
                                    <th>Total Pembayaran</th>
                                    <td>Rp <?= number_format($order['amount'], 0, ',', '.') ?></td>
                                </tr>
                                <tr>
                                    <th>Fee Perusahaan (20%)</th>
                                    <td>Rp <?= number_format($company_fee, 0, ',', '.') ?></td>
                                </tr>
                                <tr>
                                    <th>Diterima Teknisi</th>
                                    <td>Rp <?= number_format($technician_amount, 0, ',', '.') ?></td>
                                </tr>
                            </table>
                        </div>
                        
                        <form method="POST">
                            <div class="d-grid gap-2">
                                <button type="submit" name="complete_payment" class="btn btn-primary btn-lg">
                                    Saya Sudah Transfer
                                </button>
                                <a href="service.php" class="btn btn-outline-secondary">
                                    Batalkan Pesanan
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>