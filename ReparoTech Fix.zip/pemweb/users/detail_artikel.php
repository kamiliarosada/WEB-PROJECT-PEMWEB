<?php
session_start();
require_once '../db.php';

// Cek apakah user sudah login
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}

// Dapatkan ID artikel dari URL
$article_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Ambil data artikel dari database
$stmt = $conn->prepare("
    SELECT a.*, u.name AS author_name, sc.name AS service_category_name 
    FROM articles a
    JOIN users u ON a.author_id = u.id
    LEFT JOIN service_categories sc ON a.service_category_id = sc.id
    WHERE a.id = ?
");
$stmt->bind_param("i", $article_id);
$stmt->execute();
$result = $stmt->get_result();
$article = $result->fetch_assoc();

// Jika artikel tidak ditemukan, redirect atau tampilkan pesan error
if (!$article) {
    die("Artikel tidak ditemukan");
}

// Handle rating submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['rating'])) {
    $rating = intval($_POST['rating']);
    $user_id = $_SESSION['user_id'];
    
    // Validate rating value
    if ($rating < 1 || $rating > 5) {
        $_SESSION['rating_error'] = "Rating harus antara 1-5 bintang";
    } else {
        // Check if user already rated this article
        $check_stmt = $conn->prepare("SELECT id FROM article_ratings WHERE article_id = ? AND user_id = ?");
        $check_stmt->bind_param("ii", $article_id, $user_id);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();
        
        if ($check_result->num_rows > 0) {
            // Update existing rating
            $update_stmt = $conn->prepare("UPDATE article_ratings SET rating = ? WHERE article_id = ? AND user_id = ?");
            $update_stmt->bind_param("iii", $rating, $article_id, $user_id);
            $update_stmt->execute();
        } else {
            // Insert new rating
            $insert_stmt = $conn->prepare("INSERT INTO article_ratings (article_id, user_id, rating) VALUES (?, ?, ?)");
            $insert_stmt->bind_param("iii", $article_id, $user_id, $rating);
            $insert_stmt->execute();
        }
        
        $_SESSION['rating_submitted'] = true;
    }
    
    header("Location: detail_artikel.php?id=$article_id");
    exit;
}

// Get average rating and count
$rating_stmt = $conn->prepare("
    SELECT AVG(rating) as avg_rating, COUNT(*) as rating_count 
    FROM article_ratings 
    WHERE article_id = ?
");
$rating_stmt->bind_param("i", $article_id);
$rating_stmt->execute();
$rating_result = $rating_stmt->get_result();
$rating_data = $rating_result->fetch_assoc();
$average_rating = round($rating_data['avg_rating'], 1);
$rating_count = $rating_data['rating_count'];

// Get all ratings with user info
$ratings_stmt = $conn->prepare("
    SELECT ar.rating, ar.created_at, u.name as user_name, u.username
    FROM article_ratings ar
    JOIN users u ON ar.user_id = u.id
    WHERE ar.article_id = ?
    ORDER BY ar.created_at DESC
");
$ratings_stmt->bind_param("i", $article_id);
$ratings_stmt->execute();
$ratings_result = $ratings_stmt->get_result();
$all_ratings = $ratings_result->fetch_all(MYSQLI_ASSOC);

// Check if user already rated this article
$user_rated = false;
$user_rating = 0;
if (isset($_SESSION['user_id'])) {
    $user_rating_stmt = $conn->prepare("SELECT rating FROM article_ratings WHERE article_id = ? AND user_id = ?");
    $user_rating_stmt->bind_param("ii", $article_id, $_SESSION['user_id']);
    $user_rating_stmt->execute();
    $user_rating_result = $user_rating_stmt->get_result();
    if ($user_rating_result->num_rows > 0) {
        $user_rated = true;
        $user_rating = $user_rating_result->fetch_assoc()['rating'];
    }
}

// Prepare variables for display
$content = $article['content'];
$title = $article['title'];
$image_url = $article['image_url'] ? '../' . $article['image_url'] : 'https://via.placeholder.com/800x400?text=Reparo+Artikel';
$created_at = date('d F Y', strtotime($article['created_at']));
$author = $article['author_name'];
$category = $article['service_category_name'] ?: 'Umum';
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($title) ?> - Reparo</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #e4e8f0 100%);
            color: #333;
            line-height: 1.6;
            min-height: 100vh;
            margin: 0;
        }
        
        .nav-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1200px;
            margin: 0 auto;
            padding: 15px 20px;
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .logo {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 1.5rem;
            font-weight: 700;
            color: #2563eb;
            text-decoration: none;
        }
        
        .logo i {
            font-size: 1.8rem;
        }
        
        .user-actions {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .user-profile {
            display: flex;
            align-items: center;
            gap: 8px;
            cursor: pointer;
            position: relative;
        }
        
        .user-img {
            width: 35px;
            height: 35px;
            border-radius: 50%;
            background: #2563eb;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
        }
        
        .dropdown-menu {
            position: absolute;
            top: 45px;
            right: 0;
            background: white;
            border-radius: 8px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            padding: 10px 0;
            min-width: 180px;
            display: none;
            z-index: 100;
        }
        
        .dropdown-menu a {
            display: block;
            padding: 8px 15px;
            color: #334155;
            text-decoration: none;
            transition: background 0.3s;
        }
        
        .dropdown-menu a:hover {
            background: #f1f5f9;
        }
        
        .user-profile:hover .dropdown-menu {
            display: block;
        }
        
        .container {
            max-width: 900px;
            margin: 30px auto;
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        
        header {
            background: linear-gradient(90deg, #0066cc 0%, #0099cc 100%);
            color: white;
            padding: 25px 30px;
            text-align: center;
        }
        
        h1 {
            font-size: 2.2rem;
            margin-bottom: 10px;
            text-shadow: 1px 1px 3px rgba(0,0,0,0.3);
        }
        
        .article-meta {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-top: 15px;
            font-size: 0.9rem;
            opacity: 0.9;
        }
        
        .details-section {
            padding: 30px;
        }
        
        .back-btn-container {
            margin-bottom: 25px;
        }
        
        .back-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 10px 20px;
            background-color: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            text-decoration: none;
            color: #334155;
            font-weight: 600;
            transition: all 0.3s ease;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }
        
        .back-btn:hover {
            background-color: #f1f5f9;
            transform: translateY(-2px);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        
        .image-container {
            width: 100%;
            max-height: 400px;
            overflow: hidden;
            border-radius: 10px;
            margin-bottom: 25px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .image-container img {
            width: 100%;
            height: auto;
            display: block;
            transition: transform 0.3s ease;
        }
        
        .image-container img:hover {
            transform: scale(1.03);
        }
        
        /* Rating Container Styles */
        .rating-container {
            background: #f0f9ff;
            border-radius: 12px;
            padding: 25px;
            margin-top: 30px;
            border: 1px solid #b3e0ff;
        }
        
        .rating-title {
            font-size: 1.4rem;
            color: #0066cc;
            margin-bottom: 15px;
        }
        
        /* Star Rating System */
        .star-rating {
            display: flex;
            justify-content: flex-start;
            margin: 15px 0;
            direction: ltr;
        }
        
        .star-rating input {
            display: none;
        }
        
        .star-rating label {
            color: #ccc;
            font-size: 32px;
            padding: 0 3px;
            cursor: pointer;
            transition: color 0.3s;
        }
        
        .star-rating label:before {
            content: "★";
        }
        
        .star-rating input:checked ~ label,
        .star-rating label:hover,
        .star-rating label:hover ~ label {
            color: #f59e0b;
        }
        
        .star-rating input:checked + label {
            color: #f59e0b;
        }
        
        .submit-btn {
            background: linear-gradient(90deg, #0066cc 0%, #0099cc 100%);
            color: white;
            border: none;
            padding: 12px 30px;
            font-size: 16px;
            border-radius: 50px;
            cursor: pointer;
            margin-top: 15px;
            transition: all 0.3s ease;
            box-shadow: 0 4px 10px rgba(0, 102, 204, 0.3);
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .submit-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 15px rgba(0, 102, 204, 0.4);
            background: linear-gradient(90deg, #0055aa 0%, #0088bb 100%);
        }
        
        /* Rating Summary */
        .rating-summary {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 15px;
        }
        
        .rating-average {
            font-size: 2rem;
            font-weight: bold;
            color: #1e293b;
        }
        
        .rating-count {
            color: #64748b;
        }
        
        .star-rating-display {
            color: #f59e0b;
            font-size: 1.2rem;
        }
        
        /* Ratings List */
        .ratings-list {
            margin-top: 20px;
            border-top: 1px solid #e2e8f0;
            padding-top: 20px;
        }
        
        .rating-item {
            display: flex;
            gap: 15px;
            margin-bottom: 15px;
            padding-bottom: 15px;
            border-bottom: 1px solid #f1f5f9;
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #2563eb;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            flex-shrink: 0;
        }
        
        .rating-content {
            flex-grow: 1;
        }
        
        .rating-user {
            font-weight: 600;
            color: #1e293b;
        }
        
        .rating-date {
            font-size: 0.8rem;
            color: #64748b;
            margin-left: 10px;
        }
        
        .rating-value {
            color: #f59e0b;
            margin-top: 5px;
        }
        
        .no-ratings {
            text-align: center;
            color: #64748b;
            padding: 20px 0;
        }
        
        /* Messages */
        .error-message {
            background: #fff5f5;
            border-radius: 10px;
            padding: 15px;
            margin-top: 15px;
            color: #e53e3e;
            font-weight: 500;
            border: 1px solid #fed7d7;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .error-message i {
            font-size: 1.2rem;
        }
        
        .thank-you {
            background: #e6ffed;
            border-radius: 10px;
            padding: 20px;
            margin-top: 25px;
            color: #009933;
            font-weight: bold;
            border: 1px solid #99ff99;
            animation: fadeIn 0.5s ease-in-out;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        footer {
            text-align: center;
            padding: 20px;
            background: #0066cc;
            color: white;
            font-size: 0.9rem;
        }
        
        @media (max-width: 768px) {
            .details-section {
                padding: 20px;
            }
            
            h1 {
                font-size: 1.8rem;
            }
            
            .article-meta {
                flex-direction: column;
                gap: 8px;
            }
            
            .star-rating label {
                font-size: 28px;
            }
        }
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <div class="nav-container">
        <a href="#" class="logo">
            <i class="fas fa-tools"></i>
            <span>Reparo</span>
        </a>
        
        <div class="user-actions">
            <a href="#"><i class="fas fa-bell"></i></a>
            <div class="user-profile">
                <div class="user-img"><?= strtoupper(substr($_SESSION['username'], 0, 1)) ?></div>
                <span><?= $_SESSION['username'] ?></span>
                <div class="dropdown-menu">
                    <a href="profile.php"><i class="fas fa-user"></i> Profil Saya</a>
                    <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Keluar</a>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <header>
            <h1><?= htmlspecialchars($title) ?></h1>
            <div class="article-meta">
                <span><i class="fas fa-user"></i> <?= htmlspecialchars($author) ?></span>
                <span><i class="fas fa-calendar"></i> <?= $created_at ?></span>
                <span><i class="fas fa-tag"></i> <?= htmlspecialchars($category) ?></span>
            </div>
        </header>
        
        <div class="details-section">
            <div class="back-btn-container">
                <a href="artikel.php" class="back-btn">
                    <i class="fas fa-arrow-left"></i> 
                    <span>Kembali ke Daftar Artikel</span>
                </a>
            </div>
            
            <div class="image-container">
                <img src="<?= $image_url ?>" alt="<?= htmlspecialchars($title) ?>">
            </div>
            
            <?= $content ?>
            
            <div class="rating-container">
                <div class="rating-title">Rating & Ulasan</div>
                
                <?php if (isset($_SESSION['rating_error'])): ?>
                    <div class="error-message">
                        <i class="fas fa-exclamation-circle"></i>
                        <?= $_SESSION['rating_error'] ?>
                    </div>
                    <?php unset($_SESSION['rating_error']); ?>
                <?php endif; ?>
                
                <div class="rating-summary">
                    <?php if ($rating_count > 0): ?>
                        <div class="rating-average"><?= $average_rating ?></div>
                        <div>
                            <div class="star-rating-display">
                                <?php 
                                $full_stars = floor($average_rating);
                                $half_star = ($average_rating - $full_stars) >= 0.5;
                                
                                for ($i = 1; $i <= 5; $i++) {
                                    if ($i <= $full_stars) {
                                        echo '<i class="fas fa-star"></i>';
                                    } elseif ($half_star && $i == $full_stars + 1) {
                                        echo '<i class="fas fa-star-half-alt"></i>';
                                    } else {
                                        echo '<i class="far fa-star"></i>';
                                    }
                                }
                                ?>
                            </div>
                            <div class="rating-count"><?= $rating_count ?> rating</div>
                        </div>
                    <?php else: ?>
                        <div class="rating-average">0.0</div>
                        <div>
                            <div class="star-rating-display">
                                <i class="far fa-star"></i>
                                <i class="far fa-star"></i>
                                <i class="far fa-star"></i>
                                <i class="far fa-star"></i>
                                <i class="far fa-star"></i>
                            </div>
                            <div class="rating-count">Belum ada rating</div>
                        </div>
                    <?php endif; ?>
                </div>
                
                <?php if (!$user_rated): ?>
                <p>Bagaimana pengalaman Anda dengan panduan ini?</p>
                <form method="POST" id="rating-form">
                    <div class="star-rating">
                        <!-- Urutan dari 1 (kiri) ke 5 (kanan) -->
                        <input type="radio" id="star1" name="rating" value="1" required>
                        <label for="star1" title="Tidak memuaskan"></label>
                        
                        <input type="radio" id="star2" name="rating" value="2">
                        <label for="star2" title="Kurang memuaskan"></label>
                        
                        <input type="radio" id="star3" name="rating" value="3">
                        <label for="star3" title="Cukup baik"></label>
                        
                        <input type="radio" id="star4" name="rating" value="4">
                        <label for="star4" title="Memuaskan"></label>
                        
                        <input type="radio" id="star5" name="rating" value="5">
                        <label for="star5" title="Sangat memuaskan"></label>
                    </div>
                    <button type="submit" class="submit-btn" id="submit-rating">
                        <i class="fas fa-paper-plane"></i> Kirim Rating
                    </button>
                </form>
                <?php else: ?>
                    <div class="thank-you">
                        Anda sudah memberikan rating <?= $user_rating ?> bintang untuk artikel ini. Terima kasih!
                    </div>
                <?php endif; ?>
                
                <?php if (isset($_SESSION['rating_submitted'])): ?>
                    <div class="thank-you" id="thank-you-message">
                        Terima kasih atas rating Anda! Umpan balik Anda sangat berharga untuk meningkatkan kualitas panduan kami.
                    </div>
                    <?php unset($_SESSION['rating_submitted']); ?>
                <?php endif; ?>
                
                <div class="ratings-list">
                    <h4>Semua Rating</h4>
                    
                    <?php if (count($all_ratings) > 0): ?>
                        <?php foreach ($all_ratings as $rating): ?>
                            <div class="rating-item">
                                <div class="user-avatar"><?= strtoupper(substr($rating['user_name'], 0, 1)) ?></div>
                                <div class="rating-content">
                                    <div>
                                        <span class="rating-user"><?= htmlspecialchars($rating['user_name']) ?></span>
                                        <span class="rating-date"><?= date('d M Y', strtotime($rating['created_at'])) ?></span>
                                    </div>
                                    <div class="rating-value">
                                        <?php 
                                        for ($i = 1; $i <= 5; $i++) {
                                            if ($i <= $rating['rating']) {
                                                echo '<i class="fas fa-star"></i>';
                                            } else {
                                                echo '<i class="far fa-star"></i>';
                                            }
                                        }
                                        ?>
                                        (<?= $rating['rating'] ?>/5)
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="no-ratings">
                            <i class="far fa-star" style="font-size: 2rem; color: #cbd5e1; margin-bottom: 10px;"></i>
                            <p>Belum ada rating untuk artikel ini</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <footer>
            <p>© <?= date('Y') ?> Panduan Perbaikan Elektronik. Hak Cipta Dilindungi.</p>
        </footer>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const starLabels = document.querySelectorAll('.star-rating label');
            const ratingInputs = document.querySelectorAll('.star-rating input');
            const ratingForm = document.getElementById('rating-form');
            
            // Fungsi untuk menyorot bintang
            function highlightStars(value) {
                starLabels.forEach((label, index) => {
                    if (index < value) {
                        label.style.color = '#f59e0b';
                    } else {
                        label.style.color = '#ccc';
                    }
                });
            }
            
            // Event listener untuk setiap bintang
            starLabels.forEach((label, index) => {
                label.addEventListener('click', function() {
                    const ratingValue = index + 1;
                    document.querySelector(`input[value="${ratingValue}"]`).checked = true;
                    highlightStars(ratingValue);
                });
                
                label.addEventListener('mouseover', function() {
                    highlightStars(index + 1);
                });
                
                label.addEventListener('mouseout', function() {
                    const checkedInput = document.querySelector('.star-rating input:checked');
                    if (checkedInput) {
                        highlightStars(parseInt(checkedInput.value));
                    } else {
                        highlightStars(0);
                    }
                });
            });
            
            // Inisialisasi awal jika ada rating yang sudah dipilih
            const checkedInput = document.querySelector('.star-rating input:checked');
            if (checkedInput) {
                highlightStars(parseInt(checkedInput.value));
            }
            
            // Validasi form sebelum submit
            if (ratingForm) {
                ratingForm.addEventListener('submit', function(e) {
                    const checkedRating = document.querySelector('input[name="rating"]:checked');
                    if (!checkedRating) {
                        e.preventDefault();
                        alert('Silakan pilih rating terlebih dahulu');
                        return false;
                    }
                    return true;
                });
            }
        });
    </script>
</body>
</html>