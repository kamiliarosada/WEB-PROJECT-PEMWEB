-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 26, 2025 at 06:34 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pemweb`
--

-- --------------------------------------------------------

--
-- Table structure for table `articles`
--

CREATE TABLE `articles` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `service_category_id` int(11) DEFAULT NULL,
  `author_id` int(11) NOT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `is_published` tinyint(1) DEFAULT 0,
  `average_rating` decimal(3,2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `articles`
--

INSERT INTO `articles` (`id`, `title`, `content`, `category_id`, `service_category_id`, `author_id`, `image_url`, `is_published`, `average_rating`, `created_at`, `updated_at`) VALUES
(1, 'How to Maintain Your Smartphone', 'Content about smartphone maintenance...', NULL, NULL, 1, NULL, 1, NULL, '2025-05-30 06:53:45', '2025-05-30 06:53:45'),
(2, 'Common Refrigerator Problems', 'Content about refrigerator issues...', NULL, NULL, 1, NULL, 1, NULL, '2025-05-30 06:53:45', '2025-05-30 06:53:45'),
(3, 'Basic Plumbing Tips', 'Content about plumbing maintenance...', NULL, NULL, 1, NULL, 1, NULL, '2025-05-30 06:53:45', '2025-06-07 08:03:29'),
(4, 'Electrical Safety at Home', 'Content about electrical safety...', NULL, NULL, 1, NULL, 1, NULL, '2025-05-30 06:53:45', '2025-06-07 05:40:52'),
(9, 'tes', 'drtoisdeto', NULL, 2, 70, 'uploads/articles/6853ef6d05b50.jpg', 1, NULL, '2025-06-19 11:07:09', '2025-06-19 11:07:25');

-- --------------------------------------------------------

--
-- Table structure for table `article_ratings`
--

CREATE TABLE `article_ratings` (
  `id` int(11) NOT NULL,
  `article_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `rating` tinyint(4) NOT NULL CHECK (`rating` between 1 and 5),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `article_ratings`
--

INSERT INTO `article_ratings` (`id`, `article_id`, `user_id`, `rating`, `created_at`) VALUES
(1, 3, 6, 5, '2025-06-19 10:58:40'),
(2, 4, 6, 1, '2025-06-19 11:01:42'),
(3, 9, 6, 5, '2025-06-19 11:07:50'),
(4, 1, 6, 5, '2025-06-21 11:14:22'),
(5, 2, 6, 3, '2025-06-25 01:55:56');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `technician_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `rating` int(11) NOT NULL CHECK (`rating` between 1 and 5),
  `comment` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `user_id`, `technician_id`, `order_id`, `rating`, `comment`, `created_at`) VALUES
(1, 7, 19, 13, 5, '', '2025-06-08 10:19:01'),
(2, 7, 19, 10, 5, '', '2025-06-08 10:19:31'),
(3, 6, 4, 15, 1, 'tipu tipu', '2025-06-19 11:00:48'),
(4, 6, 14, 17, 5, 'kereeeeeen', '2025-06-19 11:54:23'),
(5, 6, 2, 18, 5, 'kereen', '2025-06-25 02:27:14'),
(6, 6, 3, 21, 1, '', '2025-06-25 15:30:56');

-- --------------------------------------------------------

--
-- Table structure for table `item_types`
--

CREATE TABLE `item_types` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `service_category_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `technician_id` int(11) DEFAULT NULL,
  `customer_name` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `address` text NOT NULL,
  `device` varchar(100) NOT NULL,
  `service_date` date NOT NULL,
  `service_time` varchar(50) NOT NULL,
  `notes` text DEFAULT NULL,
  `item_type_id` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `status` enum('pending','processing','completed','cancelled') DEFAULT 'pending',
  `total_amount` decimal(10,2) DEFAULT NULL,
  `feedback_id` int(11) DEFAULT NULL,
  `is_verified` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `technician_id`, `customer_name`, `phone`, `address`, `device`, `service_date`, `service_time`, `notes`, `item_type_id`, `description`, `status`, `total_amount`, `feedback_id`, `is_verified`, `created_at`, `updated_at`) VALUES
(7, 7, 3, '', '', '', '', '0000-00-00', '', NULL, NULL, 'Perbaikan gayung lope lope\nNama Pelanggan: intan\nTelepon: 08543215678\nAlamat: jakarte\nTanggal: 2025-06-28\nWaktu: 08:00-10:00\nCatatan: tak de', 'cancelled', 250000.00, NULL, 1, '2025-06-08 07:50:16', '2025-06-25 02:42:05'),
(8, 7, 3, '', '', '', '', '0000-00-00', '', NULL, NULL, 'Perbaikan gayung lope lope\nNama Pelanggan: tan\nTelepon: 234567890\nAlamat: pulu pulu\nTanggal: 2025-06-26\nWaktu: 10:00-12:00\nCatatan: cek 12 3 cek', 'cancelled', 250000.00, NULL, 1, '2025-06-08 08:09:09', '2025-06-25 02:42:04'),
(9, 7, 4, '', '', '', '', '0000-00-00', '', NULL, NULL, 'Perbaikan y\nNama Pelanggan: iki\nTelepon: 08483727777\nAlamat: y\nTanggal: 2025-06-25\nWaktu: 08:00-10:00\nCatatan: y', 'pending', 400000.00, NULL, 1, '2025-06-08 08:36:34', '2025-06-08 10:30:58'),
(10, 7, 19, '', '', '', '', '0000-00-00', '', NULL, NULL, 'Perbaikan t\nNama Pelanggan: g\nTelepon: 8888888888\nAlamat: t\nTanggal: 2025-06-10\nWaktu: 08:00-10:00\nCatatan: t', 'completed', 280000.00, NULL, 1, '2025-06-08 08:39:56', '2025-06-08 10:30:57'),
(11, 7, 19, '', '', '', '', '0000-00-00', '', NULL, NULL, 'Perbaikan g\nNama Pelanggan: y\nTelepon: 8765432455\nAlamat: g\nTanggal: 2025-06-12\nWaktu: 10:00-12:00\nCatatan: g', 'completed', 280000.00, NULL, 1, '2025-06-08 08:40:40', '2025-06-08 10:30:56'),
(12, 7, 19, '', '', '', '', '0000-00-00', '', NULL, NULL, 'Perbaikan y\nNama Pelanggan: tan\nTelepon: 081234156789\nAlamat: y\nTanggal: 2025-06-11\nWaktu: 10:00-12:00\nCatatan: y', 'completed', 280000.00, NULL, 1, '2025-06-08 09:01:13', '2025-06-08 10:30:55'),
(13, 7, 19, 'intan', '08512345678', 'y', 'y', '2025-06-26', '08:00-10:00', 'y', NULL, 'Perbaikan y\nNama Pelanggan: intan\nTelepon: 08512345678\nAlamat: y\nTanggal: 2025-06-26\nWaktu: 08:00-10:00\nCatatan: y', 'completed', 280000.00, NULL, 1, '2025-06-08 09:54:34', '2025-06-08 10:30:54'),
(14, 6, 14, 'y', '098766554436', 'serjkd', 'hp', '2025-06-21', '13:00-15:00', '', NULL, 'Catatan: Tidak ada catatan', 'cancelled', 420000.00, NULL, 1, '2025-06-19 09:52:24', '2025-06-19 11:51:52'),
(15, 6, 4, 'y', '0868594030348', 'yyy', 'yyyy', '2025-06-30', '10:00-12:00', '', NULL, 'Catatan: Tidak ada catatan', 'completed', 400000.00, NULL, 1, '2025-06-19 10:57:59', '2025-06-19 11:51:50'),
(17, 6, 14, 'ocha', '09876543224', 'labuapi', 'samsung', '2025-06-23', '13:00-15:00', '', NULL, 'Catatan: Tidak ada catatan', 'completed', 420000.00, NULL, 1, '2025-06-19 11:50:56', '2025-06-19 11:53:34'),
(18, 6, 2, 'ocha', '08644321334', 'mat', 'mat', '2025-06-30', '10:00-12:00', '', NULL, 'Catatan: Tidak ada catatan', 'completed', 350000.00, NULL, 1, '2025-06-21 05:53:42', '2025-06-25 02:05:23'),
(19, 6, 7, 'halo', '0865443213', 'fgfj', 'c vbfgh', '2025-06-25', '08:00-10:00', '', NULL, 'Catatan: Tidak ada catatan', 'cancelled', 500000.00, NULL, 1, '2025-06-21 06:01:44', '2025-06-26 02:11:05'),
(20, 6, 17, 'haiyo', '0865443321', 'cbkdxb', 'c bcb', '2025-06-25', '15:00-17:00', '', NULL, 'Catatan: Tidak ada catatan', 'cancelled', 340000.00, NULL, 1, '2025-06-21 06:06:26', '2025-06-26 02:05:56'),
(21, 6, 3, 'tantun', '06858473774', 'gomong', 'tv samsung', '2025-06-27', '13:00-15:00', '', NULL, 'Catatan: Tidak ada catatan', 'completed', 250000.00, NULL, 1, '2025-06-25 02:33:27', '2025-06-26 02:21:34');

-- --------------------------------------------------------

--
-- Table structure for table `payment_methods`
--

CREATE TABLE `payment_methods` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `bank_name` varchar(100) NOT NULL,
  `account_number` varchar(50) NOT NULL,
  `account_name` varchar(100) NOT NULL,
  `is_default` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payment_methods`
--

INSERT INTO `payment_methods` (`id`, `user_id`, `bank_name`, `account_number`, `account_name`, `is_default`, `created_at`) VALUES
(1, 6, 'GBI', '0584773848', 'Tan', 1, '2025-06-19 09:52:24'),
(2, 6, 'bri', '079695848', 'tayo', 0, '2025-06-21 06:06:26');

-- --------------------------------------------------------

--
-- Table structure for table `regular_users`
--

CREATE TABLE `regular_users` (
  `user_id` int(11) NOT NULL,
  `preferences` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `service_categories`
--

CREATE TABLE `service_categories` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `service_categories`
--

INSERT INTO `service_categories` (`id`, `name`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Kulkas', 'Perbaikan segala merek kulkas 1 pintu, 2 pintu, side by side, dan showcase. Termasuk ganti kompresor, thermostat, dan kebocoran freon.', '2025-06-08 06:07:22', '2025-06-08 06:07:22'),
(2, 'AC', 'Service berkala, isi freon, perbaikan outdoor/indoor unit, ganti kapasitor, hingga pemasangan AC baru untuk rumah dan kantor.', '2025-06-08 06:07:22', '2025-06-08 06:07:22'),
(3, 'Mesin Cuci', 'Perbaikan mesin cuci top loading, front loading, 1 tabung/2 tabung. Ganti bearing, seal, pompa drain, dan modul kontrol.', '2025-06-08 06:07:22', '2025-06-08 06:07:22'),
(4, 'TV', 'Servis TV LED, OLED, QLED, dan Smart TV. Perbaikan layar, backlight, power supply, dan masalah software.', '2025-06-08 06:07:22', '2025-06-08 06:07:22'),
(5, 'Laptop', 'Upgrade hardware, ganti LCD, keyboard, baterai, perbaikan motherboard, cleaning, dan instalasi sistem operasi.', '2025-06-08 06:07:22', '2025-06-08 06:07:22'),
(6, 'Hp', 'perbaiki apalah apalah', '2025-06-08 10:33:12', '2025-06-08 10:33:12');

-- --------------------------------------------------------

--
-- Table structure for table `technicians`
--

CREATE TABLE `technicians` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `specialization` varchar(100) DEFAULT NULL,
  `experience_years` int(11) DEFAULT NULL,
  `certification` varchar(255) DEFAULT NULL,
  `rate` decimal(10,2) DEFAULT 0.00,
  `is_verified` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `technicians`
--

INSERT INTO `technicians` (`id`, `user_id`, `specialization`, `experience_years`, `certification`, `rate`, `is_verified`, `created_at`, `updated_at`) VALUES
(1, 50, 'Kulkas', 5, 'Sertifikasi Teknisi Kulkas Berpengalaman', 150000.00, 1, '2025-06-08 06:50:06', '2025-06-08 06:50:06'),
(2, 51, 'AC', 4, 'Sertifikasi Teknisi AC Level Advance', 5.00, 1, '2025-06-08 06:50:06', '2025-06-25 02:27:14'),
(3, 52, 'Mesin Cuci', 3, 'Sertifikasi Resmi Teknisi Mesin Cuci', 1.00, 1, '2025-06-08 06:50:06', '2025-06-25 15:30:56'),
(4, 53, 'TV', 6, 'Sertifikasi Master Teknisi TV', 1.00, 1, '2025-06-08 06:50:06', '2025-06-19 11:00:48'),
(6, 55, 'Kulkas', 2, 'Sertifikasi Dasar Perbaikan Kulkas', 120000.00, 1, '2025-06-08 06:50:06', '2025-06-08 06:50:06'),
(7, 56, 'AC', 7, 'Sertifikasi Master AC + Pemasangan', 250000.00, 1, '2025-06-08 06:50:06', '2025-06-08 06:50:06'),
(8, 57, 'Mesin Cuci', 4, 'Sertifikasi Mesin Cuci Multimerek', 140000.00, 1, '2025-06-08 06:50:06', '2025-06-08 06:50:06'),
(9, 58, 'TV', 3, 'Sertifikasi Teknisi Smart TV', 180000.00, 1, '2025-06-08 06:50:06', '2025-06-08 06:50:06'),
(10, 59, 'Laptop', 6, 'Sertifikasi Advanced Chip-Level Laptop', 240000.00, 1, '2025-06-08 06:50:06', '2025-06-08 06:50:06'),
(11, 60, 'Kulkas', 5, 'Sertifikasi Teknisi Kulkas Komersial', 160000.00, 1, '2025-06-08 06:50:06', '2025-06-08 06:50:06'),
(12, 61, 'AC', 4, 'Sertifikasi Teknisi AC Central', 190000.00, 1, '2025-06-08 06:50:06', '2025-06-08 06:50:06'),
(13, 62, 'Mesin Cuci', 2, 'Sertifikasi Dasar Mesin Cuci Modern', 110000.00, 1, '2025-06-08 06:50:06', '2025-06-08 06:50:06'),
(14, 63, 'TV', 5, 'Sertifikasi Teknisi TV Proyektor', 5.00, 1, '2025-06-08 06:50:06', '2025-06-19 11:54:23'),
(16, 65, 'Kulkas', 6, 'Sertifikasi Master Kulkas Industri', 180000.00, 1, '2025-06-08 06:50:06', '2025-06-08 06:50:06'),
(17, 66, 'AC', 4, 'Sertifikasi Teknisi AC Inverter', 170000.00, 1, '2025-06-08 06:50:06', '2025-06-08 06:50:06'),
(18, 67, 'Mesin Cuci', 5, 'Sertifikasi Mesin Cuci Otomatis', 150000.00, 1, '2025-06-08 06:50:06', '2025-06-08 06:50:06'),
(19, 68, 'TV', 2, 'Sertifikasi Dasar TV Digital', 140000.00, 1, '2025-06-08 06:50:06', '2025-06-08 06:50:06'),
(20, 69, 'Laptop', 4, 'Sertifikasi Teknisi Laptop Premium', 200000.00, 1, '2025-06-08 06:50:06', '2025-06-08 06:50:06'),
(23, 70, 'kulkas', 7, 'DIAGRAM-kepribadian-manusia.jpg', 25000.00, 1, '2025-06-19 11:06:31', '2025-06-19 11:51:36');

-- --------------------------------------------------------

--
-- Table structure for table `technician_earnings`
--

CREATE TABLE `technician_earnings` (
  `id` int(11) NOT NULL,
  `technician_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `gross_amount` decimal(10,2) NOT NULL,
  `admin_fee` decimal(10,2) NOT NULL,
  `net_amount` decimal(10,2) NOT NULL,
  `payment_status` enum('pending','paid') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `paid_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `technician_skills`
--

CREATE TABLE `technician_skills` (
  `user_id` int(11) NOT NULL,
  `service_category_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `technician_skills`
--

INSERT INTO `technician_skills` (`user_id`, `service_category_id`) VALUES
(50, 1),
(50, 2),
(51, 1),
(51, 3),
(52, 4),
(52, 5),
(53, 4),
(53, 5),
(54, 1),
(54, 2),
(54, 3),
(55, 2),
(55, 3),
(56, 1),
(56, 4),
(57, 3),
(57, 5),
(58, 2),
(58, 4),
(58, 5),
(59, 1),
(59, 2),
(60, 3),
(60, 4),
(61, 2),
(61, 5),
(62, 1),
(62, 3),
(62, 5),
(63, 3),
(63, 4),
(64, 2),
(64, 5),
(65, 1),
(65, 2),
(65, 4),
(66, 1),
(66, 4),
(67, 3),
(67, 5),
(68, 2),
(68, 3),
(68, 5),
(69, 1),
(69, 4),
(70, 1),
(70, 3);

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `payment_method_id` int(11) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_type` enum('full','deposit','cod') NOT NULL,
  `status` enum('pending','completed','refunded','failed') DEFAULT 'pending',
  `transaction_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `completed_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`id`, `order_id`, `payment_method_id`, `amount`, `payment_type`, `status`, `transaction_date`, `completed_at`) VALUES
(1, 14, 1, 210000.00, 'deposit', 'completed', '2025-06-19 09:52:24', '2025-06-19 09:52:43'),
(2, 15, 1, 400000.00, 'full', 'completed', '2025-06-19 10:57:59', '2025-06-19 10:58:08'),
(4, 17, 1, 420000.00, 'full', 'completed', '2025-06-19 11:50:56', '2025-06-19 11:50:58'),
(5, 18, 1, 175000.00, 'deposit', 'completed', '2025-06-21 05:53:42', '2025-06-21 05:53:53'),
(6, 19, 1, 500000.00, 'full', 'refunded', '2025-06-21 06:01:44', '2025-06-21 06:01:50'),
(7, 20, 2, 170000.00, 'deposit', 'refunded', '2025-06-21 06:06:26', '2025-06-21 06:06:30'),
(8, 21, 2, 250000.00, 'full', 'completed', '2025-06-25 02:33:27', '2025-06-25 02:33:33');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  `gender` enum('male','female','other') DEFAULT NULL,
  `profile_picture` varchar(255) DEFAULT NULL,
  `role` enum('admin','technician','user') DEFAULT 'user',
  `is_verified` tinyint(1) DEFAULT 0,
  `is_suspended` tinyint(1) DEFAULT 0,
  `cancellation_count` int(11) NOT NULL DEFAULT 0,
  `last_cancellation_date` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `email`, `password`, `phone`, `country`, `gender`, `profile_picture`, `role`, `is_verified`, `is_suspended`, `cancellation_count`, `last_cancellation_date`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'admin', 'admin@locals.com', 'admin', '', '', '', NULL, 'admin', 1, 0, 0, NULL, '2025-05-30 06:53:45', '2025-06-07 06:20:07'),
(4, 'Mike Johnson', 'mikej', 'mike@example.com', 'mikej', '555123456', 'Canada', 'male', NULL, 'technician', 1, 0, 0, NULL, '2025-05-30 06:53:45', '2025-06-20 08:33:46'),
(6, 'ocha', 'ocha', 'ocha@gmail', 'ocha', '12345567889', 'Mataram', 'female', 'semangka.jpg', 'user', 1, 0, 2, '2025-06-26 10:11:05', '2025-06-03 05:27:10', '2025-06-26 02:15:30'),
(7, 'tan', 'tan', 'tan@gmail.com', '123', '234567890', 'Indonesia', 'male', 'DIAGRAM-kepribadian-manusia.jpg', 'user', 1, 0, 0, NULL, '2025-06-06 10:42:48', '2025-06-08 10:32:26'),
(9, 'salsa', 'salsa', 'salsa@unram.com', '123456', NULL, NULL, NULL, NULL, 'admin', 1, 0, 0, NULL, '2025-06-07 05:28:14', '2025-06-07 05:28:14'),
(50, 'Budi Setiawan', 'tech_budi', 'budi.setiawan@example.com', 'password123', '081234567890', 'Indonesia', 'male', NULL, 'technician', 1, 0, 0, NULL, '2025-06-08 06:07:22', '2025-06-08 06:07:22'),
(51, 'Siti Nurhaliza', 'siti_tech', 'siti.nurhaliza@example.com', 'password123', '082345678901', 'Indonesia', 'female', NULL, 'technician', 1, 0, 0, NULL, '2025-06-08 06:07:22', '2025-06-08 06:07:22'),
(52, 'Agus Kurniawan', 'agus_elektro', 'agus.kurniawan@example.com', 'password123', '083456789012', 'Indonesia', 'male', NULL, 'technician', 1, 0, 0, NULL, '2025-06-08 06:07:22', '2025-06-08 06:07:22'),
(53, 'Dewi Anggraeni', 'dewi_repair', 'dewi.anggraeni@example.com', 'password123', '084567890123', 'Indonesia', 'female', NULL, 'technician', 1, 0, 0, NULL, '2025-06-08 06:07:22', '2025-06-08 06:07:22'),
(54, 'Joko Susilo', 'joko_handyman', 'joko.susilo@example.com', 'password123', '085678901234', 'Indonesia', 'male', NULL, 'technician', 1, 0, 0, NULL, '2025-06-08 06:07:22', '2025-06-08 06:07:22'),
(55, 'Ani Wijayanti', 'ani_techno', 'ani.wijayanti@example.com', 'password123', '086789012345', 'Indonesia', 'female', NULL, 'technician', 1, 0, 0, NULL, '2025-06-08 06:07:22', '2025-06-08 06:07:22'),
(56, 'Eko Pratama', 'eko_fix', 'eko.pratama@example.com', 'password123', '087890123456', 'Indonesia', 'male', NULL, 'technician', 1, 0, 0, NULL, '2025-06-08 06:07:22', '2025-06-08 06:07:22'),
(57, 'Rina Amelia', 'rina_tech', 'rina.amelia@example.com', 'password123', '088901234567', 'Indonesia', 'female', NULL, 'technician', 1, 0, 0, NULL, '2025-06-08 06:07:22', '2025-06-08 06:07:22'),
(58, 'Hendra Kurnia', 'hendra_service', 'hendra.kurnia@example.com', 'password123', '089012345678', 'Indonesia', 'male', NULL, 'technician', 1, 0, 0, NULL, '2025-06-08 06:07:22', '2025-06-08 06:07:22'),
(59, 'Linda Permata', 'linda_fixit', 'linda.permata@example.com', 'password123', '081123456789', 'Indonesia', 'female', NULL, 'technician', 1, 0, 0, NULL, '2025-06-08 06:07:22', '2025-06-08 06:07:22'),
(60, 'Ahmad Yusuf', 'ahmad_repair', 'ahmad.yusuf@example.com', 'password123', '082234567890', 'Indonesia', 'male', NULL, 'technician', 1, 0, 0, NULL, '2025-06-08 06:07:22', '2025-06-08 06:07:22'),
(61, 'Yuni Kartika', 'yuni_techie', 'yuni.kartika@example.com', 'password123', '083345678901', 'Indonesia', 'female', NULL, 'technician', 1, 0, 0, NULL, '2025-06-08 06:07:22', '2025-06-08 06:07:22'),
(62, 'Rudi Cahyadi', 'rudi_servis', 'rudi.cahyadi@example.com', 'password123', '084456789012', 'Indonesia', 'male', NULL, 'technician', 1, 0, 0, NULL, '2025-06-08 06:07:22', '2025-06-08 06:07:22'),
(63, 'Maya Indah', 'maya_tech', 'maya.indah@example.com', 'password123', '085567890123', 'Indonesia', 'female', NULL, 'technician', 1, 0, 0, NULL, '2025-06-08 06:07:22', '2025-06-08 06:07:22'),
(64, 'Fajar Nugroho', 'fajar_elektro', 'fajar.nugroho@example.com', 'password123', '086678901234', 'Indonesia', 'male', NULL, 'user', 1, 0, 0, NULL, '2025-06-08 06:07:22', '2025-06-19 10:38:05'),
(65, 'Dian Puspita', 'dian_fix', 'dian.puspita@example.com', 'password123', '087789012345', 'Indonesia', 'female', NULL, 'technician', 1, 0, 0, NULL, '2025-06-08 06:07:22', '2025-06-08 06:07:22'),
(66, 'Irfan Mahendra', 'irfan_tech', 'irfan.mahendra@example.com', 'password123', '088890123456', 'Indonesia', 'male', NULL, 'technician', 1, 0, 0, NULL, '2025-06-08 06:07:22', '2025-06-08 06:07:22'),
(67, 'Nur Aisyah', 'nur_repair', 'nur.aisyah@example.com', 'password123', '089901234567', 'Indonesia', 'female', NULL, 'technician', 1, 0, 0, NULL, '2025-06-08 06:07:22', '2025-06-08 06:07:22'),
(68, 'Adi Saputro', 'adi_service', 'adi.saputro@example.com', 'password123', '081012345678', 'Lombok Barat', 'female', NULL, 'technician', 1, 0, 0, NULL, '2025-06-08 06:07:22', '2025-06-26 02:18:29'),
(69, 'Ratna Wulandari', 'ratna_techie', 'ratna.wulandari@example.com', 'password123', '082123456789', 'Indonesia', 'female', NULL, 'technician', 1, 0, 0, NULL, '2025-06-08 06:07:22', '2025-06-08 06:07:22'),
(70, 'tayo', 'tayo', 'tayo@gmail.com', '123456', '123456', 'Indonesia', 'male', 'semangka.jpg', 'technician', 1, 0, 0, NULL, '2025-06-19 11:06:31', '2025-06-19 11:51:36');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `author_id` (`author_id`),
  ADD KEY `service_category_id` (`service_category_id`);

--
-- Indexes for table `article_ratings`
--
ALTER TABLE `article_ratings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `article_id` (`article_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `technician_id` (`technician_id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indexes for table `item_types`
--
ALTER TABLE `item_types`
  ADD PRIMARY KEY (`id`),
  ADD KEY `service_category_id` (`service_category_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `technician_id` (`technician_id`),
  ADD KEY `item_type_id` (`item_type_id`),
  ADD KEY `fk_feedback` (`feedback_id`);

--
-- Indexes for table `payment_methods`
--
ALTER TABLE `payment_methods`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `regular_users`
--
ALTER TABLE `regular_users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `service_categories`
--
ALTER TABLE `service_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `technicians`
--
ALTER TABLE `technicians`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `technician_earnings`
--
ALTER TABLE `technician_earnings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `technician_id` (`technician_id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indexes for table `technician_skills`
--
ALTER TABLE `technician_skills`
  ADD PRIMARY KEY (`user_id`,`service_category_id`),
  ADD KEY `service_category_id` (`service_category_id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `payment_method_id` (`payment_method_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `articles`
--
ALTER TABLE `articles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `article_ratings`
--
ALTER TABLE `article_ratings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `item_types`
--
ALTER TABLE `item_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `payment_methods`
--
ALTER TABLE `payment_methods`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `service_categories`
--
ALTER TABLE `service_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `technicians`
--
ALTER TABLE `technicians`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `technician_earnings`
--
ALTER TABLE `technician_earnings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `articles`
--
ALTER TABLE `articles`
  ADD CONSTRAINT `articles_ibfk_1` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `articles_ibfk_2` FOREIGN KEY (`service_category_id`) REFERENCES `service_categories` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `article_ratings`
--
ALTER TABLE `article_ratings`
  ADD CONSTRAINT `article_ratings_ibfk_1` FOREIGN KEY (`article_id`) REFERENCES `articles` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `article_ratings_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `feedback`
--
ALTER TABLE `feedback`
  ADD CONSTRAINT `feedback_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `feedback_ibfk_2` FOREIGN KEY (`technician_id`) REFERENCES `technicians` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `feedback_ibfk_3` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `item_types`
--
ALTER TABLE `item_types`
  ADD CONSTRAINT `item_types_ibfk_1` FOREIGN KEY (`service_category_id`) REFERENCES `service_categories` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `fk_feedback` FOREIGN KEY (`feedback_id`) REFERENCES `feedback` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`technician_id`) REFERENCES `technicians` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `orders_ibfk_3` FOREIGN KEY (`item_type_id`) REFERENCES `item_types` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `payment_methods`
--
ALTER TABLE `payment_methods`
  ADD CONSTRAINT `payment_methods_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `regular_users`
--
ALTER TABLE `regular_users`
  ADD CONSTRAINT `regular_users_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `technicians`
--
ALTER TABLE `technicians`
  ADD CONSTRAINT `technicians_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `technician_earnings`
--
ALTER TABLE `technician_earnings`
  ADD CONSTRAINT `technician_earnings_ibfk_1` FOREIGN KEY (`technician_id`) REFERENCES `technicians` (`id`),
  ADD CONSTRAINT `technician_earnings_ibfk_2` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`);

--
-- Constraints for table `technician_skills`
--
ALTER TABLE `technician_skills`
  ADD CONSTRAINT `technician_skills_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `technician_skills_ibfk_2` FOREIGN KEY (`service_category_id`) REFERENCES `service_categories` (`id`);

--
-- Constraints for table `transactions`
--
ALTER TABLE `transactions`
  ADD CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `transactions_ibfk_2` FOREIGN KEY (`payment_method_id`) REFERENCES `payment_methods` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
