<?php
session_start();
require_once '../../db.php';

// Check if user is logged in and is a technician
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'technician') {
    header('Location: ../../login.php');
    exit;
}
$user_id = (int)$_SESSION['user_id'];

// Get user and technician data
$user = $conn->query("SELECT * FROM users WHERE id = $user_id")->fetch_assoc();
$technician = $conn->query("SELECT * FROM technicians WHERE user_id = $user_id")->fetch_assoc();

// Handle account deletion
if (isset($_POST['delete_account'])) {
    // Start transaction
    $conn->begin_transaction();
    
    try {
        // Delete from technicians table first
        $conn->query("DELETE FROM technicians WHERE user_id = $user_id");
        
        // Then delete from users table
        $conn->query("DELETE FROM users WHERE id = $user_id");
        
        $conn->commit();
        
        // Logout and redirect
        session_destroy();
        header('Location: ../../login.php?account_deleted=1');
        exit;
    } catch (Exception $e) {
        $conn->rollback();
        $_SESSION['error'] = "Failed to delete account: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <div class="row">
            <div class="col-md-3">
                <?php include '../sidebar.php'; ?>
            </div>
            <div class="col-md-9">
                <div class="container mt-5">
                    <div class="row">
                        <div class="col-md-8 offset-md-2">
                            <div class="card">
                                <div class="card-header">
                                    <h3>My Profile</h3>
                                </div>
                                <div class="card-body">
                                    <?php if (isset($_SESSION['success'])): ?>
                                        <div class="alert alert-success"><?= $_SESSION['success'] ?></div>
                                        <?php unset($_SESSION['success']); ?>
                                    <?php endif; ?>
                                    
                                    <?php if (isset($_SESSION['error'])): ?>
                                        <div class="alert alert-danger"><?= $_SESSION['error'] ?></div>
                                        <?php unset($_SESSION['error']); ?>
                                    <?php endif; ?>
                                    
                                    <div class="row mb-3">
                                        <div class="col-md-4 font-weight-bold">Name:</div>
                                        <div class="col-md-8"><?= htmlspecialchars($user['name']) ?></div>
                                    </div>
                                    <div class="row mb-3">
                                        <div class="col-md-4 font-weight-bold">Username:</div>
                                        <div class="col-md-8"><?= htmlspecialchars($user['username']) ?></div>
                                    </div>
                                    <div class="row mb-3">
                                        <div class="col-md-4 font-weight-bold">Email:</div>
                                        <div class="col-md-8"><?= htmlspecialchars($user['email']) ?></div>
                                    </div>
                                    <div class="row mb-3">
                                        <div class="col-md-4 font-weight-bold">Phone:</div>
                                        <div class="col-md-8"><?= htmlspecialchars($user['phone'] ?? 'Not set') ?></div>
                                    </div>
                                    <div class="row mb-3">
                                        <div class="col-md-4 font-weight-bold">Your Region:</div>
                                        <div class="col-md-8"><?= htmlspecialchars($user['country'] ?? 'Not set') ?></div>
                                    </div>
                                    <div class="row mb-3">
                                        <div class="col-md-4 font-weight-bold">Gender:</div>
                                        <div class="col-md-8"><?= ucfirst($user['gender'] ?? 'Not set') ?></div>
                                    </div>
                                    <div class="row mb-3">
                                        <div class="col-md-4 font-weight-bold">Specialization:</div>
                                        <div class="col-md-8"><?= htmlspecialchars($technician['specialization'] ?? 'Not set') ?></div>
                                    </div>
                                    <div class="row mb-3">
                                        <div class="col-md-4 font-weight-bold">Experience:</div>
                                        <div class="col-md-8"><?= $technician['experience_years'] ?? '0' ?> years</div>
                                    </div>
                                    <div class="row mb-3">
                                        <div class="col-md-4 font-weight-bold">Certification:</div>
                                        <div class="col-md-8"><?= htmlspecialchars($technician['certification'] ?? 'Not set') ?></div>
                                    </div>
                                    <div class="row mb-3">
                                        <div class="col-md-4 font-weight-bold">Rate per hour:</div>
                                        <div class="col-md-8">Rp <?= number_format($technician['rate'] ?? 0, 2) ?></div>
                                    </div>
                                    
                                    <div class="row mt-4 g-2">
                                        <div class="col-md-4">
                                            <a href="edit_profile.php" class="btn btn-primary w-100">Edit Profile</a>
                                        </div>
                                        <div class="col-md-4">
                                            <a href="setting.php" class="btn btn-warning w-100">Change Password</a>
                                        </div>
                                        <div class="col-md-4">
                                            <button type="button" class="btn btn-danger w-100" data-bs-toggle="modal" data-bs-target="#deleteModal">
                                                Delete Account
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Delete Account Modal -->
    <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="deleteModalLabel">Confirm Account Deletion</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to delete your account? This action cannot be undone. All your data will be permanently removed.</p>
                    <p class="text-danger"><strong>Warning:</strong> This will delete all your profile information, service history, and any associated data.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <form method="POST" action="">
                        <button type="submit" name="delete_account" class="btn btn-danger">Delete My Account</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>