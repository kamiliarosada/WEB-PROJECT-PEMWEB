<?php
session_start();
require_once '../db.php';

// Check if user is logged in and is a technician
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'technician') {
    header('Location: ../login.php');
    exit;
}

$user_id = (int)$_SESSION['user_id'];

// Get statistics
$total_orders = $conn->query("SELECT COUNT(*) FROM orders o JOIN technicians t ON o.technician_id = t.id WHERE t.user_id = $user_id")->fetch_row()[0];
$pending_orders = $conn->query("SELECT COUNT(*) FROM orders o JOIN technicians t ON o.technician_id = t.id WHERE t.user_id = $user_id AND o.status = 'pending'")->fetch_row()[0];
$completed_orders = $conn->query("SELECT COUNT(*) FROM orders o JOIN technicians t ON o.technician_id = t.id WHERE t.user_id = $user_id AND o.status = 'completed'")->fetch_row()[0];

// Get average rating
$avg_rating_result = $conn->query("
    SELECT AVG(f.rating) as avg_rating 
    FROM feedback f 
    JOIN technicians t ON f.technician_id = t.id 
    WHERE t.user_id = $user_id
");
$avg_rating = $avg_rating_result ? ($avg_rating_result->fetch_assoc()['avg_rating'] ?? 0) : 0;

// Get total earnings
$total_earnings_result = $conn->query("
    SELECT COALESCE(SUM(o.total_amount), 0) as total_earnings
    FROM orders o
    JOIN technicians t ON o.technician_id = t.id
    JOIN transactions tr ON o.id = tr.order_id
    WHERE t.user_id = $user_id 
    AND o.status = 'completed'
    AND tr.status = 'completed'
");
$total_earnings = $total_earnings_result ? ($total_earnings_result->fetch_assoc()['total_earnings'] ?? 0) : 0;

// Get monthly performance (including earnings)
$monthly_performance = [];
for ($i = 5; $i >= 0; $i--) {
    $month = date('Y-m', strtotime("-$i months"));
    $query = $conn->query("
        SELECT 
            COUNT(*) as count,
            COALESCE(SUM(o.total_amount), 0) as earnings
        FROM orders o 
        JOIN technicians t ON o.technician_id = t.id 
        JOIN transactions tr ON o.id = tr.order_id
        WHERE t.user_id = $user_id 
            AND o.status = 'completed' 
            AND tr.status = 'completed'
            AND DATE_FORMAT(o.created_at, '%Y-%m') = '$month'
    ");
    $result = $query->fetch_assoc();
    $monthly_performance[] = [
        'month' => date('M Y', strtotime($month . '-01')),
        'count' => $result['count'],
        'earnings' => $result['earnings']
    ];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Performance</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <div class="row">
            <div class="col-md-3">
                <?php include 'sidebar.php'; ?>
            </div>
            <div class="col-md-9">
                <h2>My Performance</h2>
                
                <div class="row mb-4">
                    <div class="col-md-3">
                        <div class="card stat-card bg-primary text-white">
                            <div class="card-body">
                                <h5 class="card-title">Total Orders</h5>
                                <h2><?= $total_orders ?></h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card stat-card bg-warning text-dark">
                            <div class="card-body">
                                <h5 class="card-title">Pending Orders</h5>
                                <h2><?= $pending_orders ?></h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card stat-card bg-success text-white">
                            <div class="card-body">
                                <h5 class="card-title">Completed</h5>
                                <h2><?= $completed_orders ?></h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card stat-card bg-info text-white">
                            <div class="card-body">
                                <h5 class="card-title">Avg Rating</h5>
                                <h2>
                                    <?= number_format($avg_rating, 1) ?>
                                    <i class="bi bi-star-fill text-warning"></i>
                                </h2>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="row mb-4">
                    <div class="col-md-6">
                        <div class="card stat-card bg-purple text-white">
                            <div class="card-body">
                                <h5 class="card-title">Total Income</h5>
                                <h2><?= number_format($total_earnings, 2) ?> <small>IDR</small></h2>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="card mb-4">
                    <div class="card-header">
                        <h5>Monthly Performance</h5>
                    </div>
                    <div class="card-body">
                        <canvas id="performanceChart"></canvas>
                    </div>
                </div>
                
                <div class="card mb-4">
                    <div class="card-header">
                        <h5>Monthly Income</h5>
                    </div>
                    <div class="card-body">
                        <canvas id="earningsChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Performance Chart (Orders Completed)
        const ctx = document.getElementById('performanceChart').getContext('2d');
        const performanceChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: <?= json_encode(array_column($monthly_performance, 'month')) ?>,
                datasets: [{
                    label: 'Completed Orders',
                    data: <?= json_encode(array_column($monthly_performance, 'count')) ?>,
                    backgroundColor: 'rgba(54, 162, 235, 0.5)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            precision: 0
                        }
                    }
                }
            }
        });
        
        // Earnings Chart
        const earningsCtx = document.getElementById('earningsChart').getContext('2d');
        const earningsChart = new Chart(earningsCtx, {
            type: 'line',
            data: {
                labels: <?= json_encode(array_column($monthly_performance, 'month')) ?>,
                datasets: [{
                    label: 'Earnings (IDR)',
                    data: <?= json_encode(array_column($monthly_performance, 'earnings')) ?>,
                    backgroundColor: 'rgba(75, 192, 192, 0.2)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 2,
                    tension: 0.1,
                    fill: true
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return 'IDR ' + value.toLocaleString();
                            }
                        }
                    }
                },
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return 'IDR ' + context.raw.toLocaleString();
                            }
                        }
                    }
                }
            }
        });
    </script>
    
    <style>
        .bg-purple {
            background-color: #6f42c1 !important;
        }
        .stat-card {
            transition: transform 0.3s;
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
    </style>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>