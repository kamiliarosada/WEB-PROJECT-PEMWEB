<?php
session_start();
require_once '../db.php';

// Check if user is logged in and is a technician
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'technician') {
    header('Location: ../login.php');
    exit;
}

if (!isset($_GET['id'])) {
    header('Location: schedule.php');
    exit;
}

$order_id = (int)$_GET['id'];
$user_id = (int)$_SESSION['user_id'];

// Get order details with payment information
$order_query = $conn->query("
    SELECT 
        o.*,
        t.user_id as technician_user_id,
        it.name as item_type,
        sc.name as service_category,
        f.rating,
        f.comment as feedback,
        tr.payment_type,
        tr.status as payment_status,
        tr.amount,
        tr.completed_at as payment_date,
        pm.bank_name,
        pm.account_number,
        pm.account_name
    FROM orders o
    JOIN technicians t ON o.technician_id = t.id
    LEFT JOIN item_types it ON o.item_type_id = it.id
    LEFT JOIN service_categories sc ON it.service_category_id = sc.id
    LEFT JOIN feedback f ON o.id = f.order_id
    LEFT JOIN transactions tr ON o.id = tr.order_id
    LEFT JOIN payment_methods pm ON tr.payment_method_id = pm.id
    WHERE o.id = $order_id AND t.user_id = $user_id
");

if ($order_query->num_rows === 0) {
    header('Location: schedule.php');
    exit;
}

$order = $order_query->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Details</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        .badge-pending {
            background-color: #ffc107;
            color: #000;
        }
        .badge-processing {
            background-color: #0dcaf0;
            color: #000;
        }
        .badge-completed {
            background-color: #198754;
        }
        .badge-cancelled {
            background-color: #dc3545;
        }
        .star-rating {
            color: #ffc107;
            font-size: 1.2rem;
        }
        .service-badge {
            background-color: #6c757d;
            color: white;
        }
        .payment-badge {
            background-color: #6f42c1;
            color: white;
        }
        .payment-details {
            background-color: #f8f9fa;
            border-radius: 8px;
            padding: 15px;
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <div class="row">
            <div class="col-md-3">
                <?php include 'sidebar.php'; ?>
            </div>
            <div class="col-md-9">
                <h2><i class="bi bi-file-text"></i> Order Details</h2>
                
                <?php if (isset($_GET['success'])): ?>
                    <div class="alert alert-success alert-dismissible fade show">
                        <?= htmlspecialchars($_GET['success']) ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <div class="card">
                    <div class="card-header">
                        <h5>Order #<?= $order['id'] ?></h5>
                        <span class="badge rounded-pill badge-<?= $order['status'] ?>">
                            <?= ucfirst($order['status']) ?>
                        </span>
                    </div>
                    <div class="card-body">
                        <div class="row mb-4">
                            <div class="col-md-6">
                                <h6>Customer Information</h6>
                                <p><strong>Name:</strong> <?= htmlspecialchars($order['customer_name']) ?></p>
                                <p><strong>Phone:</strong> <?= htmlspecialchars($order['phone']) ?></p>
                                <p><strong>Address:</strong> <?= htmlspecialchars($order['address']) ?></p>
                            </div>
                            <div class="col-md-6">
                                <h6>Service Details</h6>
                                <?php if ($order['service_category']): ?>
                                    <p>
                                        <strong>Category:</strong> 
                                        <span class="badge service-badge"><?= htmlspecialchars($order['service_category']) ?></span>
                                    </p>
                                    <p><strong>Service Type:</strong> <?= htmlspecialchars($order['item_type']) ?></p>
                                <?php endif; ?>
                                <p><strong>Device:</strong> <?= htmlspecialchars($order['device']) ?></p>
                                <p><strong>Service Date:</strong> <?= date('d M Y', strtotime($order['service_date'])) ?></p>
                                <p><strong>Time Slot:</strong> <?= htmlspecialchars($order['service_time']) ?></p>
                                <?php if ($order['total_amount']): ?>
                                    <p><strong>Total Amount:</strong> $<?= number_format($order['total_amount'], 2) ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="mb-4">
                            <h6>Payment Information</h6>
                            <div class="payment-details">
                                <?php if ($order['payment_type']): ?>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <p><strong>Payment Type:</strong> 
                                                <span class="badge payment-badge">
                                                    <?= strtoupper($order['payment_type']) ?>
                                                </span>
                                            </p>
                                            <p><strong>Status:</strong> 
                                                <span class="badge bg-<?= $order['payment_status'] == 'completed' ? 'success' : 'warning' ?>">
                                                    <?= ucfirst($order['payment_status']) ?>
                                                </span>
                                            </p>
                                            <p><strong>Amount Paid:</strong> $<?= number_format($order['amount'], 2) ?></p>
                                            <?php if ($order['payment_date']): ?>
                                                <p><strong>Payment Date:</strong> <?= date('d M Y H:i', strtotime($order['payment_date'])) ?></p>
                                            <?php endif; ?>
                                        </div>
                                        <div class="col-md-6">
                                            <?php if ($order['payment_type'] == 'bank_transfer' && $order['bank_name']): ?>
                                                <p><strong>Bank Details:</strong></p>
                                                <p>Bank: <?= htmlspecialchars($order['bank_name']) ?></p>
                                                <p>Account: <?= htmlspecialchars($order['account_number']) ?></p>
                                                <p>Name: <?= htmlspecialchars($order['account_name']) ?></p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <p class="text-muted">No payment information available</p>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="mb-4">
                            <h6>Description/Notes</h6>
                            <div class="p-3 bg-light rounded">
                                <?= $order['description'] ? nl2br(htmlspecialchars($order['description'])) : 
                                   ($order['notes'] ? nl2br(htmlspecialchars($order['notes'])) : 'No description provided') ?>
                            </div>
                        </div>
                        
                        <?php if ($order['status'] == 'completed' && $order['feedback']): ?>
                        <div class="mb-4">
                            <h6>Customer Feedback</h6>
                            <div class="feedback-card">
                                <div class="star-rating mb-2">
                                    <?php for ($i = 1; $i <= 5; $i++): ?>
                                        <i class="bi bi-star<?= $i <= $order['rating'] ? '-fill' : '' ?>"></i>
                                    <?php endfor; ?>
                                </div>
                                <p><?= nl2br(htmlspecialchars($order['feedback'])) ?></p>
                            </div>
                        </div>
                        <?php endif; ?>
                        
                        <div class="mt-4">
                            <?php if ($order['status'] == 'pending'): ?>
                                <a href="update_status.php?id=<?= $order['id'] ?>&status=processing&from=view" class="btn btn-info">
                                    <i class="bi bi-check-circle"></i> Accept Order
                                </a>
                                <a href="update_status.php?id=<?= $order['id'] ?>&status=cancelled&from=view" class="btn btn-danger">
                                    <i class="bi bi-x-circle"></i> Reject Order
                                </a>
                            <?php elseif ($order['status'] == 'processing'): ?>
                                <a href="update_status.php?id=<?= $order['id'] ?>&status=completed&from=view" class="btn btn-success">
                                    <i class="bi bi-check-circle"></i> Mark as Completed
                                </a>
                            <?php endif; ?>
                            <a href="schedule.php" class="btn btn-secondary">
                                <i class="bi bi-arrow-left"></i> Back to Schedule
                            </a>
                        </div>
                    </div>
                    <div class="card-footer text-muted">
                        Created at: <?= date('d M Y H:i', strtotime($order['created_at'])) ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>