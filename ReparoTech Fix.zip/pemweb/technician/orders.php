<?php
session_start();
require_once '../db.php';

// Check if user is logged in and is a technician
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'technician') {
    header('Location: ../login.php');
    exit;
}

$user_id = (int)$_SESSION['user_id'];

// Get technician ID from technicians table
$technician = $conn->query("SELECT id FROM technicians WHERE user_id = $user_id")->fetch_assoc();
$technician_id = $technician['id'];

// Query for all orders (including processing ones for the "Mark Completed" button)
$orders = $conn->query("
    SELECT 
        o.*,
        it.name as item_type,
        sc.name as service_category,
        f.rating,
        f.comment as feedback,
        f.created_at as feedback_date,
        t.payment_type,
        t.status as payment_status,
        t.amount,
        t.completed_at as payment_date,
        pm.bank_name,
        pm.account_number
    FROM orders o
    LEFT JOIN item_types it ON o.item_type_id = it.id
    LEFT JOIN service_categories sc ON it.service_category_id = sc.id
    LEFT JOIN feedback f ON o.id = f.order_id
    LEFT JOIN transactions t ON o.id = t.order_id
    LEFT JOIN payment_methods pm ON t.payment_method_id = pm.id
    WHERE o.technician_id = $technician_id AND o.status IN ('processing', 'completed', 'cancelled')
    ORDER BY 
        CASE WHEN o.status = 'processing' THEN 0 ELSE 1 END,
        o.service_date DESC, 
        o.service_time DESC
");

if (!$orders) {
    die("Query failed: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order History</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        .badge-pending {
            background-color: #ffc107;
            color: #000;
        }
        .badge-processing {
            background-color: #0dcaf0;
            color: #000;
        }
        .badge-completed {
            background-color: #198754;
        }
        .badge-cancelled {
            background-color: #dc3545;
        }
        .star-rating {
            color: #ffc107;
            font-size: 1.2rem;
        }
        .feedback-card {
            background-color: #f8f9fa;
            border-radius: 8px;
            padding: 15px;
            margin-top: 10px;
        }
        .no-feedback {
            color: #6c757d;
            font-style: italic;
        }
        .service-badge {
            background-color: #6c757d;
            color: white;
        }
        .payment-badge {
            background-color: #6f42c1;
            color: white;
        }
        .action-column {
            width: 150px;
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <div class="row">
            <div class="col-md-3">
                <?php include 'sidebar.php'; ?>
            </div>
            <div class="col-md-9">
                <h2><i class="bi bi-clock-history"></i> Order History</h2>
                
                <?php if (isset($_GET['success'])): ?>
                    <div class="alert alert-success alert-dismissible fade show">
                        <?= htmlspecialchars($_GET['success']) ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead class="table-light">
                            <tr>
                                <th>Order ID</th>
                                <th>Customer</th>
                                <th>Service</th>
                                <th>Amount</th>
                                <th>Payment</th>
                                <th>Date</th>
                                <th>Status</th>
                                <th>Rating</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($orders && $orders->num_rows > 0): ?>
                                <?php while($order = $orders->fetch_assoc()): ?>
                                <tr>
                                    <td>#<?= $order['id'] ?></td>
                                    <td>
                                        <?= htmlspecialchars($order['customer_name']) ?><br>
                                        <small class="text-muted"><?= htmlspecialchars($order['phone']) ?></small>
                                    </td>
                                    <td>
                                        <?php if ($order['service_category']): ?>
                                            <span class="badge service-badge"><?= htmlspecialchars($order['service_category']) ?></span><br>
                                            <?= htmlspecialchars($order['item_type']) ?>
                                        <?php else: ?>
                                            <span class="text-muted">N/A</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($order['total_amount']): ?>
                                            $<?= number_format($order['total_amount'], 2) ?>
                                        <?php else: ?>
                                            <span class="text-muted">N/A</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($order['payment_type']): ?>
                                            <span class="badge payment-badge">
                                                <?= strtoupper($order['payment_type']) ?>
                                            </span><br>
                                            <small>
                                                <?= $order['amount'] ? '$'.number_format($order['amount'], 2) : 'N/A' ?><br>
                                                <span class="text-<?= $order['payment_status'] == 'completed' ? 'success' : 'warning' ?>">
                                                    <?= ucfirst($order['payment_status']) ?>
                                                </span>
                                            </small>
                                        <?php else: ?>
                                            <span class="badge bg-secondary">Not Paid</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?= date('d M Y', strtotime($order['service_date'])) ?><br>
                                        <small><?= htmlspecialchars($order['service_time']) ?></small>
                                    </td>
                                    <td>
                                        <span class="badge rounded-pill badge-<?= $order['status'] ?>">
                                            <?= ucfirst($order['status']) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($order['rating']): ?>
                                            <div class="star-rating">
                                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                                    <i class="bi bi-star<?= $i <= $order['rating'] ? '-fill' : '' ?>"></i>
                                                <?php endfor; ?>
                                            </div>
                                        <?php else: ?>
                                            <span class="text-muted">No rating</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($order['status'] === 'processing'): ?>
                                            <form method="post" action="complete_order.php" class="d-inline">
                                                <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
                                                <button type="submit" class="btn btn-sm btn-success">
                                                    <i class="bi bi-check-circle"></i> Complete
                                                </button>
                                            </form>
                                            <span class="text-muted">N/A</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="9" class="text-center text-muted py-4">
                                        <i class="bi bi-clipboard-x" style="font-size: 3rem;"></i>
                                        <p class="mt-2">No orders found</p>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Confirm before marking as completed
        document.querySelectorAll('form[action="complete_order.php"]').forEach(form => {
            form.addEventListener('submit', function(e) {
                if (!confirm('Are you sure you want to mark this order as completed? This will record your earnings for this job.')) {
                    e.preventDefault();
                }
            });
        });
    </script>
</body>
</html>