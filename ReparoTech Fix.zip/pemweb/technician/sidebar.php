<?php
// Konfigurasi base URL
$tech_root = '/pemweb/technician/';
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://';
$base_url = $protocol . $_SERVER['HTTP_HOST'] . $tech_root;

// Daftar menu items
$menu_items = [
    'dashboard' => [
        'title' => 'Dashboard',
        'icon' => 'speedometer2',
        'url' => 'dashboard.php'
    ],
    'orders' => [
        'title' => 'My Orders',
        'icon' => 'list-task',
        'url' => 'orders.php'
    ],
    'schedule' => [
        'title' => 'My Schedule',
        'icon' => 'calendar-check',
        'url' => 'schedule.php'
    ],
    'performance' => [
        'title' => 'My Performance',
        'icon' => 'graph-up',
        'url' => 'performance.php'
    ],
    'feedback' => [
        'title' => 'Customer Feedback',
        'icon' => 'chat-left-text',
        'url' => 'feedback.php'
    ],
    'articles' => [
        'title' => 'My Articles',
        'icon' => 'journal-text',
        'url' => 'articles/index.php'
    ],
    'profile' => [
        'title' => 'My Profile',
        'icon' => 'person-circle',
        'url' => 'profile/profile.php'
    ],
];

// Fungsi untuk mengecek active menu
function isMenuActive($menuUrl, $currentUri) {
    // Ambil path saja (abaikan query string dan fragment)
    $currentPath = parse_url($currentUri, PHP_URL_PATH);
    
    // Normalisasi path - hapus slash di awal/akhir dan convert ke lowercase
    $currentPath = trim(strtolower($currentPath), '/');
    $menuPath = trim(strtolower($menuUrl), '/');
    
    // Jika path berakhir dengan .php, bandingkan nama file
    if (substr($menuPath, -4) === '.php') {
        return basename($currentPath) === basename($menuPath);
    }
    
    // Untuk path directory (seperti articles/)
    return strpos($currentPath, $menuPath) === 0;
}

$current_uri = $_SERVER['REQUEST_URI'];
?>

<!-- HTML Sidebar Menu -->
<div class="list-group" id="techSideNav">
    <!-- Group: Main -->
    <div class="list-group-item list-group-item-dark">
        <i class="bi bi-menu-button-wide"></i> Main Menu
    </div>
    
    <?php foreach(['dashboard', 'orders', 'schedule'] as $key): ?>
        <a href="<?= $base_url . $menu_items[$key]['url'] ?>" 
           class="list-group-item list-group-item-action <?= isMenuActive($menu_items[$key]['url'], $current_uri) ? 'active' : '' ?>">
            <i class="bi bi-<?= $menu_items[$key]['icon'] ?>"></i> <?= $menu_items[$key]['title'] ?>
        </a>
    <?php endforeach; ?>
    
    <!-- Group: Performance -->
    <div class="list-group-item list-group-item-dark">
        <i class="bi bi-graph-up"></i> Performance
    </div>
    
    <?php foreach(['performance', 'feedback'] as $key): ?>
        <a href="<?= $base_url . $menu_items[$key]['url'] ?>" 
           class="list-group-item list-group-item-action <?= isMenuActive($menu_items[$key]['url'], $current_uri) ? 'active' : '' ?>">
            <i class="bi bi-<?= $menu_items[$key]['icon'] ?>"></i> <?= $menu_items[$key]['title'] ?>
        </a>
    <?php endforeach; ?>
    
    <!-- Group: Content -->
    <div class="list-group-item list-group-item-dark">
        <i class="bi bi-file-earmark-text"></i> Content
    </div>
    
    <a href="<?= $base_url . $menu_items['articles']['url'] ?>" 
       class="list-group-item list-group-item-action <?= isMenuActive($menu_items['articles']['url'], $current_uri) ? 'active' : '' ?>">
        <i class="bi bi-<?= $menu_items['articles']['icon'] ?>"></i> <?= $menu_items['articles']['title'] ?>
    </a>
    
    <!-- Group: Account -->
    <div class="list-group-item list-group-item-dark">
        <i class="bi bi-person-circle"></i> Account
    </div>
    
    <a href="<?= $base_url . $menu_items['profile']['url'] ?>" 
       class="list-group-item list-group-item-action <?= isMenuActive($menu_items['profile']['url'], $current_uri) ? 'active' : '' ?>">
        <i class="bi bi-<?= $menu_items['profile']['icon'] ?>"></i> <?= $menu_items['profile']['title'] ?>
    </a>
    
    <!-- Logout -->
    <div class="list-group-item"></div>
    <a href="<?= $base_url ?>../logout.php" class="list-group-item list-group-item-action text-danger">
        <i class="bi bi-box-arrow-right"></i> Logout
    </a>
</div>

<style>
#techSideNav {
    border-radius: 0.5rem;
    overflow: hidden;
}

#techSideNav .active {
    background-color: var(--bs-primary) !important;
    color: white !important;
    font-weight: bold;
    border-color: var(--bs-primary) !important;
}

#techSideNav .list-group-item-dark {
    background-color: var(--bs-gray-800);
    color: white;
    font-weight: 500;
}

#techSideNav a:not(.active):hover {
    background-color: rgba(0, 0, 0, 0.05);
}

#techSideNav a.active i {
    color: white !important;
}

#techSideNav .bi {
    margin-right: 0.5rem;
    font-size: 1.1rem;
}
</style>