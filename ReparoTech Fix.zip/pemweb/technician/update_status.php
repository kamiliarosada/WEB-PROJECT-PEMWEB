<?php
session_start();
require_once '../db.php';

// Check if user is logged in and is a technician
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'technician') {
    header('Location: ../login.php');
    exit;
}

if (!isset($_GET['id']) || !isset($_GET['status'])) {
    header('Location: schedule.php');
    exit;
}

$order_id = (int)$_GET['id'];
$status = $_GET['status'];
$user_id = (int)$_SESSION['user_id'];

// Validate status
$allowed_statuses = ['processing', 'completed', 'cancelled'];
if (!in_array($status, $allowed_statuses)) {
    header('Location: schedule.php');
    exit;
}

// Check if order belongs to this technician
$order_check = $conn->query("
    SELECT o.id 
    FROM orders o
    JOIN technicians t ON o.technician_id = t.id
    WHERE o.id = $order_id AND t.user_id = $user_id
");

if ($order_check->num_rows === 0) {
    header('Location: schedule.php');
    exit;
}

// Update status
$conn->query("UPDATE orders SET status = '$status' WHERE id = $order_id");

// Determine where to redirect back to
if (isset($_GET['from']) && $_GET['from'] == 'view') {
    $redirect = "view_order.php?id=$order_id";
} elseif (isset($_GET['from']) && $_GET['from'] == 'schedule') {
    $redirect = "schedule.php";
} else {
    $redirect = "orders.php";
}

// Redirect back with success message
header("Location: $redirect?success=Order+status+updated+successfully");
exit;