<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $name     = $_POST['name'];
  $username = $_POST['username'];
  $email    = $_POST['email'];
  $password = $_POST["password"];
  $phone    = $_POST['phone'];
  $country  = $_POST['country'];
  $gender   = $_POST['gender'];
  $role     = $_POST['role'];

  // Handle profile picture upload
  $profile = $_FILES['profile_picture']['name'];
  $target = "uploads/" . basename($profile);
  move_uploaded_file($_FILES['profile_picture']['tmp_name'], $target);

  // Check if username or email already exists
  $check = $conn->query("SELECT * FROM users WHERE username='$username' OR email='$email'");
  if ($check->num_rows > 0) {
    echo "<script>alert('Username atau email sudah terdaftar!'); window.location='register.php';</script>";
  } else {
    // Insert user data
    $insert_user = "INSERT INTO users (name, username, email, password, phone, country, gender, profile_picture, role)
               VALUES ('$name', '$username', '$email', '$password', '$phone', '$country', '$gender', '$profile', '$role')";

    if ($conn->query($insert_user)) {
      $user_id = $conn->insert_id;
      
      // If role is technician, insert additional technician data
      if ($role == 'technician') {
        $specialization = $_POST['specialization'];
        $experience = $_POST['experience'];
        $certification = $_POST['certification'];
        $rate = $_POST['rate'];
        
        // Handle certification file upload
        $cert_file = $_FILES['certification_file']['name'];
        $cert_target = "uploads/certifications/" . basename($cert_file);
        move_uploaded_file($_FILES['certification_file']['tmp_name'], $cert_target);
        
        $insert_tech = "INSERT INTO technicians (user_id, specialization, experience_years, certification, rate)
                        VALUES ($user_id, '$specialization', $experience, '$cert_file', $rate)";
        
        if (!$conn->query($insert_tech)) {
          echo "<script>alert('Pendaftaran teknisi gagal!'); window.location='register.php';</script>";
          exit();
        }
        
        // Insert technician skills
        if (isset($_POST['skills'])) {
          foreach ($_POST['skills'] as $skill_id) {
            $conn->query("INSERT INTO technician_skills (user_id, service_category_id) VALUES ($user_id, $skill_id)");
          }
        }
      }
      
      echo "<script>alert('Register berhasil! Silakan login.'); window.location='login.php';</script>";
    } else {
      echo "<script>alert('Register gagal!'); window.location='register.php';</script>";
    }
  }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Register - ReparoTech</title>
  <link rel="stylesheet" href="assets/style_login.css">
  <style>
    .technician-fields {
      display: none;
      margin-top: 15px;
      padding: 15px;
      background: #f5f5f5;
      border-radius: 5px;
    }
    .skills-container {
      display: flex;
      flex-wrap: wrap;
      gap: 10px;
      margin-top: 10px;
    }
    .skill-checkbox {
      background: #e0e0e0;
      padding: 5px 10px;
      border-radius: 15px;
      cursor: pointer;
    }
    .skill-checkbox input {
      margin-right: 5px;
    }
  </style>
  <script>
    function toggleTechnicianFields() {
      const role = document.querySelector('select[name="role"]').value;
      const techFields = document.getElementById('technician-fields');
      if (role === 'technician') {
        techFields.style.display = 'block';
      } else {
        techFields.style.display = 'none';
      }
    }
  </script>
</head>
<body>
  <div class="container">
    <div class="left">
      <img src="assets/teknisi.jpg" alt="Login Image">
    </div>
    <div class="right">
      <h2>Welcome to ReparoTech!</h2>
      <p class="form-title">Registration Form</p>
      <form action="register.php" method="POST" enctype="multipart/form-data">
        <input type="text" name="name" placeholder="Enter Your Name" required>
        <input type="text" name="username" placeholder="Enter Your Username" required>
        <input type="email" name="email" placeholder="Enter Email Address" required>
        <input type="password" name="password" placeholder="Enter Password" required>
        <input type="tel" name="phone" placeholder="Enter Phone" required>
        
        <select name="country" required>
          <option value="">Select Your Region</option>
          <option value="Mataram">Mataram</option>
          <option value="Lombok Timur">Lombok Timur</option>
          <option value="Lombok Barat">Lombok Barat</option>
          <option value="Lombok Timur">Lombok Tengah</option>
        </select>
        
        <div class="gender">
          Gender:
          <label><input type="radio" name="gender" value="male" checked> Male</label>
          <label><input type="radio" name="gender" value="female"> Female</label>
        </div>
        
        <label>Role:
          <select name="role" required onchange="toggleTechnicianFields()">
            <option value="user">User</option>
            <option value="technician">Technician</option>
          </select>
        </label>
        
        <div id="technician-fields" class="technician-fields">
          <input type="text" name="specialization" placeholder="Specialization (e.g. AC Repair)">
          <input type="number" name="experience" placeholder="Years of Experience" min="0">
          <input type="text" name="certification" placeholder="Certification Name">
          <input type="file" name="certification_file" accept=".pdf,.jpg,.png">
          <input type="number" name="rate" placeholder="Hourly Rate" min="0" step="5000">
          
          <label>Skills:</label>
          <div class="skills-container">
            <?php
            $skills = $conn->query("SELECT * FROM service_categories");
            while ($skill = $skills->fetch_assoc()):
            ?>
            <label class="skill-checkbox">
              <input type="checkbox" name="skills[]" value="<?= $skill['id'] ?>">
              <?= $skill['name'] ?>
            </label>
            <?php endwhile; ?>
          </div>
        </div>
        
        <label class="upload">Profile Picture:
          <input type="file" name="profile_picture" accept="image/*">
        </label>
        
        <label class="terms">
          <input type="checkbox" required> I agree to ReparoTech Terms and Conditions.
        </label>
        
        <button type="submit" class="btn yellow">Register</button>
        
        <div class="bottom-links">
          <a href="login.php">🔑 Already Member?</a>
          <span>|</span>
          <a href="index.php">🏠 Back to Home</a>
        </div>
      </form>
    </div>
  </div>
</body>
</html>